package com.aa.aaa.flutter_tool;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
