import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_tool/utils/app_const/app_colors.dart';
import 'package:get/get.dart';
import '../controller/transfer_input_controller.dart';
import '../models/transfer_input_model.dart';

class TransferInputView<Controller extends TransferInputController> extends GetView<Controller>{
  final TransferInputModel inputModel;
  final bool needLine;
  const TransferInputView({super.key, required this.inputModel, this.needLine = true});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: Column(
        children: [
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  margin: const EdgeInsets.only(left: 10),
                  width: 100,
                  child: Text(inputModel.title,style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 16),),
                ),
                _createInputWidget(context),
              ],
            ),
          ),
          needLine?Container(height: 0.5, margin: const EdgeInsets.only(bottom: 2), color: AppColors.lightBackGround):Container()
        ],
      ),
    );
  }

  Widget _createInputWidget(BuildContext context){
    if(inputModel.inputType == TransferInputType.transferInputTypeNick){
      return _createInputField(controller.nickController.value);
    }
    if(inputModel.inputType == TransferInputType.transferInputTypeAmount){
      return _createInputField(controller.amountController.value);
    }
    if(inputModel.inputType == TransferInputType.transferInputTypeDesc){
      return _createInputField(controller.descController.value);
    }
    if(inputModel.inputType == TransferInputType.transferInputTypeChoose){
      return _createChooseField(context);
    }
    if(inputModel.inputType == TransferInputType.transferInputTypeTime){
      return _createChooseField(context);
    }
    if(inputModel.inputType == TransferInputType.transferInputTypeRecvTime){
      return _createChooseField(context);
    }
    return _createInputField(controller.nickController.value);
  }

  Widget _createInputField(TextEditingController editingController){
    return Container(
        width: 200,
        alignment: Alignment.centerRight,
        margin: const EdgeInsets.only(right: 10),
        child:TextField(
            controller: editingController,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, color: Colors.black),
            minLines: 1,
            decoration: InputDecoration(
              hintText: inputModel.hintText,
              hintStyle: const TextStyle(color: AppColors.liveChatBgColor),
              enabledBorder: const UnderlineInputBorder( borderSide: BorderSide(color: AppColors.whiteColor)),
              focusedBorder: const UnderlineInputBorder( borderSide: BorderSide(color: AppColors.whiteColor),
              ),
            )
        )
    );
  }

  Widget _createChooseField(BuildContext context){
    return GestureDetector(
      onTap: () =>controller.chooseEvent(inputModel, context),
      child: Container(
          width: 200,
          alignment: Alignment.center,
          margin: const EdgeInsets.only(right: 10),
          child: _createChooseText()
      ),
    );
  }

  Widget _createChooseText(){
    if (inputModel.inputType == TransferInputType.transferInputTypeChoose){
      return Obx((){
        return Text(controller.transferType.value.isNotEmpty?controller.transferType.value:inputModel.hintText,style: TextStyle(color: controller.transferType.value.isNotEmpty?Colors.black:AppColors.liveChatBgColor,fontSize: 16));});
    }
    if (inputModel.inputType == TransferInputType.transferInputTypeTime){
      return Obx((){
        return Text(controller.transferTime.value.isNotEmpty?controller.transferTime.value:inputModel.hintText,style: TextStyle(color: controller.transferTime.value.isNotEmpty?Colors.black:AppColors.liveChatBgColor,fontSize: 16));});
    }
    if (inputModel.inputType == TransferInputType.transferInputTypeRecvTime){
      return Obx((){
        return Text(controller.transferRecvTime.value.isNotEmpty?controller.transferRecvTime.value:inputModel.hintText,style: TextStyle(color: controller.transferRecvTime.value.isNotEmpty?Colors.black:AppColors.liveChatBgColor,fontSize: 16));});
    }
    return Obx((){
      return Text(controller.transferType.value.isNotEmpty?controller.transferType.value:inputModel.hintText,style: TextStyle(color: controller.transferType.value.isNotEmpty?Colors.black:AppColors.liveChatBgColor,fontSize: 16));
    });
  }
}