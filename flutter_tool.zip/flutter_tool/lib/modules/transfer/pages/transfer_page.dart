import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_tool/utils/app_const/app_const.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../../../utils/app_const/app_colors.dart';
import '../controller/transfer_controller.dart';
import '../views/transfer_input_view.dart';

class TransferPage<Controller extends TransferController> extends GetView<Controller>{
  const TransferPage({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
          iconTheme: const IconThemeData(color: Colors.white),
          title:  Text(controller.dataModel.title,style:const TextStyle(fontSize: 18,color: Colors.white)),
          backgroundColor:AppColors.appBarColor
      ),
      body: Container(
        color: AppColors.lightBackGround,
        child: Column(
          children: [
            _createTransferList(),
            _createSubmitBtn(context)
          ],
        ),
      ),
    );
  }
  Widget _createTransferList(){
    return Container(
      height: 299,
      color: Colors.white,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        children: [
          TransferInputView(inputModel: controller.inputList.obs.value[0]),
          TransferInputView(inputModel: controller.inputList.obs.value[1]),
          TransferInputView(inputModel: controller.inputList.obs.value[2]),
          TransferInputView(inputModel: controller.inputList.obs.value[3]),
          TransferInputView(inputModel: controller.inputList.obs.value[4]),
          TransferInputView(inputModel: controller.inputList.obs.value[5],needLine:false),
        ],
      ),
    );
  }
  Widget _createSubmitBtn(BuildContext context){
    return GestureDetector(
      onTap: ()=>controller.submitTransfer(),
      child: Container(
        height: 45,
        alignment: Alignment.center,
        width: AppConst.screenWidth(context) - 40,
        margin: const EdgeInsets.only(top: 20,left: 20, right: 20),
        decoration: BoxDecoration(color: Colors.redAccent,borderRadius: BorderRadius.circular(40)),
        child:const Text('提交',style: TextStyle(color: Colors.white,fontSize:18)),
      ),
    );
  }
}