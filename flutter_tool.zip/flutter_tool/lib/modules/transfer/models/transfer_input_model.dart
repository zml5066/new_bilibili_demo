enum TransferInputType {
  transferInputTypeNick,// 昵称
  transferInputTypeAmount,//金额
  transferInputTypeChoose, // 转账类型
  transferInputTypeTime, // 请输入转账时间
  transferInputTypeRecvTime, // 请输入收款时间
  transferInputTypeDesc, // 转账说明
}

class TransferInputModel {
  String title;
  String hintText;
  TransferInputType inputType;
  TransferInputModel({required this.title, required this.hintText, required this.inputType});
}