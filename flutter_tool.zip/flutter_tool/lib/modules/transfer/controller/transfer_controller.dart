
import 'package:flutter_tool/modules/transfer/controller/transfer_input_controller.dart';
import 'package:get/get.dart';
import '../../../utils/app_const/app_toast.dart';
import '../../toolset/models/toolset_cell_model.dart';
import '../models/transfer_input_model.dart';

class TransferController extends GetxController{
  late ToolsetCellModel dataModel;
  late RxList<TransferInputModel> inputList;

  void submitTransfer(){
    Get.find<TransferInputController>().submitSuccess();
    AppToast.toast('提交成功');
  }

  @override
  void onInit() {
    super.onInit();
    dataModel = Get.arguments;
    inputList = RxList<TransferInputModel>([
      TransferInputModel(title: '对方昵称',hintText: '请输入对方昵称',inputType: TransferInputType.transferInputTypeNick),
      TransferInputModel(title: '转账金额',hintText: '请输入转账金额',inputType: TransferInputType.transferInputTypeAmount),
      TransferInputModel(title: '转账类型',hintText: '请选择转账类型',inputType: TransferInputType.transferInputTypeChoose),
      TransferInputModel(title: '转账时间',hintText: '请选择转账时间',inputType: TransferInputType.transferInputTypeTime),
      TransferInputModel(title: '收款时间',hintText: '请选择收款时间',inputType: TransferInputType.transferInputTypeRecvTime),
      TransferInputModel(title: '转账说明',hintText: '请输入转账说明',inputType: TransferInputType.transferInputTypeDesc),
    ]);
  }
}