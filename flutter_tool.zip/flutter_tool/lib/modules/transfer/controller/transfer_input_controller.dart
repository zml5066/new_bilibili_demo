
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pickers/pickers.dart';
import 'package:flutter_pickers/time_picker/model/date_mode.dart';
import 'package:get/get.dart';

import '../models/transfer_input_model.dart';

class TransferInputController extends GetxController {
  late Rx<TextEditingController> nickController;
  late Rx<TextEditingController> amountController;
  late Rx<TextEditingController> descController;
  late RxString transferType;// 转账类型
  late RxString transferTime;// 转账时间
  late RxString transferRecvTime;// 收账时间
  late List<String> transferTypeList;

  void chooseEvent(TransferInputModel inputModel,BuildContext context){
    if (inputModel.inputType==TransferInputType.transferInputTypeChoose){
      Pickers.showSinglePicker(context,
          data: transferTypeList,
          selectData: '',
          onConfirm: (p, position) {
            transferType.value = p;
          });
    }
    if (inputModel.inputType==TransferInputType.transferInputTypeTime){
      Pickers.showDatePicker(
        context,
        mode: DateMode.YMDHMS,
        onConfirm: (p) {
          transferTime.value = '${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}:${p.second}';
        },
      );
    }
    if (inputModel.inputType==TransferInputType.transferInputTypeRecvTime){
      Pickers.showDatePicker(
        context,
        mode: DateMode.YMDHMS,
        onConfirm: (p) {
          transferRecvTime.value = '${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}:${p.second}';
          },
      );
    }
  }

  void submitSuccess(){
    transferType.value = '';
    transferTime.value = '';
    transferRecvTime.value = '';
    nickController.value.text = '';
    amountController.value.text = '';
    descController.value.text = '';
  }

  @override
  void onInit() {
    super.onInit();
    transferType = ''.obs;
    transferTime = ''.obs;
    transferRecvTime= ''.obs;
    nickController  = TextEditingController().obs;
    amountController  = TextEditingController().obs;
    descController  = TextEditingController().obs;
    transferTypeList = ['支付宝', '微信', '银行卡'];
  }
}