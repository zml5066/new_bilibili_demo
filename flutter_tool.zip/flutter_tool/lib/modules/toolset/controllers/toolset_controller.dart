
import 'package:get/get.dart';

import '../../../routers/app_pages.dart';
import '../../../utils/app_const/app_toast.dart';
import '../models/toolset_banner_model.dart';
import '../models/toolset_cell_model.dart';

class ToolsetController extends GetxController {
  late List<ToolsetCellModel>toolsetListData;
  late RxList<ToolsetBannerModel> bannersList;
  @override
  void onInit() {
    super.onInit();
    toolsetListData = [
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '结婚证加强版',index: 0),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '二维码生成',index: 1),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '转账',index: 2),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '密码生成器',index: 3),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '网路测速',index:4),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '余额',index: 5),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '真心话大冒险',index: 6),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '手持弹幕',index: 7),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '分贝测试仪',index: 8),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '朋友圈',index: 9),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '对话',index: 10),
      ToolsetCellModel(iconName: 'assets/images/微信收藏.png', title: '微信语音导出',index: 11),
    ];
    bannersList = RxList([
      ToolsetBannerModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF', id: "1", name: '1'),
      ToolsetBannerModel(imageUrl:'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF', id: "2", name: '1'),
      ToolsetBannerModel(imageUrl: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF', id: "3", name: '1'),
      ToolsetBannerModel( imageUrl: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF', id: "4", name: '1'),
    ]);
  }

  void cellTap(ToolsetCellModel cellModel){
    if (cellModel.index == 0){
      Get.toNamed(AppPages.marriageCert, arguments:cellModel);
    }
    else if (cellModel.index == 1){
      Get.toNamed(AppPages.qrcodeGenerate, arguments:cellModel);
    }
    else if(cellModel.index == 2){
      Get.toNamed(AppPages.transfer, arguments:cellModel);
    }
    else if(cellModel.index == 3){
      Get.toNamed(AppPages.pwdGenerate, arguments:cellModel);
    }
    else if(cellModel.index == 4){
      Get.toNamed(AppPages.networkSpeed, arguments:cellModel);
    }
    else {
      AppToast.toast('${cellModel.title}正在紧急开发中');
    }
  }
}