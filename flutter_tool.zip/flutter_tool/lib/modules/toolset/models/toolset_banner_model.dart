
class ToolsetBannerModel {
  final String imageUrl;
  final String id;
  final String name;
  ToolsetBannerModel({required this.imageUrl, required this.id, required this.name});
}