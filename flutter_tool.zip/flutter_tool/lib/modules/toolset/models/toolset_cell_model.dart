
class ToolsetCellModel {
  String iconName;
  String title;
  int index;
  ToolsetCellModel({required this.iconName, required this.title, required this.index});
}

