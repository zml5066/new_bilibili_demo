
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_tool/utils/app_const/app_colors.dart';
import 'package:flutter_tool/utils/app_const/app_const.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../controllers/toolset_controller.dart';
import '../models/toolset_cell_model.dart';
import '../views/toolset_banner_view.dart';
import '../views/toolset_cell_view.dart';

class ToolsetPage<Controller extends ToolsetController> extends GetView<Controller> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('微访',style: TextStyle(fontSize: 18,color: Colors.white)),
          backgroundColor:AppColors.appBarColor
      ),
      body:Container(
        color: AppColors.pageBackground,
        child: Column(
          children: [
            _createToolsetList(context),
            const Expanded(child:ToolsetBannerView())
          ],
        ),
      ),
    );
  }

  Widget _createToolsetList(BuildContext context){
    return Container(
      decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20)),
      height: 300,
      width: AppConst.screenWidth(context),
      child:  Container(
        alignment: Alignment.center,
        margin: const EdgeInsets.only(top: 10),
        child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.only(left: 5, right: 5, top: 5),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1),
            itemCount: controller.toolsetListData.length,
            itemBuilder: (BuildContext context, int position) {
              return ToolSetCellView(cellModel: controller.toolsetListData[position],);}
        ),
      ),
    );
  }
}