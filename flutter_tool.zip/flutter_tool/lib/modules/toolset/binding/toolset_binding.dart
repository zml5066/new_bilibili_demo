import 'package:get/get.dart';

import '../controllers/toolset_controller.dart';

class ToolsetBinding extends Bindings {
  @override
  void dependencies() {
   Get.lazyPut<ToolsetController>(() => ToolsetController());
  }
}