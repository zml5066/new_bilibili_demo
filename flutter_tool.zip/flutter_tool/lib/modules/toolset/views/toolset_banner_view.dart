import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:flutter_swiper_view/flutter_swiper_view.dart';
import '../controllers/toolset_controller.dart';
import 'package:cached_network_image/cached_network_image.dart';
class ToolsetBannerView<Controller extends ToolsetController> extends GetView<Controller> {
  const ToolsetBannerView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 0),
      child: Swiper(
        itemBuilder: (context, index){
          return CachedNetworkImage(imageUrl:controller.bannersList.obs.value[index].imageUrl,fit:BoxFit.fill);
        },
        itemCount: controller.bannersList.obs.value.length,
        autoplay:true,
        pagination: const SwiperPagination(),
      ),
    );
  }
}