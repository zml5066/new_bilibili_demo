
import 'package:flutter/cupertino.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';

import '../controllers/toolset_controller.dart';
import '../models/toolset_cell_model.dart';

class ToolSetCellView <Controller extends ToolsetController> extends GetView<Controller>  {
  final ToolsetCellModel cellModel;
  const ToolSetCellView({super.key, required this.cellModel});

  @override
  Widget build(BuildContext context) {
    return  Container(
      alignment: Alignment.center,
      child:  GestureDetector(
        onTap: ()=>controller.cellTap(cellModel),
        child: Column(
          children: [
            SizedBox(
              width: 35,
              height: 35,
              child: Image.asset(cellModel.iconName,fit: BoxFit.cover),
            ),
            Container(
              margin: const EdgeInsets.only(top: 5),
              child: Text(cellModel.title),
            )
          ],
        ),
      ),
    );
  }
}
