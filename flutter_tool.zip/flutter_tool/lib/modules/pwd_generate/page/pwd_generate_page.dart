import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';

import '../../../utils/app_const/app_colors.dart';
import '../controller/pwd_generate_controller.dart';

class PwdGeneratePage<Controller extends PwdGenerateController>
    extends GetView<Controller> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          iconTheme: const IconThemeData(color: Colors.white),
          title: Text(controller.dataModel.title,
              style: const TextStyle(fontSize: 18, color: Colors.white)),
          backgroundColor: AppColors.appBarColor),
      body: Container(
        color: AppColors.lightBackGround,
        child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          children: [
            Container(
              margin: const EdgeInsets.only(left: 10, top: 20),
              child: const Text('已经生成的密码：',
                  style: TextStyle(color: AppColors.blackColor, fontSize: 16)),
            ),
            _createGenerateResult(),
            _createUseCharacter(),
            _createPwdLen(),
            _createGenerateBtn(context),
          ],
        ),
      ),
    );
  }

  Widget _createGenerateResult() {
    return Container(
      height: 45,
      alignment: Alignment.centerLeft,
      margin: const EdgeInsets.only(left: 10, top: 30, right: 10),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Obx(
                () {
              return Container(
                margin: const EdgeInsets.only(left: 10),
                child:  Text(controller.generatePwd.value,
                    style: const TextStyle(
                        color: AppColors.blackColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
              );
            },
          ),
          GestureDetector(
            onTap: ()=>controller.copyGeneratePwd(),
            child: Container(
              alignment: Alignment.centerRight,
              margin: const EdgeInsets.only(right: 10),
              child: Icon(Icons.copy,size: 25,color: Colors.orange,),
            ),
          )
        ],
      ),
    );
  }

  // 创建使用字符
  Widget _createUseCharacter() {
    return Container(
        height: 50,
        margin: const EdgeInsets.only(left: 10, right: 10, top: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              margin: const EdgeInsets.only(left: 10),
              alignment: Alignment.centerLeft,
              child: const Text('使用字符:',
                  style: TextStyle(color: AppColors.blackColor, fontSize: 16)),
            ),
            Expanded(child: Obx(() {
              return Row(
                children: _createCharacterChildren(),
              );
            })),
          ],
        ));
  }

  // 使用字符子部件
  List<Widget> _createCharacterChildren() {
    List<Widget> children = [];
    for (int i = 0; i < controller.useCharacterKey.length; i++) {
      children.add(Row(
        children: [
          Checkbox(
            value: controller
                .useCharacter.obs.value[controller.useCharacterKey[i]],
            activeColor: Colors.greenAccent,
            checkColor: Colors.white,
            onChanged: (bool? value) => controller.updateUserCharacterStatus(
                controller.useCharacterKey[i], value!),
          ),
          Text(controller.useCharacterKey[i],
              style: const TextStyle(color: AppColors.blackColor, fontSize: 16))
        ],
      ));
    }
    return children;
  }

  // 创建密码长度
  Widget _createPwdLen(){
    return Container(
      height: 30,
      width: 120,
      margin: const EdgeInsets.only(left: 10, top: 30, right: 10),
       child: Row(
       mainAxisAlignment: MainAxisAlignment.start,
       children: [
         Container(
           alignment: Alignment.centerLeft, margin: const EdgeInsets.only(left: 10),
           child: const Text('密码长度:', style: TextStyle(color: AppColors.blackColor, fontSize: 16))),
         const SizedBox(width: 20),
         GestureDetector(
           onTap: ()=>controller.updatePwdLen(true),
           child: const Icon(Icons.add,size: 20,color: AppColors.blackColor),
         ),
         const SizedBox(width: 10),
         Obx(() {
           return Container(
             width: 50,
             alignment: Alignment.center,
             decoration: BoxDecoration(color: AppColors.whiteColor,borderRadius: BorderRadius.circular(5)),
             child: Text(controller.pwdLen.value.toString(), style: const TextStyle(color: AppColors.blackColor, fontSize: 16)),
           );
         }),
         const SizedBox(width: 10),
         GestureDetector(
           onTap: ()=>controller.updatePwdLen(false),
           child: const Icon(Icons.remove,size: 20,color: AppColors.blackColor),
         ),
       ],
     ),
    );
  }

  /// 生成密码按钮
  Widget _createGenerateBtn(BuildContext context) {
    return GestureDetector(
      onTap: () => controller.startGeneratePwd(),
      child: Container(
        height: 45,
        alignment: Alignment.center,
        margin: const EdgeInsets.only(top: 30, left: 10, right: 20),
        decoration: BoxDecoration(
            color: Colors.redAccent, borderRadius: BorderRadius.circular(40)),
        child: const Text('生成密码',
            style: TextStyle(color: Colors.white, fontSize: 18)),
      ),
    );
  }
}
