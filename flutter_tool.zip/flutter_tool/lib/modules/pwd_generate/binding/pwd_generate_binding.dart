
import 'package:get/get.dart';

import '../controller/pwd_generate_controller.dart';

class PwdGenerateBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PwdGenerateController>(() => PwdGenerateController());
  }
}