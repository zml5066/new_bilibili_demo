
import 'dart:math';

import 'package:flutter/services.dart';
import 'package:flutter_tool/utils/app_const/app_const.dart';
import 'package:flutter_tool/utils/app_const/app_toast.dart';
import 'package:get/get.dart';

import '../../toolset/models/toolset_cell_model.dart';

class PwdGenerateController extends GetxController {
  late ToolsetCellModel dataModel;
  late RxString generatePwd;// 生成的密码
  late RxMap<String, bool> useCharacter;
  late List<String>useCharacterKey;
  late Map<String, String> characterMap;
  late RxInt pwdLen; // 密码长度

  void startGeneratePwd(){
    String availableChars = '';
    useCharacter.forEach((key, value) {
      if (value){
        availableChars += characterMap[key].toString();
      }
    });
    generatePwd.value = generateRandomString(availableChars);
  }

  void copyGeneratePwd(){
    Clipboard.setData(ClipboardData(text: generatePwd.value));
    AppToast.toast('复制成功');
  }

  void updateUserCharacterStatus(String key, bool value){
    useCharacter.obs.value[key]=value;
  }

  void updatePwdLen(bool add){
    if (add){
      if (pwdLen.value < 50) {
        pwdLen.value = pwdLen.value + 1;
      }
    }
    else {
      if (pwdLen.value >6) {
        pwdLen.value = pwdLen.value - 1;
      }
    }
  }

  String generateRandomString(String availableChars) {
    final random = Random();
    final randomString = List.generate(pwdLen.value,
            (index) => availableChars[random.nextInt(availableChars.length)])
        .join();
    return randomString;
  }

  @override
  void onInit() {
    super.onInit();
    dataModel = Get.arguments;
    generatePwd = ''.obs;
    pwdLen = 6.obs;
    useCharacterKey = ['a-z', 'A-Z','0-9','特殊字符'];
    List<String> characterList = ['abcdefghijklmnoqprstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ','0123456789','!@#%^&*'];
    useCharacter = RxMap<String, bool>({});
    characterMap =({});
    for(int i = 0; i<useCharacterKey.length; i ++){
      useCharacter.obs.value[useCharacterKey[i]]=false;
      characterMap[useCharacterKey[i]] = characterList[i];
    }
    useCharacter.obs.value['a-z']=true;
  }
}