import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/bindings_interface.dart';
import '../controller/qrcode_generate_controller.dart';

class QRCodeGenerateBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<QRCodeGenerateController>(() => QRCodeGenerateController());
  }
}