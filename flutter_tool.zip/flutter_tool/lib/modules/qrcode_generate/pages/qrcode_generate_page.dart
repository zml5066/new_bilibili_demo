import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../../utils/app_const/app_colors.dart';
import '../controller/qrcode_generate_controller.dart';

class QRCodeGeneratePage<Controller extends QRCodeGenerateController> extends GetView<Controller>{
  const QRCodeGeneratePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          iconTheme: const IconThemeData(color: Colors.white),
          title:  Text(controller.dataModel.title,style: const TextStyle(fontSize: 18,color: Colors.white)),
          backgroundColor:AppColors.appBarColor
      ),
      body: Column(
        // crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: const EdgeInsets.all(20),
            child: TextField(
              controller: controller.editingController,
              decoration: const InputDecoration(border: OutlineInputBorder(), labelText: '请输入内容'),
            ),
          ),
          Obx(() {
            return controller.qrCode.value?_createQRImageView():Container();
          }),
          ElevatedButton(
              onPressed: ()=>controller.generateQRCode(),
              child: const Text('生成二维码')),
        ],
      ),
    );
  }

  Widget _createQRImageView(){
    return  Container(
      margin: const EdgeInsets.all(20),
      child: QrImageView(
        data: controller.editingController.text,
        version: QrVersions.auto,
        size: 300,
        gapless: false,
      ),
    );
  }
}