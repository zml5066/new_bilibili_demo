import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../../../utils/app_const/app_const.dart';
import '../../toolset/models/toolset_cell_model.dart';

class QRCodeGenerateController extends GetxController {
  late ToolsetCellModel dataModel;
  late TextEditingController editingController;
  late RxBool qrCode;
  var count = 0.obs;
  void generateQRCode(){
    if(editingController.text.isNotEmpty){
      qrCode.value= true;
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    qrCode = false.obs;
    dataModel = Get.arguments;
    editingController  = TextEditingController();
    editingController.addListener(() {
     if(!editingController.text.isNotEmpty){
       qrCode.value= false;
     }
    });
  }
  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
    editingController.dispose();
  }
}