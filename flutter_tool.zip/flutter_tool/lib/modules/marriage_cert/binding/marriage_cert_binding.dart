
import 'package:get/get.dart';

import '../controllers/marriage_cert_controller.dart';
import '../controllers/marriage_image_controller.dart';

class MarriageCertBinding extends Bindings {
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut<MarriageCertController>(() => MarriageCertController());
    Get.put(MarriageImageController());
  }
}