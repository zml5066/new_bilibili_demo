
import 'package:get/get.dart';

class MarriageImageController extends GetxController{

}