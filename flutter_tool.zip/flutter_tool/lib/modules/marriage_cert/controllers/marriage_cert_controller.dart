
import 'package:get/get.dart';

import '../../toolset/models/toolset_cell_model.dart';

class MarriageCertController extends GetxController {
  late ToolsetCellModel dataModel;
  @override
  void onInit() {
    super.onInit();
    dataModel = Get.arguments;
  }
}