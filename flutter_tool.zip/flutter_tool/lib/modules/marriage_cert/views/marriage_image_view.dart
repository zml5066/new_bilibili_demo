import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';

import '../controllers/marriage_image_controller.dart';
class MarriageImageView<Controller extends MarriageImageController> extends GetView<Controller>{
  const MarriageImageView({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

  }
}