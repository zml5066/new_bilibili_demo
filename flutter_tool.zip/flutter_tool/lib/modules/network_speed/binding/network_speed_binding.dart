import 'package:get/get.dart';
import '../controllers/network_speed_controller.dart';

class NetworkSpeedBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<NetworkSpeedController>(() => NetworkSpeedController());
  }
}