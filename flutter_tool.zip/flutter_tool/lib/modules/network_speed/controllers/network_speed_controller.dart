
import 'package:get/get.dart';

import '../../toolset/models/toolset_cell_model.dart';

class NetworkSpeedController extends GetxController{
  late ToolsetCellModel dataModel;

  @override
  void onInit() {
    super.onInit();
    dataModel = Get.arguments;
  }
}