import 'dart:ui';

abstract class AppColors {
  static const lightBackGround = Color.fromRGBO(220, 220, 220, 1.0);
  static const Color whiteColor = Color.fromRGBO(255, 255, 255, 1.0);
  static const Color blackColor = Color.fromRGBO(0, 0, 0, 1.0);
  static const Color pageBackground = Color.fromRGBO(194, 226, 248, 1.0);
  static const Color statusBarColor = Color.fromRGBO(220, 220, 220, 1.0);
  static const Color appBarColor = Color.fromRGBO(26, 148, 230, 1.0);
  static const Color liveChatBgColor = Color.fromRGBO(94, 94, 94, 0.8);
}