import 'package:flutter/material.dart';

abstract class AppValues {

  static const double emojiKeyboardDefault = 430;
  static const double giftListDefault = 350;
  static const double videoHeight = 240 + kToolbarHeight;
}
