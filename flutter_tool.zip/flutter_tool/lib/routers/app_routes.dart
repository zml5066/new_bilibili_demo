part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const toolset = _Paths.toolset;
  static const qrcodeGenerate = _Paths.qrcodeGenerate;
  static const transfer = _Paths.transfer;
  static const pwdGenerate = _Paths.pwdGenerate;
  static const networkSpeed = _Paths.networkSpeed;
  static const marriageCert = _Paths.marriageCert;
}

abstract class _Paths {
  static const toolset = '/toolset';
  static const qrcodeGenerate = '/qrcodeGenerate';
  static const transfer = '/transfer';
  static const pwdGenerate = '/pwdGenerate';
  static const networkSpeed = '/networkSpeed';
  static const marriageCert = '/marriageCert';
}