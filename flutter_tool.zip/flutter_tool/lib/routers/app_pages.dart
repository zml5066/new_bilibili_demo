
import 'package:flutter_tool/modules/pwd_generate/binding/pwd_generate_binding.dart';
import 'package:flutter_tool/modules/toolset/binding/toolset_binding.dart';
import 'package:flutter_tool/modules/toolset/pages/toolset_page.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';

import '../modules/marriage_cert/binding/marriage_cert_binding.dart';
import '../modules/marriage_cert/pages/marriage_cert_page.dart';
import '../modules/network_speed/binding/network_speed_binding.dart';
import '../modules/network_speed/page/network_speed_page.dart';
import '../modules/pwd_generate/page/pwd_generate_page.dart';
import '../modules/qrcode_generate/binding/qrcode_generate_binding.dart';
import '../modules/qrcode_generate/pages/qrcode_generate_page.dart';
import '../modules/transfer/binding/transfer_binding.dart';
import '../modules/transfer/pages/transfer_page.dart';

part 'app_routes.dart';
class AppPages {
  AppPages._();
  static const initial = Routes.toolset;
  static const qrcodeGenerate = Routes.qrcodeGenerate;
  static const transfer = Routes.transfer;
  static const pwdGenerate = Routes.pwdGenerate;
  static const networkSpeed = Routes.networkSpeed;
  static const marriageCert = Routes.marriageCert;
  static final routes = [
    GetPage(
      name: _Paths.toolset,
      page: () =>  ToolsetPage(),
      binding:  ToolsetBinding(),
    ),
    GetPage(
      name: _Paths.qrcodeGenerate,
      page: () =>  QRCodeGeneratePage(),
      binding: QRCodeGenerateBinding(),
    ),
    GetPage(
      name: _Paths.transfer,
      page: () =>  TransferPage(),
      binding: TransferBinding(),
    ),
    GetPage(
      name: _Paths.pwdGenerate,
      page: () =>  PwdGeneratePage(),
      binding: PwdGenerateBinding(),
    ),
    GetPage(
      name: _Paths.networkSpeed,
      page: () =>  const NetworkSpeedPage(),
      binding: NetworkSpeedBinding(),
    ),
    GetPage(
      name: _Paths.marriageCert,
      page: () =>  const MarriageCertPage(),
      binding: MarriageCertBinding(),
    ),
  ];
}
