//
//  FlutterInvoke.m
//  Runner
//
//  Created by Robert on 2023/6/4.
//

#import "FlutterInvoke.h"

@interface FlutterInvoke()

@property (nonatomic, strong) FlutterEngine *flutterEngine;

@property (nonatomic, strong, readwrite) FlutterViewController *flutterVC;
@end

@implementation FlutterInvoke

+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    return _sharedInstance;
}


- (void)reciveFlutterMethodWithChannelName:(NSString *)channelName
                           binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger
                               completeion:(void (^)(NSString *methodName, id arguments))completeion {
    if (completeion) {
        FlutterMethodChannel *methodChannel = [FlutterMethodChannel methodChannelWithName:channelName binaryMessenger:binaryMessenger];
        [methodChannel setMethodCallHandler:^(FlutterMethodCall * _Nonnull call, FlutterResult  _Nonnull result) {
            completeion(call.method, call.arguments);
        }];
    }
}

- (void)sendFlutterMethodWithChannelName:(NSString *)channelName
                         binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger
                              methodName:(NSString *)methodName
                               arguments:(id)arguments
                             completeion:(nullable void (^)(id result))completeion {
    FlutterMethodChannel *methodChannel = [FlutterMethodChannel methodChannelWithName:channelName binaryMessenger:binaryMessenger];
    if (completeion) {
        [methodChannel invokeMethod:methodName arguments:arguments result:^(id  _Nullable result) {
            completeion(result);
        }];
    }
    else {
        [methodChannel invokeMethod:methodName arguments:arguments];
    }
}

- (void)reciveFlutterBasicMessageWithChannelName:(NSString *)channelName
                                 binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger
                                     completeion:(void (^)(id  _Nullable message))completeion {
    FlutterBasicMessageChannel *channel = [FlutterBasicMessageChannel messageChannelWithName:channelName binaryMessenger:binaryMessenger];
    [channel setMessageHandler:^(id  _Nullable message, FlutterReply  _Nonnull callback) {
        if (completeion) {
            completeion(message);
        }
    }];
}

- (void)sendFlutterBasicMessageWithChannelName:(NSString *)channelName
                                       message:(id)message
                                 binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger {
    FlutterBasicMessageChannel *channel = [FlutterBasicMessageChannel messageChannelWithName:channelName binaryMessenger:binaryMessenger];
    [channel sendMessage:message];
}

#pragma mark Private
- (instancetype)init {
    self = [super init];
    if (self) {
        _flutterVC = [[FlutterViewController alloc] initWithEngine:self.flutterEngine nibName:nil bundle:nil];
    }
    return self;
}

#pragma mark GET SET
- (FlutterEngine *)flutterEngine {
    if (!_flutterEngine) {
        FlutterEngine *engine = [[FlutterEngine alloc] initWithName:@"FlutterInvoke_FlutterEngine"];
        if ([engine run]) {
            _flutterEngine = engine;
        }
    }
    return _flutterEngine;
}

@end
