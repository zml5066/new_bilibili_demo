//
//  FlutterInvoke.h
//  Runner
//
//  Created by Robert on 2023/6/4.
//

#import <Foundation/Foundation.h>
#import <Flutter/Flutter.h>
NS_ASSUME_NONNULL_BEGIN

@interface FlutterInvoke : NSObject

@property (nonatomic, strong, readonly) FlutterViewController *flutterVC;

+ (instancetype)sharedInstance;


- (void)reciveFlutterMethodWithChannelName:(NSString *)channelName
                           binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger
                               completeion:(void (^)(NSString *methodName, id arguments))completeion;

- (void)sendFlutterMethodWithChannelName:(NSString *)channelName
                         binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger
                              methodName:(NSString *)methodName
                               arguments:(id)arguments
                             completeion:(nullable void (^)(id result))completeion;

- (void)reciveFlutterBasicMessageWithChannelName:(NSString *)channelName
                                 binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger
                                    completeion:(void (^)(id  _Nullable message))completeion;


- (void)sendFlutterBasicMessageWithChannelName:(NSString *)channelName
                                       message:(id)message
                               binaryMessenger:(NSObject<FlutterBinaryMessenger>*)binaryMessenger;
@end

NS_ASSUME_NONNULL_END
