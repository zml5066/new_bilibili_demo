package com.example.new_bilibili;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
