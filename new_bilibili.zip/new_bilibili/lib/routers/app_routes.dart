part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const main = _Paths.main;
  static const live = _Paths.live;
  static const home =  _Paths.home;
  static const dynamic =  _Paths.dynamic;
  static const purchase =  _Paths.purchase;
  static const me =  _Paths.me;
  static const liveChatRoom =  _Paths.liveChatRoom;
  static const videoPlayDetail =  _Paths.videoPlayDetail;
}

abstract class _Paths {
  static const main = '/main';
  static const live = '/live';
  static const home = '/home';
  static const dynamic = '/dynamic';
  static const purchase = '/purchase';
  static const me = '/me';
  static const liveChatRoom = '/liveChatRoom';
  static const videoPlayDetail = '/videoPlayDetail';
}
