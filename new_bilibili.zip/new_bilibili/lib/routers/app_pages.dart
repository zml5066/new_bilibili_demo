
import 'package:get/get.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:new_bilibili/modules/dynamic/bindings/dynamic_binding.dart';
import 'package:new_bilibili/modules/home/bindings/home_binding.dart';
import 'package:new_bilibili/modules/home/pages/home_page.dart';
import 'package:new_bilibili/modules/live/bindings/live_binding.dart';
import 'package:new_bilibili/modules/live/pages/live_page.dart';
import 'package:new_bilibili/modules/live_chat_rom/pages/live_chat_room_page.dart';
import 'package:new_bilibili/modules/me/bindings/me_binding.dart';
import 'package:new_bilibili/modules/me/pages/me_page.dart';
import 'package:new_bilibili/modules/purchase/bindings/purchase_binding.dart';
import 'package:new_bilibili/modules/purchase/pages/purchase_page.dart';

import '../main/main_binding.dart';
import '../main/main_page.dart';
import '../modules/dynamic/pages/dynamic_page.dart';
import '../modules/live_chat_rom/bindings/live_chat_room_binding.dart';
import '../modules/video_play_detail/bindings/video_play_detail_binding.dart';
import '../modules/video_play_detail/pages/video_play_detail_page.dart';

part 'app_routes.dart';
class AppPages {
  AppPages._();

  static const initial = Routes.main;
  static const live = Routes.live;
  static const home = Routes.home;
  static const dynamic = Routes.dynamic;
  static const purchase = Routes.purchase;
  static const me = Routes.me;
  static const liveChatRoom = Routes.liveChatRoom;
  static const videoPlayDetail = Routes.videoPlayDetail;

  static final routes = [
    GetPage(
      name: _Paths.main,
      page: () =>  MainPage(),
      binding: MainBinding(),
    ),
    GetPage(
      name: _Paths.live,
      page: () =>  LivePage(),
      binding: LiveBinding(),
    ),
    GetPage(
      name: _Paths.home,
      page: () =>  const HomePage(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: _Paths.dynamic,
      page: () => const DynamicPage(),
      binding: DynamicBinding(),
    ),
    GetPage(
      name: _Paths.purchase,
      page: () =>  const PurchasePage(),
      binding: PurchaseBinding(),
    ),
    GetPage(
      name: _Paths.me,
      page: () => const MePage(),
      binding: MeBinding(),
    ),
    GetPage(
      name: _Paths.liveChatRoom,
      page: () => const LiveChatRoomPage(),
      binding: LiveChatRoomBinding(),
    ),
    GetPage(
      name: _Paths.videoPlayDetail,
      page: () => const VideoPlayDetailPage(),
      binding: VideoPlayDetailBinding(),
    ),
  ];
}
