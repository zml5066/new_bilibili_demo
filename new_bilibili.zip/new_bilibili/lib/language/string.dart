
// ignore_for_file: constant_identifier_names

class I18nContent{
  static const String languageShow="简体";
  static const String title="哔哩哔哩";
  static const String BottomBarFirst="首页";
  static const String BottomBarSecond="动态";
  static const String BottomBarFourth="会员购";
  static const String BottomBarFifth="我";
}
