import 'package:get/get_navigation/src/root/internacionalization.dart';
import 'package:new_bilibili/language/string.dart';

class Messages extends Translations{
  @override
  Map<String, Map<String, String>> get keys => {
    //配置中文
    'zh_CN':{
      I18nContent.languageShow: "简体",
      I18nContent.title:"哔哩哔哩",
      I18nContent.BottomBarFirst:"首页",
      I18nContent.BottomBarSecond:"动态",
      I18nContent.BottomBarFourth:"会员购",
      I18nContent.BottomBarFifth:"我",
    },
    //配置英文
    'en_US':{
      I18nContent.languageShow: "English",
      I18nContent.title:"bilibili",
      I18nContent.BottomBarFirst:"Home",
      I18nContent.BottomBarSecond:"Dynamic",
      I18nContent.BottomBarFourth:"Purchase",
      I18nContent.BottomBarFifth:"Me",
    }
  };
}
