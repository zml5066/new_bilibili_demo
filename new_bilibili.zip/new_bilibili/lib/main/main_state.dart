import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:new_bilibili/routers/app_pages.dart';

class MainState {
  RxInt selectIndex;
  bool iszhCN;
  List<String> pages = [AppPages.home,AppPages.dynamic,AppPages.live,AppPages.purchase,AppPages.me,];
  MainState({required this.selectIndex,required this.iszhCN});
}
