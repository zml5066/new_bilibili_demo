import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/dynamic/bindings/dynamic_binding.dart';
import 'package:new_bilibili/modules/dynamic/pages/dynamic_page.dart';
import 'package:new_bilibili/modules/home/bindings/home_binding.dart';
import 'package:new_bilibili/modules/home/pages/home_page.dart';
import 'package:new_bilibili/modules/me/bindings/me_binding.dart';
import 'package:new_bilibili/modules/me/pages/me_page.dart';
import 'package:new_bilibili/modules/purchase/bindings/purchase_binding.dart';
import 'package:new_bilibili/modules/purchase/pages/purchase_page.dart';
import '../routers/app_pages.dart';
import 'main_state.dart';

class MainController extends GetxController {
  late MainState state = MainState(selectIndex: 0.obs, iszhCN: true);

  void changePage(int index) {
    state.selectIndex.value = index;
    Get.offNamed(state.pages[index], id: 1, preventDuplicates: false);
  }

  void changeLive() {
    Get.toNamed(AppPages.live);
}

  Route? onGenerateRoute(RouteSettings settings) {
    if (settings.name == AppPages.home) {
      return GetPageRoute(
          settings: settings,
          page: () => HomePage(),
          binding: HomeBinding(),
          transition: Transition.noTransition);
    }
    if (settings.name == AppPages.dynamic) {
      return GetPageRoute(
          settings: settings,
          page: () => const DynamicPage(),
          binding: DynamicBinding(),
          transition: Transition.noTransition);
    }
    if (settings.name == AppPages.purchase) {
      return GetPageRoute(
          settings: settings,
          page: () => const PurchasePage(),
          binding: PurchaseBinding(),
          transition: Transition.noTransition);
    }
    if (settings.name == AppPages.me) {
      return GetPageRoute(
          settings: settings,
          page: () => const MePage(),
          binding: MeBinding(),
          transition: Transition.noTransition);
    }
    return null;
  }
}
