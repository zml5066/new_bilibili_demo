// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/dynamic/pages/dynamic_page.dart';
import 'package:new_bilibili/modules/home/pages/home_page.dart';
import 'package:new_bilibili/modules/me/pages/me_page.dart';
import 'package:new_bilibili/modules/purchase/pages/purchase_page.dart';
import '../modules/live/pages/live_page.dart';
import '../routers/app_pages.dart';
import 'main_controller.dart';

class MainPage<Controller extends MainController> extends GetView<Controller> {
  MainPage({Key? key}) : super(key: key);
  List bodyPageList = [
    const HomePage(),
    const DynamicPage(),
     LivePage(),
    const PurchasePage(),
    const MePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Navigator(
          key: Get.nestedKey(1),
          initialRoute: AppPages.home,
          onGenerateRoute: controller.onGenerateRoute,
        ),
        bottomNavigationBar: Obx(() => BottomNavigationBar(
            currentIndex: controller.state.selectIndex.value,
            onTap: (int index) {
              if (index == 2) {
                controller.changeLive();
              } else {
                controller.changePage(index);
              }
            },
            selectedFontSize: 12.0,
            unselectedItemColor: Colors.grey,
            selectedItemColor: Colors.redAccent,
            type: BottomNavigationBarType.fixed,
            items: _createItems())));
  }

  List<BottomNavigationBarItem> _createItems() {
    return [
      BottomNavigationBarItem(
          icon: Container(
              margin: const EdgeInsets.only(top: 10),
              child: const Icon(Icons.home_filled, size: 30)),
          label: '首页'),
      BottomNavigationBarItem(
          icon: Container(
              margin: const EdgeInsets.only(top: 10),
              child: const Icon(Icons.cabin_rounded, size: 30)),
          label: '动态'),
      BottomNavigationBarItem(
          icon: Container(
              margin: const EdgeInsets.only(top: 20),
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6.0),
                  color: Colors.pinkAccent),
              child: const Icon(Icons.add, size: 30, color: Colors.white)),
          label: ''),
      BottomNavigationBarItem(
          icon: Container(
            margin: const EdgeInsets.only(top: 10),
            child: const Icon(Icons.shopping_bag_sharp, size: 30),
          ),
          label: '会员购'),
      BottomNavigationBarItem(
          icon: Container(
              margin: const EdgeInsets.only(top: 10),
              child: const Icon(Icons.people_alt, size: 30)),
          label: '我的'),
    ];
  }
}
