import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'language/messsage.dart';
import 'main/main_binding.dart';
import 'routers/app_pages.dart';
import 'utils/app_const/app_const.dart';
import 'utils/app_const/app_themes.dart';

void main() {
  runApp(const MyApp());
}

final navigatorKey =  GlobalKey();
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      navigatorKey: AppConst.navigatorKey,
      theme: lightTheme,
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.light,
      initialBinding: MainBinding(),
      initialRoute: AppPages.initial,
      getPages: AppPages.routes,
      translations: Messages(),
      locale: const Locale('zh', 'CN'),
      fallbackLocale: const Locale('zh', 'CN'),
      debugShowCheckedModeBanner: false,
    );
  }
}