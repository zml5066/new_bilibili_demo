
import 'dart:io';

import 'package:auto_orientation/auto_orientation.dart';
import 'package:brightness_volume/brightness_volume.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'app_video_state.dart';

typedef VideoPlayerStateFunc = void Function(AppVideoPlayState playState);

class AppVideoPlayer{
  ///************************ Public ************************///
  static void configVideoURL(String url)=> AppVideoPlayer.instance?._configVideoURL(url);

  static VideoPlayerController? getPlayerController(){
    return AppVideoPlayer.instance?._getPlayerController();
  }

  static Future<void>? getVideoPlayerFuture(){
    return  AppVideoPlayer.instance?._getVideoPlayerFuture();
  }

  static AppVideoPlayState? getPlayerState(){
    return AppVideoPlayer.instance?._getPlayerState();
  }

  static void getDefaultVolume (Function() callback){
    AppVideoPlayer.instance?._getDefaultVolume(callback);
  }

  static void addListenerState(VideoPlayerStateFunc stateFunc){
    AppVideoPlayer.instance?._listenerState(stateFunc);
  }
  static void play(){
    AppVideoPlayer.instance?._play();
  }

  static void pause(){
    AppVideoPlayer.instance?._pause();
  }

  static void stop(){
    AppVideoPlayer.instance?._stop();
  }

  static void seekTo(double value){
    AppVideoPlayer.instance?._seekTo(value);
  }

  static double? getSettingValue(AppVideoSettingType settingType){
   return AppVideoPlayer.instance?._getSettingValue(settingType);
  }

  // 获取音量
  static Future<double?> getVolume() async{
    return await AppVideoPlayer.instance?._getVolume();
  }

  // 设置音量
  static Future<void> setVolume(double volume,Function() callback) async{
    return await AppVideoPlayer.instance?._setVolume(volume,callback);
  }

  // 获取亮度
  static Future<double?> getBrightness() async{
    return await AppVideoPlayer.instance?._getBrightness();
  }

  // 设置亮度
  static Future<void> setBrightness(double brightness,Function() callback ) async{
    return await AppVideoPlayer.instance?._setBrightness(brightness, callback);
  }

  // 设置播放速度
  static Future<void> setSpeed(double speed,Function() callback) async{
    return AppVideoPlayer.instance?._setSpeed(speed, callback);
  }

  // 设置是否循环播放
  static Future<void> setLooping(bool looping) async{
    return AppVideoPlayer.instance?._setLooping(looping);
  }

  // 设置横屏
  static void setLandscape(){
    AppVideoPlayer.instance?._setLandscape();
  }

  // 设置竖屏
  static void setPortrait(){
    AppVideoPlayer.instance?._setPortrait();
  }

  // 简单处理下时间格式化mm:ss （超过1小时可自行处理hh:mm:ss）
  static String? formatDuration(int second){
    return AppVideoPlayer.instance?._formatDuration(second);
  }

  static void destoryData(){
    AppVideoPlayer.instance?._destoryData();
  }

  ///************************ Private ************************\\\
  factory AppVideoPlayer() => _getInstance()!;
  static AppVideoPlayer? get instance => _getInstance();
  static AppVideoPlayer? _instance;

  /// 变量
  late VideoPlayerController  _playerController;
  late Future<void>  videoPlayerFuture;
  late AppVideoPlayState  _playState;
  late String _videoURL;
  late VideoPlayerStateFunc _stateFunc;

  AppVideoPlayer._internal() {
    _initVideoData();
  }

  static AppVideoPlayer? _getInstance() {
    _instance ??= AppVideoPlayer._internal();
    return _instance;
  }

  void _configVideoURL(String url){
    _videoURL = url;
    _videoLoad();
  }

  VideoPlayerController _getPlayerController(){
    return _playerController;
  }

  Future<void> _getVideoPlayerFuture(){
    return videoPlayerFuture;
  }

  AppVideoPlayState _getPlayerState(){
    return _playState;
  }

  void _listenerState(VideoPlayerStateFunc stateFunc){
    _stateFunc = stateFunc;
  }

  void _play(){
    _playState.resetState();
    _playState.playerState = AppVideoPlayerState.playing;
    _playerController.play();
  }

  void _pause(){
    _playState.playerState = AppVideoPlayerState.paused;
    _playerController.pause();
    _stateFunc(_playState);
  }

  void _stop(){
    _playState.playerState = AppVideoPlayerState.stopped;
    _playerController.pause();
    _stateFunc(_playState);
  }

  void _seekTo(double value){
    _playerController.seekTo(Duration(seconds: value.toInt()));
    _playerController.play();
  }

  double _getSettingValue(AppVideoSettingType settingType){
    if (settingType == AppVideoSettingType.appVideoSettingTypeVolume){
      return _playState.volumeValue;
    }
    else if (settingType == AppVideoSettingType.appVideoSettingTypeBrightness){
      return _playState.brightnessValue;
    }
    else if (settingType == AppVideoSettingType.appVideoSettingTypeSpeed){
      return _playState.speedValue;
    }
    return 0.0;
  }

  // 获取音量
  Future<double> _getVolume() async{
    return await BVUtils.volume;
  }

  // 设置音量
  Future<void> _setVolume(double volume,Function() callback) async{
    _playState.volumeValue = volume / 1.0;
    callback();
    return await BVUtils.setVolume(_playState.volumeValue);
  }

  // 获取亮度
  Future<double> _getBrightness() async{
    return await BVUtils.brightness;
  }

  // 设置亮度
  Future<void> _setBrightness(double brightness,Function() callback) async{
    _playState.brightnessValue = brightness / 1.0;
    callback();
    return await BVUtils.setBrightness(_playState.brightnessValue);
  }

  // 设置播放速度
  Future<void> _setSpeed(double speed,Function() callback) async{
    _playState.speedValue = speed / 1.0;
    callback();
    return _playerController.setPlaybackSpeed(speed);
  }

  // 设置是否循环播放
  Future<void> _setLooping(bool looping) async{
    return _playerController.setLooping(looping);
  }

  // 设置横屏
  void _setLandscape(){
    AutoOrientation.landscapeAutoMode();
    // iOS13+横屏时，状态栏自动隐藏，可自定义：https://juejin.cn/post/7054063406579449863
    if(Platform.isAndroid){
      ///关闭状态栏，与底部虚拟操作按钮
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    }
  }

  // 设置竖屏
  void _setPortrait(){
    AutoOrientation.portraitAutoMode();
    if(Platform.isAndroid){
      ///显示状态栏，与底部虚拟操作按钮
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
          overlays: [SystemUiOverlay.top, SystemUiOverlay.bottom]);
    }
  }

  // 简单处理下时间格式化mm:ss （超过1小时可自行处理hh:mm:ss）
   String _formatDuration(int second){
    int min = second ~/ 60;
    int sec = second % 60;
    String minString = min < 10 ? "0$min" : min.toString();
    String secString = sec < 10 ? "0$sec" : sec.toString();
    return "$minString:$secString";
  }

  void _destoryData(){
    _playerController.removeListener(() { });
    _playerController.dispose();
  }

  _videoLoad() async{
    _playerController = VideoPlayerController.networkUrl(Uri.parse(_videoURL));
    videoPlayerFuture = _playerController.initialize();
    _playerController.addListener(_videoStatusListener);
  }

  /// 监听视频播放进度的方法
  _videoStatusListener(){
    var curPosition = _playerController.value.position;
    var totalPosition = _playerController.value.duration;
    _playState.curPosStr = curPosition.toString().substring(2, 7);
    _playState.totalDurationStr = totalPosition.toString().substring(2, 7);
    _playState.curPos = (_playerController.value.position.inHours * 3600 +
        _playerController.value.position.inMinutes * 60 +
        _playerController.value.position.inSeconds).toDouble();
    _playState.totalDuration = (_playerController.value.duration.inHours * 3600 +
        _playerController.value.duration.inMinutes * 60 +
        _playerController.value.duration.inSeconds).toDouble();
    if(_playState.curPos!= 0.0 && _playState.curPos == _playState.totalDuration){
      _stop();
    }
    _stateFunc(_playState);
  }

  void _getDefaultVolume (Function() callback)async{
    _playState.volumeValue = await _getVolume();
    _playState.brightnessValue = await _getBrightness();
    callback();
  }

  _initVideoData(){
    _playState = AppVideoPlayState(displayState: AppVideoDisplayState.appVideoDisplayNormal);
  }
}