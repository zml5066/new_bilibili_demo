/// 播放状态枚举
enum AppVideoPlayerState {
  stopped, // 初始状态，已停止或发生错误
  playing, // 正在播放
  paused, // 暂停
  completed // 播放结束
}

/// 视频显示状态
enum AppVideoDisplayState {
  appVideoDisplayNormal, // 默认状态（竖屏未全屏状态）
  appVideoDisplayVertical, // 竖屏全屏状态）
  appVideoDisplayLandscape, // 横屏状态
}

/// 播放状态枚举
enum AppVideoSettingType {
  appVideoSettingTypeVolume, //音量设置
  appVideoSettingTypeBrightness, // 亮度设置
  appVideoSettingTypeSpeed //速度
}

class AppVideoPlayState {
  late String curPosStr;
  late String totalDurationStr;
  late double curPos;
  late double totalDuration;
  late AppVideoPlayerState playerState;
  late AppVideoDisplayState displayState;
  late double volumeValue;
  late double brightnessValue;
  late double speedValue;

  AppVideoPlayState(
      {this.curPosStr = '0.0',
      this.totalDurationStr = '0.0',
      this.curPos = 0.0,
      this.totalDuration = 0.0,
      this.playerState = AppVideoPlayerState.stopped,
      this.displayState = AppVideoDisplayState.appVideoDisplayNormal,
      this.volumeValue = 0.0,
      this.brightnessValue = 0.0,
      this.speedValue = 0.0});

  resetState() {
    curPosStr = '0.0';
    totalDurationStr = '0.0';
    curPos = 0.0;
    totalDuration = 0.0;
    playerState = AppVideoPlayerState.stopped;
  }
}
