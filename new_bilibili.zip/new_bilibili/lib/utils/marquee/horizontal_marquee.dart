import 'package:flutter/material.dart';

class HorizontalMarquee extends StatefulWidget {
  final Widget child;
  final int speed;
  const HorizontalMarquee({super.key, required this.child, this.speed = 100});
  @override
  State<HorizontalMarquee> createState() => _HorizontalMarqueeState();
}

class _HorizontalMarqueeState extends State<HorizontalMarquee>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  late ScrollController _scrollController;
  SingleChildScrollView? _scrollView;
  double _space = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _scrollController = ScrollController();
    _animationController = AnimationController(
        vsync: this, duration: Duration(milliseconds: widget.speed));
    _animation = Tween(
      begin: 0.1,
      end: 100.0,
    ).animate(_animationController);
    _animation.addListener(() {
      if (_scrollController.hasClients) {
        if (_scrollView != null &&
            _scrollController.position.hasContentDimensions) {
          var index = _animation.value / 100;
          _scrollController.jumpTo(index * _scrollController.position.maxScrollExtent);
        }
        if (_scrollController.position.hasViewportDimension && _space == 0) {
          setState(() {
            _space = _scrollController.position.viewportDimension;
          });
        }
      }
    });
    _animationController.repeat();
  }

  @override
  Widget build(BuildContext context) {
    _scrollView = SingleChildScrollView(
      controller: _scrollController,
      scrollDirection: Axis.horizontal,
      child: _scrollController.hasClients
          ? Row(
              children: [
                SizedBox(
                  width: _space,
                ),
                widget.child,
                SizedBox(
                  width: _space,
                ),
              ],
            )
          : const SizedBox(),
    );
    return _scrollView ?? const Column();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}
