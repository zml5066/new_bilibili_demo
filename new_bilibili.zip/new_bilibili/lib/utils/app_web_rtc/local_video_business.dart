// ignore_for_file: depend_on_referenced_packages

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';
import 'package:new_bilibili/utils/app_web_rtc/video_size.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:core';
import 'package:collection/collection.dart';


class LocalVideoBusiness {
  late bool inCalling;
  late String? selectedVideoFPS;
  late VideoSize selectedVideoSize;
  String? selectedVideoInputId;
  String? selectedAudioInputId;
  final Function() updateCallback;
  final Function(MediaStream? stream) streamCallback;

  late List<MediaDeviceInfo> devices = [];
  MediaStream? localStream;
  late RTCVideoRenderer localRenderer;
  late RTCVideoRenderer remoteRenderer;
  RTCPeerConnection? pc1;
  // RTCPeerConnection? pc2;
  late List<RTCRtpSender>senders;
  var _speakerphoneOn = false;

  LocalVideoBusiness({required this.updateCallback, required this.streamCallback}){
    inCalling = false;
    selectedVideoFPS = '30';
    selectedVideoSize = VideoSize(1280, 720);
    devices = [];
    localRenderer = RTCVideoRenderer();
    remoteRenderer = RTCVideoRenderer();
    senders = <RTCRtpSender>[];
  }

  void readyLocalVideo(){
    _initRenderers();
    _loadDevices();
    navigator.mediaDevices.ondevicechange = (event) {
      _loadDevices();
    };
  }

  Future<void> initPCs() async {
    // pc2 ??= await createPeerConnection({});
    // pc1 ??= await createPeerConnection({});
    //
    // pc2?.onTrack = (event) {
    //   if (event.track.kind == 'video') {
    //     remoteRenderer.srcObject = event.streams[0];
    //     updateCallback();
    //   }
    // };
    //
    // pc2?.onConnectionState = (state) {
    //   AppConst.rrPrint('connectionState $state');
    // };
    //
    // pc2?.onIceConnectionState = (state) {
    //   AppConst.rrPrint('iceConnectionState $state');
    // };
    //
    // await pc2?.addTransceiver(
    //     kind: RTCRtpMediaType.RTCRtpMediaTypeAudio,
    //     init: RTCRtpTransceiverInit(direction: TransceiverDirection.RecvOnly));
    // await pc2?.addTransceiver(
    //     kind: RTCRtpMediaType.RTCRtpMediaTypeVideo,
    //     init: RTCRtpTransceiverInit(direction: TransceiverDirection.RecvOnly));
    //
    // pc1!.onIceCandidate = (candidate) => pc2!.addCandidate(candidate);
    // pc2!.onIceCandidate = (candidate) => pc1!.addCandidate(candidate);
  }

  Future<void> start() async {
    try {
      localStream = await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': {
          if (selectedVideoInputId != null && kIsWeb)
            'deviceId': selectedVideoInputId,
          if (selectedVideoInputId != null && !kIsWeb)
            'optional': [
              {'sourceId': selectedVideoInputId}
            ],
          'width': selectedVideoSize.width,
          'height': selectedVideoSize.height,
          'frameRate': selectedVideoFPS,
        },
      });
      localRenderer.srcObject = localStream;
      remoteRenderer.srcObject = localRenderer.srcObject;
      inCalling = true;

      await initPCs();

      // localStream?.getTracks().forEach((track) async {
      //   var rtpSender = await pc1?.addTrack(track, localStream!);
      //   AppConst.rrPrint('track.settings ${track.getSettings()}');
      //   senders.add(rtpSender!);
      // });

      await _negotiate();
      updateCallback();
    } catch (e) {
      AppConst.rrPrint(e.toString());
    }
  }

  Future<void>stop() async {
    try {
      localStream?.getTracks().forEach((track) async {
        await track.stop();
      });
      await localStream?.dispose();
      localStream = null;
      localRenderer.srcObject = null;
      remoteRenderer.srcObject = null;
      senders.clear();
      inCalling = false;
      await stopPCs();
      _speakerphoneOn = false;
      await Helper.setSpeakerphoneOn(_speakerphoneOn);
      updateCallback();
    } catch (e) {
      AppConst.rrPrint(e.toString());
    }
  }

  Future<void> stopPCs() async {
    await pc1?.close();
    // await pc2?.close();
    pc1 = null;
    // pc2 = null;
  }

  Future<void> selectVideoFps(String fps) async {
    selectedVideoFPS = fps;
    if (!inCalling) {
      return;
    }
    await selectVideoInput(selectedVideoInputId);
    updateCallback();
  }

  Future<void> selectVideoSize(String size) async {
    selectedVideoSize = VideoSize.fromString(size);
    if (!inCalling) {
      return;
    }
    await selectVideoInput(selectedVideoInputId);
    updateCallback();
  }

  Future<void> selectAudioInput(String? deviceId) async {
    selectedAudioInputId = deviceId;
    if (!inCalling) {
      return;
    }

    var newLocalStream = await navigator.mediaDevices.getUserMedia({
      'audio': {
        if (selectedAudioInputId != null && kIsWeb)
          'deviceId': selectedAudioInputId,
        if (selectedAudioInputId != null && !kIsWeb)
          'optional': [
            {'sourceId': selectedAudioInputId}
          ],
      },
      'video': false,
    });
    var newTrack = newLocalStream.getAudioTracks().first;
    AppConst.rrPrint('track.settings ${newTrack.getSettings()}');
    var sender = senders.firstWhereOrNull((sender) => sender.track?.kind == 'audio');
    await sender?.replaceTrack(newTrack);
  }

  Future<void> selectAudioOutput(String? deviceId) async {
    if (!inCalling) {
      return;
    }
    await localRenderer.audioOutput(deviceId!);
  }

  Future<void> setSpeakerphoneOn() async {
    _speakerphoneOn = !_speakerphoneOn;
    await Helper.setSpeakerphoneOn(_speakerphoneOn);
    updateCallback();
  }

  Future<void> selectVideoInput(String? deviceId) async {
    selectedVideoInputId = deviceId;
    if (!inCalling) {
      return;
    }
    localRenderer.srcObject = null;

    localStream?.getTracks().forEach((track) async {
      await track.stop();
    });
    await localStream?.dispose();

    var newLocalStream = await navigator.mediaDevices.getUserMedia({
      'audio': false,
      'video': {
        if (selectedVideoInputId != null && kIsWeb)
          'deviceId': selectedVideoInputId,
        if (selectedVideoInputId != null && !kIsWeb)
          'optional': [
            {'sourceId': selectedVideoInputId}
          ],
        'width': selectedVideoSize.width,
        'height': selectedVideoSize.height,
        'frameRate': selectedVideoFPS,
      },
    });
    localStream = newLocalStream;
    localRenderer.srcObject = localStream;
    var newTrack = localStream?.getVideoTracks().first;
    AppConst.rrPrint('track.settings ${newTrack!.getSettings()}');
    var sender =
    senders.firstWhereOrNull((sender) => sender.track?.kind == 'video');
    var params = sender!.parameters;
    AppConst.rrPrint('params degradationPreference${params.degradationPreference}');
    params.degradationPreference = RTCDegradationPreference.MAINTAIN_RESOLUTION;
    await sender.setParameters(params);
    await sender.replaceTrack(newTrack);
  }

  void destoryData(){
    stop();
    localRenderer.dispose();
    remoteRenderer.dispose();
    navigator.mediaDevices.ondevicechange = null;
  }

  Future<void> _initRenderers() async {
    await localRenderer.initialize();
    await remoteRenderer.initialize();
  }

  Future<void> _loadDevices() async {
    if (WebRTC.platformIsAndroid || WebRTC.platformIsIOS) {
      var status = await Permission.bluetooth.request();
      if (status.isPermanentlyDenied) {
        AppConst.rrPrint('BLEpermdisabled');
      }

      status = await Permission.bluetoothConnect.request();
      if (status.isPermanentlyDenied) {
        AppConst.rrPrint('ConnectPermdisabled');
      }
    }
    devices = await navigator.mediaDevices.enumerateDevices();;
    updateCallback();
  }

  Future<void> _negotiate() async {
    var offer = await pc1?.createOffer();
    await pc1?.setLocalDescription(offer!);
    // await pc2?.setRemoteDescription(offer!);
    // var answer = await pc2?.createAnswer();
    // await pc2?.setLocalDescription(answer!);
    // await pc1?.setRemoteDescription(answer!);
  }

  List<MediaDeviceInfo> get audioInputs =>
      devices.where((device) => device.kind == 'audioinput').toList();

  List<MediaDeviceInfo> get audioOutputs =>
      devices.where((device) => device.kind == 'audiooutput').toList();

  List<MediaDeviceInfo> get videoInputs =>
      devices.where((device) => device.kind == 'videoinput').toList();

  MediaDeviceInfo get selectedAudioInput => audioInputs.firstWhere(
          (device) => device.deviceId == selectedVideoInputId,
      orElse: () => audioInputs.first);
}
