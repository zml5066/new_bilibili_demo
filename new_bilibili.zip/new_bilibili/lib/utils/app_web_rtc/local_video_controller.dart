
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:get/get.dart';

import 'local_video_business.dart';

class LocalVideoController extends GetxController{

  late  Rx<LocalVideoBusiness> localVideoBusiness;

  void initData(){
    localVideoBusiness = LocalVideoBusiness(updateCallback: (){

    }, streamCallback: (MediaStream? stream){

    }).obs;
    localVideoBusiness.value.readyLocalVideo();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    initData();
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
    localVideoBusiness.value.destoryData();
  }
}