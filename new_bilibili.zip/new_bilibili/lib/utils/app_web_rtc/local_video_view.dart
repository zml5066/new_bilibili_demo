import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_web_rtc/local_video_controller.dart';

class LocalVideoView<Controller extends LocalVideoController> extends GetView<Controller> {
  const LocalVideoView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Container(
        margin: const EdgeInsets.only(top: 100),
        width: 200,
        height: 200,
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              color: Colors.pinkAccent,
              width: 100,height: 50,
              child:  RTCVideoView(controller.localVideoBusiness.value.localRenderer),
            ),
            SizedBox(height: 20),
            Container(
              color: Colors.pinkAccent,
              width: 100,height: 50,
              child:  RTCVideoView(controller.localVideoBusiness.value.remoteRenderer),
            ),
            Container(
             width: 30,height: 30,
             child:  GestureDetector(
               onTap: () => controller.localVideoBusiness.value.inCalling
                   ? controller.localVideoBusiness.value.stop()
                   : controller.localVideoBusiness.value.start(),
               child:
               Icon(controller.localVideoBusiness.value.inCalling ? Icons.call_end : Icons.phone),
             ),
           )
          ],
        ),
      );
    });
  }
}

//
// class LocalVideoView<Controller extends LocalVideoController> extends GetView<Controller> {
//   const LocalVideoView({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Obx(() {
//       return Container(
//         margin: const EdgeInsets.all(0),
//         alignment: Alignment.center,
//         child:RTCVideoView(controller.localVideoBusiness.value.localRenderer),
//       );
//     });
//   }
// }
