import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

abstract class AppConst {
  /// 屏幕宽(注意是dp)转换px 需要 screenWidth * pixelRatio)
  static  double screenWidth(BuildContext context) => MediaQuery.of(context).size.width;
  /// 屏幕高(注意是dp)
  static double screenHeight(BuildContext context) => MediaQuery.of(context).size.height;
  /// 底部功能栏, 类似于iPhone XR 底部安全区域
  static double bottomBarHeight(BuildContext context) => MediaQuery.of(context).padding.bottom;
  /// 顶部状态栏, 随着刘海屏会增高
  static double statusBarHeight(BuildContext context) => MediaQuery.of(context).padding.top;
  /// 屏幕密度
  static double devicePixelRatio(BuildContext context) => MediaQuery.of(context).devicePixelRatio;
  /// 键盘高度
  static double keyboardHeight(BuildContext context) => MediaQuery.of(context).viewInsets.bottom;

  static double toolbarHeight(BuildContext context)=>statusBarHeight(context) + kToolbarHeight / 2;

  /// 打印
  static rrPrint(dynamic a){if (kDebugMode) { print(a);}}

  static GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static BuildContext? appContext() {
    return navigatorKey.currentState?.context;
  }
}