import 'package:dio/dio.dart';

class NetworkError {
  final int? code;
  final String? msg;
  NetworkError({this.code, this.msg});
}

class AppResponse {
  final dynamic data;
  final NetworkError? error;
  AppResponse(this.data, {this.error});
}

class AppNetwork {
  factory AppNetwork() => _getInstance()!;
  static AppNetwork? get instance => _getInstance();
  static AppNetwork? _instance;
  AppNetwork._internal() {
    _configureDio();
  }
  static AppNetwork? _getInstance() {
    _instance ??= AppNetwork._internal();
    return _instance;
  }

  Future<Response> get(String url, {Map<String, dynamic>? queryParameters}) async {
    Future<Response> future = _dio.get(url, queryParameters: queryParameters);
    future.then((value) {
      if (value.statusCode == 200){
        return value;
      }
      else {
        throw Exception(NetworkError(code:value.statusCode,msg:'网络异常'));
      }
    });
    future.catchError((e){
      throw Exception(NetworkError(code:10001,msg:'接口请求异常'));
    });
    return future;
  }

  Future<Response> post(String url, {dynamic data}) async {
    Future<Response> future = _dio.post(url, data: data);
    future.then((value) {
      if (value.statusCode == 200){
        return value;
      }
      else {
        throw Exception(NetworkError(code:value.statusCode,msg:'网络异常'));
      }
    });
    future.catchError((e){
      throw Exception(NetworkError(code:10001,msg:'接口请求异常'));
    });
    return future;
  }

  final _dio = Dio();
  /// 私有方法
  void _configureDio() {
    _dio.options.baseUrl = 'http://rap2api.taobao.org/app/mock/312489';
    _dio.options.connectTimeout = const Duration(seconds: 15);
    _dio.options.receiveTimeout = const Duration(seconds: 30);
  }
}