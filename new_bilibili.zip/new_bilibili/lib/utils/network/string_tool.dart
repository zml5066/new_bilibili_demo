import 'package:flutter/cupertino.dart';

class StringTool {

  static String skipLastChar(String text) {
    return text.characters.skipLast(1).toString();
  }
}