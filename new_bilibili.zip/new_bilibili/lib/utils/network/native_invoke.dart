
import 'package:flutter/services.dart';

enum NativeInvokeType{
  nativeInvokeTypeAlbum,
  nativeInvokeTypeCamera,
  nativeInvokeTypeAlbumPath,
}

const String nativeInvokeTypeAlbum = 'nativeInvokeTypeAlbum';
const String nativeInvokeTypeCamera = 'nativeInvokeTypeCamera';
const String nativeInvokeTypeAlbumPath = 'nativeInvokeTypeAlbumPath';

extension NativeInvokeMethodStr on NativeInvokeType {
  String get value {
    switch (this) {
      case NativeInvokeType.nativeInvokeTypeAlbum:
        return nativeInvokeTypeAlbum;
      case NativeInvokeType.nativeInvokeTypeCamera:
        return nativeInvokeTypeCamera;
      case NativeInvokeType.nativeInvokeTypeAlbumPath:
        return nativeInvokeTypeAlbumPath;
      default:
        return '';
    }
  }
}



class NativeInvoke {
  factory NativeInvoke() => _getInstance()!;
  static NativeInvoke? get instance => _getInstance();
  static NativeInvoke? _instance;
  MethodChannel platformChannel = const MethodChannel('samples.flutter.dev/wechat');

  NativeInvoke._internal() {
    platformChannel = const MethodChannel('samples.flutter.dev/wechat');
  }
  static NativeInvoke? _getInstance() {
    _instance ??= NativeInvoke._internal();
    return _instance;
  }

  /// 调用原生方法
  void callNativeInvoke(NativeInvokeType type) {
    platformChannel.invokeMapMethod(type.value);
  }

 /// 监听原生方法回调
  void listenerNativeInvokeCall(NativeInvokeType type,  {required Null Function(dynamic data) callback}) async {
    Future<dynamic> platformCallHandler(MethodCall call) async {
      switch (call.method) {
        case nativeInvokeTypeAlbumPath:
          callback(call.arguments);
          return type.value;
      }
    }
     platformChannel.setMethodCallHandler(platformCallHandler);
  }
}