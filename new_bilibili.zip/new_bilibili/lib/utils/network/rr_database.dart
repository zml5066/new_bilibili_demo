
class RRDatabase {

}