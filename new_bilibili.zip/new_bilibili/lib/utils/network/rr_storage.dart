import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
class RRStorage {
  factory RRStorage() => _getInstance()!;
  static RRStorage? get instance => _getInstance();
  static RRStorage? _instance;
  static SharedPreferences? _storage;

  RRStorage._internal() {
    _initStorage();
  }

  static RRStorage? _getInstance() {
    _instance ??= RRStorage._internal();
    return _instance;
  }
  _initStorage() async {
    _storage ??= await SharedPreferences.getInstance();
  }

  setStorage(String key, dynamic value) async {
    await _initStorage();
    String type;
    // 判断类型
    if(value is Map || value is List){
      type = 'String';
      value = const JsonEncoder().convert(value);
    }
    else {
      type = value.runtimeType.toString();
    }
    switch (type) {
      case 'String':
        _storage?.setString(key, value);
        break;
      case 'int':
        _storage?.setInt(key, value);
        break;
      case 'double':
        _storage?.setInt(key, value);
        break;
      case 'bool':
        _storage?.setInt(key, value);
        break;
    }
  }

  Future<dynamic> getStorage(String key) async{
    await _initStorage();
    dynamic value = _storage?.get(key);
    if(_isJson(value)){
      return const JsonDecoder().convert(value);
    }
    else {
      return value;
    }
  }

  Future<bool?> hasKey(String key) async {
    await _initStorage();
    return _storage?.containsKey(key);
  }

  Future<bool?> removeStorage(String key) async {
    await _initStorage();
    if ((await hasKey(key))!){
      await _storage?.remove(key);
      return true;
    }
    return false;
  }

  Future<bool> clearStore()async {
    await _initStorage();
    _storage?.clear();
    return true;
  }

  Future<Set<String>?> getKeys()async {
    await _initStorage();
    return _storage?.getKeys();
  }

  _isJson(dynamic value) {
    try{
      const JsonDecoder().convert(value);
      return true;
    }
    catch(e) {
      return false;
    }
  }

}