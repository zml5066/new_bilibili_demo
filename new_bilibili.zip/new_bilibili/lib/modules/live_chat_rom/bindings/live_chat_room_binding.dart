import 'package:get/get.dart';
import '../controllers/chat_gift_controller.dart';
import '../controllers/chat_input_controller.dart';
import '../controllers/chat_room_bottom_controller.dart';
import '../controllers/chat_room_list_controller.dart';
import '../controllers/live_chat_room_controller.dart';

class LiveChatRoomBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LiveChatRoomController>( () => LiveChatRoomController());
    Get.lazyPut<ChatRoomListController>( () => ChatRoomListController());
    Get.lazyPut<ChatRoomBottomController>( () => ChatRoomBottomController());
    Get.lazyPut<ChatInputController>( () => ChatInputController());
    Get.lazyPut<ChatGiftController>( () => ChatGiftController());
  }
}