
import 'package:get/get.dart';

enum ChatInputEventType {
  chatInputEventTypeUndefined,
  chatInputEventTypeEmoji,// 表情按钮
  chatInputEventTypeCurtain, //弹幕设置
  chatInputEventTypeSend,// 发送
}


class ChatKeyboardState{
  RxBool isExpanded;
  RxBool isEmojiKeyboard;
  RxBool fieldHaveText;
  ChatInputEventType eventType;

  ChatKeyboardState({
    required this.isExpanded,
    required this.isEmojiKeyboard,
    required this.fieldHaveText,
    this.eventType=ChatInputEventType.chatInputEventTypeUndefined});
}