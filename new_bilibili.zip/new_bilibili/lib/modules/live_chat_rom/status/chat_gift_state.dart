
import 'package:get/get_rx/src/rx_types/rx_types.dart';

class ChatGiftState {
  RxBool isExpanded;
  ChatGiftState({required this.isExpanded,});
}