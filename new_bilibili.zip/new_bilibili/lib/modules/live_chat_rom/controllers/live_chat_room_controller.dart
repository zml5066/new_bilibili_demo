import 'package:get/get.dart';
import '../../../utils/app_const/app_const.dart';
import '../../../utils/app_const/app_toast.dart';
import '../../home/models/chasing_cell_model.dart';
import '../models/anchor_info_model.dart';
import '../models/anchor_rank_model.dart';

class LiveChatRoomController extends GetxController {
  late ChasingCellModel dataModel;
  late AnchorInfoModel anchorInfoModel;
  late AnchorRankModel anchorRankModel;

  @override
  void onInit() {
    super.onInit();
    dataModel = Get.arguments;
    AppConst.rrPrint(dataModel.title);
    anchorInfoModel = _defaultAnchorInfoModel();
    anchorRankModel = _defaultAnchorRankModel();
  }

  void goBack() {
    Get.back();
  }

  void openMoreSet() {}

  void attentionAnchor(){
    AppToast.toast('关注');
    anchorInfoModel.isAttention.value = !anchorInfoModel.isAttention.value;
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
    AppConst.rrPrint('onClose');
  }

  AnchorInfoModel _defaultAnchorInfoModel() {
    return AnchorInfoModel(
        avatarUrl: 'https://randomuser.me/api/portraits/men/48.jpg',
        anchorName: '阿妙影视',
        isAttention: true.obs,
        watchNum: 1000.obs);
  }

  AnchorRankModel _defaultAnchorRankModel() {
    return AnchorRankModel(
      rankAvatarUrls: RxList(
        [
          'https://randomuser.me/api/portraits/men/50.jpg',
          'https://randomuser.me/api/portraits/men/51.jpg',
          'https://randomuser.me/api/portraits/men/52.jpg'
        ],
      ),
      onlineNum: 121.obs,
    );
  }
}
