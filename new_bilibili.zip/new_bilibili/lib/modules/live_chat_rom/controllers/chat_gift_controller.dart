import 'package:get/get.dart';
import '../../../utils/app_const/app_const.dart';
import '../models/chat_gift_model.dart';
import '../status/chat_gift_state.dart';

class ChatGiftController extends GetxController {

  late RxList<ChatGiftModel> giftList;
  late ChatGiftState giftState;

  void initData(){
    giftList = _defaultGiftList();
    giftState = ChatGiftState(isExpanded: false.obs);
  }

  void showGiftList(bool show){
    giftState.isExpanded.value = show;
  }

  void selectedGift(ChatGiftModel dataModel){
    if (dataModel.selected.value) {
      AppConst.rrPrint('送${dataModel.giftName}礼物');
    }
    else {
      for (int i = 0; i < giftList.length; i++) {
        ChatGiftModel giftModel = giftList[i];
        if (giftModel.giftName ==
            dataModel.giftName) {
          giftModel.selected.value = true;
        } else {
          giftModel.selected.value = false;
        }
      }
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    initData();
  }

  @override
  void onClose() {
    super.onClose();
  }

  RxList<ChatGiftModel> _defaultGiftList(){
    return RxList<ChatGiftModel>([
      ChatGiftModel(giftImage: '给代打的礼物'.obs, giftName: '给代打的礼物'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:2.obs,selected: true.obs),
      ChatGiftModel(giftImage: '泡泡机'.obs, giftName: '泡泡机'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:3.obs,selected: false.obs),
      ChatGiftModel(giftImage: '一箭倾心'.obs, giftName: '一箭倾心'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:4.obs,selected: false.obs),
      ChatGiftModel(giftImage: '红叶大道'.obs, giftName: '红叶大道'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:5.obs,selected: false.obs),
      ChatGiftModel(giftImage: '奇幻之城'.obs, giftName: '奇幻之城'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:6.obs,selected: false.obs),
      ChatGiftModel(giftImage: '贤者戒指'.obs, giftName: '贤者戒指'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:7.obs,selected: false.obs),
      ChatGiftModel(giftImage: '暮光女神'.obs, giftName: '暮光女神'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:8.obs,selected: false.obs),
      ChatGiftModel(giftImage: '开车车'.obs, giftName: '开车车'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:9.obs,selected: false.obs),
      ChatGiftModel(giftImage: '时砾约定'.obs, giftName: '时砾约定'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:10.obs,selected: false.obs),
      ChatGiftModel(giftImage: '次元之城'.obs, giftName: '次元之城'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:11.obs,selected: false.obs),
      ChatGiftModel(giftImage: '金币'.obs, giftName: '金币'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:12.obs,selected: false.obs),
      ChatGiftModel(giftImage: '82年红酒'.obs, giftName: '82年红酒'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:13.obs,selected: false.obs),
      ChatGiftModel(giftImage: '灯塔'.obs, giftName: '灯塔'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:14.obs,selected: false.obs),
      ChatGiftModel(giftImage: '美满'.obs, giftName: '美满'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:15.obs,selected: false.obs),
      ChatGiftModel(giftImage: '极速超跑'.obs, giftName: '极速超跑'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:16.obs,selected: false.obs),
      ChatGiftModel(giftImage: '灵魂歌姬'.obs, giftName: '灵魂歌姬'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:17.obs,selected: false.obs),
      ChatGiftModel(giftImage: '荧光马车'.obs, giftName: '荧光马车'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:18.obs,selected: false.obs),
      ChatGiftModel(giftImage: '圣诞精灵'.obs, giftName: '圣诞精灵'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:19.obs,selected: false.obs),
      ChatGiftModel(giftImage: 'IVL冲冲冲'.obs, giftName: 'IVL冲冲冲'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:20.obs,selected: false.obs),
      ChatGiftModel(giftImage: '聆听'.obs, giftName: '聆听'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:21.obs,selected: false.obs),
      ChatGiftModel(giftImage: '玲珑福袋'.obs, giftName: '玲珑福袋'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:22.obs,selected: false.obs),
      ChatGiftModel(giftImage: '戒指糖'.obs, giftName: '戒指糖'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:23.obs,selected: false.obs),
      ChatGiftModel(giftImage: '如意小香包'.obs, giftName: '如意小香包'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:24.obs,selected: false.obs),
      ChatGiftModel(giftImage: '时光沙漏'.obs, giftName: '时光沙漏'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:25.obs,selected: false.obs),
      ChatGiftModel(giftImage: '守护之翼'.obs, giftName: '守护之翼'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:26.obs,selected: false.obs),
      ChatGiftModel(giftImage: '咕咕卡'.obs, giftName: '咕咕卡'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:27.obs,selected: false.obs),
      ChatGiftModel(giftImage: '铃兰花'.obs, giftName: '铃兰花'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:28.obs,selected: false.obs),
      ChatGiftModel(giftImage: '天空之翼'.obs, giftName: '天空之翼'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:29.obs,selected: false.obs),
      ChatGiftModel(giftImage: '小蛋糕'.obs, giftName: '小蛋糕'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:30.obs,selected: false.obs),
      ChatGiftModel(giftImage: '么么'.obs, giftName: '么么'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:31.obs,selected: false.obs),
      ChatGiftModel(giftImage: '嗨翻全场'.obs, giftName: '嗨翻全场'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:32.obs,selected: false.obs),
      ChatGiftModel(giftImage: '探索者启航'.obs, giftName: '探索者启航'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:33.obs,selected: false.obs),
      ChatGiftModel(giftImage: '闪耀R星'.obs, giftName: '闪耀R星'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:34.obs,selected: false.obs),
      ChatGiftModel(giftImage: '33下装'.obs, giftName: '33下装'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:35.obs,selected: false.obs),
      ChatGiftModel(giftImage: '旋转木马'.obs, giftName: '旋转木马'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:36.obs,selected: false.obs),
      ChatGiftModel(giftImage: '心跳回忆'.obs, giftName: '心跳回忆'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:37.obs,selected: false.obs),
      ChatGiftModel(giftImage: '奇幻之城'.obs, giftName: '奇幻之城'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:38.obs,selected: false.obs),
      ChatGiftModel(giftImage: '红叶大道'.obs, giftName: '红叶大道'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:39.obs,selected: false.obs),
      ChatGiftModel(giftImage: '草莓蛋糕'.obs, giftName: '草莓蛋糕'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:40.obs,selected: false.obs),
      ChatGiftModel(giftImage: '奶粉钱'.obs, giftName: '奶粉钱'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:41.obs,selected: false.obs),
      ChatGiftModel(giftImage: '彩虹泡泡机'.obs, giftName: '彩虹泡泡机'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:42.obs,selected: false.obs),
      ChatGiftModel(giftImage: '小电视飞船'.obs, giftName: '小电视飞船'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:43.obs,selected: false.obs),
      ChatGiftModel(giftImage: '为你摘星'.obs, giftName: '为你摘星'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:44.obs,selected: false.obs),
      ChatGiftModel(giftImage: '积分加成卡'.obs, giftName: '积分加成卡'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:45.obs,selected: false.obs),
      ChatGiftModel(giftImage: 'D言D语'.obs, giftName: 'D言D语'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:46.obs,selected: false.obs),
      ChatGiftModel(giftImage: '海洋之心'.obs, giftName: '海洋之心'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:47.obs,selected: false.obs),
      ChatGiftModel(giftImage: '大电影票'.obs, giftName: '大电影票'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:48.obs,selected: false.obs),
      ChatGiftModel(giftImage: '星愿飞船'.obs, giftName: '星愿飞船'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:49.obs,selected: false.obs),
      ChatGiftModel(giftImage: '鎏金小电视'.obs, giftName: '鎏金小电视'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:50.obs,selected: false.obs),
      ChatGiftModel(giftImage: '踏青日记'.obs, giftName: '踏青日记'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:51.obs,selected: false.obs),
      ChatGiftModel(giftImage: '疯狂点赞'.obs, giftName: '疯狂点赞'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:52.obs,selected: false.obs),
      ChatGiftModel(giftImage: '战术可乐'.obs, giftName: '战术可乐'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:53.obs,selected: false.obs),
      ChatGiftModel(giftImage: '为你加冕'.obs, giftName: '为你加冕'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:54.obs,selected: false.obs),
      ChatGiftModel(giftImage: '唱片计划'.obs, giftName: '唱片计划'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:55.obs,selected: false.obs),
      ChatGiftModel(giftImage: '震撼声浪'.obs, giftName: '震撼声浪'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:56.obs,selected: false.obs),
      ChatGiftModel(giftImage: '森林花路'.obs, giftName: '森林花路'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:57.obs,selected: false.obs),
      ChatGiftModel(giftImage: '云南白药小狸'.obs, giftName: '云南白药小狸'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:58.obs,selected: false.obs),
      ChatGiftModel(giftImage: '赛事劫宝'.obs, giftName: '赛事劫宝'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:59.obs,selected: false.obs),
      ChatGiftModel(giftImage: '幻乐之声'.obs, giftName: '幻乐之声'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:60.obs,selected: false.obs),
      ChatGiftModel(giftImage: '新年红包'.obs, giftName: '新年红包'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:61.obs,selected: false.obs),
      ChatGiftModel(giftImage: '缘定三生'.obs, giftName: '缘定三生'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:62.obs,selected: false.obs),
      ChatGiftModel(giftImage: '大糕能'.obs, giftName: '大糕能'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:63.obs,selected: false.obs),
      ChatGiftModel(giftImage: '马了顶大'.obs, giftName: '马了顶大'.obs,giftType: ChatGiftType.chatGiftTypeNormal,number:64.obs,selected: false.obs),
    ]);
  }
}