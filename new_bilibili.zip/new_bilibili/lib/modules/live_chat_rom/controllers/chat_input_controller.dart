import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../../../utils/app_const/app_values.dart';
import '../status/chat_keyboard_state.dart';


class ChatInputController extends GetxController {
  late Rx<TextEditingController> editController;
  late FocusNode fieldFocusNode = FocusNode();

  late RxList<String> emojiList;
  late ChatKeyboardState keyboardState;

  late RxDouble keyboardHeight;

  void initData(){
    keyboardState = ChatKeyboardState(isEmojiKeyboard: false.obs, fieldHaveText: false.obs, isExpanded: false.obs);
    emojiList = _defaultEmojiList();
    editController = TextEditingController().obs;
    editController.value.addListener(() {
      keyboardState.fieldHaveText.value = editController.value.text.isNotEmpty?true:false;
    });
    keyboardHeight = 0.0.obs;
    fieldFocusNode = FocusNode();
    fieldFocusNode.addListener(() {
      if (fieldFocusNode.hasFocus) {
        keyboardState.isEmojiKeyboard.value = false;
      }
      else{
        keyboardState.isEmojiKeyboard.value = true;
      }
    });
  }

  void eventTap(ChatInputEventType type) {
    keyboardState.eventType = type;
    if (type == ChatInputEventType.chatInputEventTypeEmoji) {
      changeEmojiKeyboard();
    }
  }

  void emojiChange(String text){
    keyboardState.fieldHaveText.value = text.isNotEmpty?true:false;
    editController.value.text = editController.value.text + text;
  }

  void closeEmojiKeyboard(){
    if(keyboardState.isExpanded.value) {
      keyboardState.isExpanded.value = false;
      editController.value.text = '';
      keyboardHeight.value = 0.0;
      fieldFocusNode.unfocus();
    }
  }

  void openEmojiKeyboard(bool showFocusNode, BuildContext context){
    if(!keyboardState.isExpanded.value) {
      keyboardState.isExpanded.value = true;
      if (showFocusNode){
        keyboardState.isEmojiKeyboard.value = false;
        FocusScope.of(context).requestFocus(fieldFocusNode);
      }
      else {
        keyboardState.isEmojiKeyboard.value = true;
      }
      keyboardHeight.value = AppValues.emojiKeyboardDefault;
    }
  }

  void changeEmojiKeyboard(){
    if (!keyboardState.isEmojiKeyboard.value){
      keyboardState.isEmojiKeyboard.value = true;
      fieldFocusNode.unfocus();
    }
  }
  void deleteFieldText(){
    String originalText = editController.value.text;
    dynamic text;
    if (originalText.isNotEmpty) {
      text = originalText.characters.skipLast(1);
      editController.value.text = "$text";
    }
  }

  RxList<String> _defaultEmojiList(){
    return RxList<String>([
      '😀','😃','😄','😁','😆','😅','🤣',
      '😂','🙂','🙃','😉','😊','😇','😍',
      '🤩','😘','😗','😚','😙','😋','😛',
      '😜','🤪','😝','🤑','🤗','🤭','🤔',
      '🤫','🤐','🤨','😐','😑','😶','😏',
      '😒','🙄','😬','🤥','😌','😔','😪',
      '🤤','😴','😷','🤒','🤕','🤢','🤮',
      '🤧','😵','🤯','🤠','😎','🤓','🧐',
      '😕','😟','🙁','☹️','😮','😯','😲',
      '😳','😦','😧','😨','😰','😥','😢',
      '😭','😱','😖','😣','😞','😓','😩',
      '😫','😤','😡','😠','🤬','😈', '👿',
      '💀','☠️','💩','🤡','👹','👺', '❤️',
      '❤️‍🩹',
    ]);
  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }
  @override
  void onClose() {
    super.onClose();
    editController.close();
    fieldFocusNode.removeListener(() { });
  }
}