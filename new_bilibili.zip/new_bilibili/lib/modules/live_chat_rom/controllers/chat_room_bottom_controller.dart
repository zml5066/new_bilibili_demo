
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../../../utils/app_const/app_toast.dart';
import 'chat_gift_controller.dart';
import 'chat_input_controller.dart';
enum BottomEventType {
  bottomEventTypeDress,
  bottomEventTypeEmoji,
  bottomEventTypeBattle,
  bottomEventTypeJuan,
  bottomEventTypeGift
}
class ChatRoomBottomController extends GetxController{

  void bottomTap(BottomEventType type){
    if(type == BottomEventType.bottomEventTypeGift){
      Get.find<ChatGiftController>().showGiftList(true);
    }
    else {
      AppToast.toast('按钮事件');
    }
  }

  void openChatKeyboard(BuildContext context){
    Get.find<ChatInputController>().openEmojiKeyboard(true, context);
  }
  void openEmojiKeyboard(BuildContext context){
      Get.find<ChatInputController>().openEmojiKeyboard(false,context);
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }
}