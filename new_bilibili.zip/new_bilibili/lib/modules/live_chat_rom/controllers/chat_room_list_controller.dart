import 'package:get/get.dart';

import '../models/chat_room_cell_model.dart';

class ChatRoomListController extends GetxController {
  late RxList<ChatRoomCellModel> chatList;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    chatList = _defaultChatListData();
  }

  RxList<ChatRoomCellModel> _defaultChatListData() {
    return RxList<ChatRoomCellModel>([
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
              '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
      ChatRoomCellModel(
          level: 5,
          chatContent: '今天天气真好',
          isAnchor: false,
          nickName: '银鸽宝'),
      ChatRoomCellModel(
          level: 10,
          chatContent:
          '今天电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团，电视剧我的团长我的团',
          isAnchor: true,
          nickName: '影视剧'),
    ]);
  }
}
