import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/chat_gift_controller.dart';
import 'package:new_bilibili/utils/app_const/app_colors.dart';

import '../models/chat_gift_model.dart';

class ChatGiftCellView<Controller extends ChatGiftController> extends GetView<Controller> {

  final ChatGiftModel  dataModel;
  const ChatGiftCellView({super.key, required this.dataModel});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8),color:dataModel.selected.value?AppColors.liveChatBgColor:const Color.fromRGBO(0, 0, 0, 0)),
        child: GestureDetector(
          onTap: (){
            controller.selectedGift(dataModel);
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 0),
                height: 50,
                width: 50,
                child: Image.asset('assets/images/${dataModel.giftImage}.png'),
              ),
              Container(
                  alignment: Alignment.center,
                  child:Text(dataModel.selected.value?'${dataModel.number.value}电池':dataModel.giftName.value,
                      style:TextStyle(fontSize: dataModel.selected.value?9:12, color: dataModel.selected.value?Colors.grey:Colors.white,decoration: TextDecoration.none))
              ),
              Container(
                  alignment: Alignment.bottomCenter,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(2),color:dataModel.selected.value?Colors.redAccent:const Color.fromRGBO(0, 0, 0, 0)),
                  child:Text( dataModel.selected.value?'投喂':'${dataModel.number}电池', style:  TextStyle(fontSize: dataModel.selected.value?12:9, color: dataModel.selected.value?Colors.white:Colors.grey,decoration: TextDecoration.none))
              )
            ],
          ),
        ),
      );
    });
  }
}
