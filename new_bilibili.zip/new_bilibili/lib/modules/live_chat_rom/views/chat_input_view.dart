import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/app_const/app_colors.dart';
import '../controllers/chat_input_controller.dart';
import '../status/chat_keyboard_state.dart';

class ChatInputView<Controller extends ChatInputController>
    extends GetView<Controller> {
  const ChatInputView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5),
      height: 45,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(child: _createTextField()),
          _createIcon(ChatInputEventType.chatInputEventTypeEmoji,
              Icons.emoji_emotions_outlined),
          _createIcon(ChatInputEventType.chatInputEventTypeCurtain,
              Icons.font_download_outlined),
          Obx(()=> controller.keyboardState.fieldHaveText.value?
          _createIcon(ChatInputEventType.chatInputEventTypeSend, Icons.send_sharp):Container())
        ],
      ),
    );
  }

  Widget _createIcon(ChatInputEventType eventType, IconData iconData) {
    return GestureDetector(
      onTap: () => controller.eventTap(eventType),
      child: Container(
          width: 30,
          height: 30,
          margin: const EdgeInsets.only(left: 3, right: 3),
          child: Icon(iconData, size: 25, color: Colors.white)),
    );
  }

  Widget _createTextField() {
    return Container(
        height: 30,
        margin: const EdgeInsets.only(left: 5, right: 5),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: AppColors.liveChatBgColor),
        alignment: Alignment.centerLeft,
        child:Obx(() => TextField(
            focusNode: controller.fieldFocusNode,
            controller: controller.editController.value,
            textAlign: TextAlign.start,
            style: const TextStyle(fontSize: 12, color: Colors.white),
            keyboardType: TextInputType.multiline,
            cursorColor: Colors.pinkAccent,
            maxLines: 5,
            minLines: 1,
            decoration: const InputDecoration(
              contentPadding:  EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              fillColor: AppColors.liveChatBgColor,
              filled: true,
              hintText: "来个走心弹幕",
              hintStyle: TextStyle(color: AppColors.liveChatBgColor),
              border: OutlineInputBorder( borderRadius: BorderRadius.all(Radius.circular(10)),borderSide: BorderSide(color: AppColors.liveChatBgColor, width: 1.0)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10)), borderSide: BorderSide(color: AppColors.liveChatBgColor, width: 1.0)),
            )
        ))
    );
  }
}
