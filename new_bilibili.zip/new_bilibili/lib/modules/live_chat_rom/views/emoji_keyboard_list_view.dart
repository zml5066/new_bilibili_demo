import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/chat_input_controller.dart';

class EmojiKeyboardListView<Controller extends ChatInputController>
    extends GetView<Controller>{
  const EmojiKeyboardListView({super.key});


  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5, top: 5),
      child:Stack(
        alignment:AlignmentDirectional.bottomEnd,
        children: [
          GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 2, crossAxisSpacing: 2,childAspectRatio: 1),
              itemCount: controller.emojiList.obs.value.length,
              padding: EdgeInsets.zero,
              shrinkWrap: true,
              physics: const ClampingScrollPhysics(),
              itemBuilder: (BuildContext context, int position) {
                return GestureDetector(
                  onTap: ()=>controller.emojiChange(controller.emojiList.obs.value[position]),
                  child: Container( alignment: Alignment.center,child: Text(controller.emojiList.obs.value[position], style: const TextStyle(fontSize: 30)),
                  ),
                );
              }),
          GestureDetector(
            onTap: ()=>controller.deleteFieldText(),
            child: Container(
              width: 50,
              height: 30,
              margin: const EdgeInsets.only(bottom: 80, right: 20),
              decoration: BoxDecoration(color: Colors.black54,borderRadius: BorderRadius.circular((8.0))),
              alignment: Alignment.center,
              child: const Icon(Icons.close_sharp, size: 25, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
