import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/live_chat_room_controller.dart';

class AnchorInfoView<Controller extends LiveChatRoomController>
    extends GetView<Controller> {
  const AnchorInfoView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      height: 40,
      decoration: BoxDecoration( color: const Color.fromRGBO(94, 94, 94, 0.4), borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            height: 35,
            width: 35,
            margin: const EdgeInsets.only(top: 0, left: 5),
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage( image: NetworkImage(controller.anchorInfoModel.avatarUrl), fit: BoxFit.cover)),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(controller.anchorInfoModel.anchorName,style: const TextStyle(fontSize: 10, color: Colors.white)),
              Text(controller.anchorInfoModel.watchNum.obs.value.toString(),style: const TextStyle(fontSize: 10, color: Colors.white)),
            ],
          ),
          Obx((){
            return  controller.anchorInfoModel.isAttention.value?_createAlreadyAttentionView():_createNoAttentionView();
          }),
        ],
      ),
    );
  }
  Widget _createNoAttentionView(){
    return  GestureDetector(
      onTap: ()=>controller.attentionAnchor(),
      child: Container(
        height: 25,
        width: 60,
        margin: const EdgeInsets.only(top: 0, right: 5),
        decoration: BoxDecoration(
          color: Colors.pinkAccent,
          borderRadius: BorderRadius.circular((10.0)),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add,size: 15, color: Colors.white),
            Text('关注',style: TextStyle(fontSize: 12, color: Colors.white),)
          ],
        ),
      ),
    );
  }

  Widget _createAlreadyAttentionView(){
    return GestureDetector(
      onTap: ()=>controller.attentionAnchor(),
      child: Container(
        height: 25,
        width: 60,
        margin: const EdgeInsets.only(top: 0, right: 5),
        decoration: BoxDecoration(
          color: Colors.pinkAccent,
          borderRadius: BorderRadius.circular((10.0)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/images/为你加冕.png'),
            Image.asset('assets/images/为你摘星.png'),
          ],
        ),
      ),

    );

  }
}

// @override
// Widget build(BuildContext context) {
//   return Wrap(
//     direction: Axis.horizontal,
//     alignment: WrapAlignment.start,
//     spacing: 5.0,
//     runSpacing: 5.0,
//     children: [
//       RichText(
//         text: TextSpan(
//           children: [
//             dataModel.isAnchor?
//             WidgetSpan(
//               child: Container(
//                 decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), border: Border.all(color: Colors.red, width: 1)),
//                 child: const Text( '主播', style: TextStyle(fontSize: 12, color: Colors.red),
//                 ),
//               ),
//             ):
//             WidgetSpan(
//               child: Container(
//                 decoration: BoxDecoration(color: Colors.blueGrey,borderRadius: BorderRadius.circular(5)),
//                 child:  Text( 'Level${dataModel.level.toString()}', style:const TextStyle(fontSize: 12, color: Colors.white),
//                 ),
//               ),
//             ),
//             WidgetSpan(
//               child: Image.asset(
//                 'assets/images/告白花束.png',
//                 scale: 9,
//               ),
//             ),
//             TextSpan(text: dataModel.chatContent),
//             WidgetSpan(
//                 child: Container(height: 5)
//             ),
//           ],
//         ),
//       )
//     ],
//   );
// }