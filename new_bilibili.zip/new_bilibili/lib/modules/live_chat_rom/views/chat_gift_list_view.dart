import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/chat_gift_controller.dart';
import 'package:new_bilibili/utils/app_const/app_values.dart';

import '../../../utils/app_const/app_const.dart';
import 'chat_gift_cell_view.dart';

class ChatGiftListView<Controller extends ChatGiftController> extends GetView<Controller> {
  const ChatGiftListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return AnimatedPositioned(
        duration: const Duration(milliseconds: 300),
        top: controller.giftState.isExpanded.value? 0 : AppConst.screenHeight(context),
        width: AppConst.screenWidth(context),
        height: AppConst.screenHeight(context),
        child: GestureDetector(
          onTap: ()=>controller.showGiftList(false),
          child: Container(
              color: const Color.fromRGBO(255, 255, 255, 0.0),
              margin: const EdgeInsets.all(0),
              height: AppConst.screenHeight(context),
              child:Container(
                decoration:BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.black87),
                margin: EdgeInsets.only(top: AppConst.screenHeight(context)-AppValues.giftListDefault, left: 0,right: 0,bottom: AppConst.bottomBarHeight(context)),
                height:AppValues.giftListDefault,
                child:GestureDetector(
                  onTap: (){},
                  child: GridView.builder(
                      itemCount: controller.giftList.obs.value.length,
                      shrinkWrap: true,
                      padding: const EdgeInsets.only(left: 5, right: 5, top: 5),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                          mainAxisSpacing: 10,
                          crossAxisSpacing: 10,
                          childAspectRatio: 1),
                      itemBuilder: (BuildContext context, int position) {
                        return ChatGiftCellView(dataModel: controller.giftList.obs.value[position]);
                      }),
                ),
              )
          ),
        ),
      );
    });
  }
}
