import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/live_chat_room_controller.dart';

import '../../../utils/marquee/horizontal_marquee.dart';

class MoreLiveView<Controller extends LiveChatRoomController>
    extends GetView<Controller> {
  const MoreLiveView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _createPopular(),
          _createMoreLive(),
        ],
      ),
    );
  }

  Widget _createPopular() {
    return Container(
      width: 60,
      height: 30,
      margin: const EdgeInsets.only(left: 10),
      decoration: BoxDecoration(
          color: const Color.fromRGBO(94, 94, 94, 0.5),
          borderRadius: BorderRadius.circular(10.0)),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.local_fire_department_outlined,
            color: Colors.pinkAccent,
            size: 15,
          ),
          Text('人气榜', style: TextStyle(fontSize: 12, color: Colors.white)),
        ],
      ),
    );
  }

  Widget _createMoreLive() {
    return Container(
      width: 80,
      height: 30,
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
          color: const Color.fromRGBO(94, 94, 94, 0.5),
          borderRadius: BorderRadius.circular(10.0)),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
           SizedBox(width: 2),
           Icon(
            Icons.more_outlined,
            color: Colors.white,
            size: 15,
          ),
           SizedBox(width: 3),
          Expanded(
              child: HorizontalMarquee(
                speed: 3000,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('更多直播',style: TextStyle(color: Colors.white, fontSize: 12)),
                  ],
                ),
              )
          ),
           SizedBox(width: 2),
           Icon(
            Icons.arrow_forward_ios_rounded,
            color: Colors.white,
            size: 15,
          ),
        ],
      ),
    );
  }
}

