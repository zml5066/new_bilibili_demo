import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/chat_input_controller.dart';


import '../../../utils/app_const/app_const.dart';
import '../../../utils/app_const/app_values.dart';
import 'chat_input_view.dart';
import 'emoji_keyboard_list_view.dart';

class ChatKeyboardView<Controller extends ChatInputController> extends GetView<Controller> {
  const ChatKeyboardView({super.key});
  @override
  Widget build(BuildContext context) {
    return  KeyboardVisibilityBuilder(builder: (BuildContext context, bool isKeyboardVisible){
      return Obx(() {
        controller.keyboardHeight.value = isKeyboardVisible? MediaQuery.of(context).viewInsets.bottom + 100:AppValues.emojiKeyboardDefault;
        return AnimatedPositioned(
          duration: const Duration(milliseconds: 300),
          top: controller.keyboardState.isExpanded.value? 0 : AppConst.screenHeight(context),
          width: AppConst.screenWidth(context),
          height: AppConst.screenHeight(context),
          child:GestureDetector(
            onTap: ()=>controller.closeEmojiKeyboard(),
            child: Container(
                color: const Color.fromRGBO(255, 255, 255, 0.0),
                margin: const EdgeInsets.all(0),
                height: AppConst.screenHeight(context),
                child: GestureDetector(
                  onTap: (){},
                  child: Container(
                    decoration:BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.black87),
                    margin: EdgeInsets.only(top: AppConst.screenHeight(context)- controller.keyboardHeight.value, left: 0,right: 0),
                    height:controller.keyboardHeight.value,
                    child:const Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ChatInputView(),
                        Expanded(child: EmojiKeyboardListView())
                      ],
                    ),
                  ),
                )
            ),
          ),
        );
      });
    });
  }
}
