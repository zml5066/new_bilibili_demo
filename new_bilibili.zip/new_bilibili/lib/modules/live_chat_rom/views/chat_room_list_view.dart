import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/chat_room_list_controller.dart';
import 'package:new_bilibili/utils/app_const/app_colors.dart';
import 'chat_cell_view.dart';

class ChatRoomListView<Controller extends ChatRoomListController> extends GetView<Controller> {
  const ChatRoomListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 30),
      child: ListView.builder(
          // shrinkWrap: true,
          itemCount: controller.chatList.obs.value.length,
          itemBuilder: (BuildContext context, int index) {
            return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 5, left: 15, right: 75),
                    padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    decoration: BoxDecoration(
                        color: AppColors.liveChatBgColor,
                        borderRadius: BorderRadius.circular(15)),
                    child: ChatCellView(dataModel: controller.chatList.obs.value[index],),
                  ),
                ]);
          }),
    );
  }
}
