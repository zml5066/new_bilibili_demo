import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/live_chat_room_controller.dart';

class ChatRoomLiveView<Controller extends LiveChatRoomController> extends GetView<Controller> {
  const ChatRoomLiveView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      margin: const EdgeInsets.only(top: 10),
      color: Colors.black87,
    );
  }
}
