import 'package:extended_text/extended_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/chat_room_list_controller.dart';
import '../models/chat_room_cell_model.dart';

class ChatCellView<Controller extends ChatRoomListController>
    extends GetView<Controller> {
  final ChatRoomCellModel dataModel;

  const ChatCellView({super.key, required this.dataModel});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constrains){
        return Wrap(
          direction: Axis.horizontal,
          alignment: WrapAlignment.start,
          // spacing: 5.0,
          // runSpacing: 5.0,
          children: [
            ExtendedRichText(
              text: TextSpan(
                children: [
                  dataModel.isAnchor?
                  WidgetSpan(
                    child: Container(
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), border: Border.all(color: Colors.red, width: 1)),
                      child: const Text( '主播', style: TextStyle(fontSize: 12, color: Colors.red),
                      ),
                    ),
                  ):
                  WidgetSpan(
                    child: Container(
                      decoration: BoxDecoration(color: Colors.blueGrey,borderRadius: BorderRadius.circular(5)),
                      padding: const EdgeInsets.all(2),
                      child:  Text( 'Level${dataModel.level.toString()}', style:const TextStyle(fontSize: 12, color: Colors.white),
                      ),
                    ),
                  ),
                  WidgetSpan(
                    child: Image.asset(
                      'assets/images/告白花束.png',
                      scale: 9,
                    ),
                  ),
                  TextSpan(text: dataModel.chatContent),
                  WidgetSpan(
                    child: Image.asset(
                      'assets/images/一箭倾心.png',
                      scale: 5,
                    ),
                  ),
                ],
              ),
            )
          ],
        );
      },
    );
  }
}
