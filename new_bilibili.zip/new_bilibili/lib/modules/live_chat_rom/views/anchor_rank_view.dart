import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/live_chat_room_controller.dart';

class AnchorRankView<Controller extends LiveChatRoomController> extends GetView<Controller> {
  const AnchorRankView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      alignment: Alignment.center,
      child: Stack(
        alignment: Alignment.center,
        children:  _createRankAvatar(),
      ),
    );
  }

  List<Widget>_createRankAvatar(){
    List<Widget> widgets = [];
    var wid = Positioned(
      right: 0.0,
      width: 35,
      height: 35,
      child: _createCycleView(''),
    );
    widgets.add(wid);
    for(int i = 0;i <controller.anchorRankModel.rankAvatarUrls.length;i ++){
      var wid = Positioned(
        right:(i+ 1) * 30.0 - 2 * (i+ 1),
        width: 35,
        height: 35,
        child: _createCycleView(controller.anchorRankModel.rankAvatarUrls[i]),
      );
      widgets.add(wid);
    }
    return widgets;
  }

  Widget _createCycleView(String? url){
    if (url!.isEmpty){
      return Container(
          width: 35,
          height: 35,
          alignment: Alignment.center,
          decoration:const BoxDecoration(shape: BoxShape.circle, color: Colors.blueGrey),
          child: Obx(() {
            return Text(controller.anchorRankModel.onlineNum.value.toString(), style:const TextStyle(fontSize: 12, color: Colors.white));
          }),
      );
    }
    return Container(
        width: 35,
        height: 35,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            image: DecorationImage( image: NetworkImage(url), fit: BoxFit.cover
            )
        )
    );
  }
}
