import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/live_chat_room_controller.dart';
import '../../../utils/app_const/app_const.dart';
import 'anchor_info_view.dart';
import 'anchor_rank_view.dart';
import 'more_live_view.dart';

class ChatRoomHeaderView<Controller extends LiveChatRoomController>
    extends GetView<Controller> {
  const ChatRoomHeaderView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin:  EdgeInsets.only(left: 5, right: 5,top:AppConst.toolbarHeight(context)),
      height: 100,
      child: Column(
        children: [
          _createAnchorBgView(),
          const SizedBox(height: 10,),
          const MoreLiveView(),
        ],
      ),
    );
  }

  Widget _createAnchorBgView() {
    return Container(
      height: 50,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _createArrowView(),
           const Expanded(
              child: Row(
            children: [
              AnchorInfoView(),
              Expanded(child: AnchorRankView()),
            ],
          )),
          _createMoreSet(),
        ],
      ),
    );
  }

  Widget _createArrowView() {
    return GestureDetector(
      onTap: () => controller.goBack(),
      child: Container(
        margin: const EdgeInsets.only(left: 5),
        width: 20,
        height: 20,
        alignment: Alignment.centerLeft,
        child: const Icon(Icons.arrow_back_ios, size: 20, color: Colors.white),
      ),
    );
  }

  Widget _createMoreSet() {
    return GestureDetector(
      onTap: () => controller.openMoreSet(),
      child: Container(
        width: 20,
        height: 20,
        margin: const EdgeInsets.only(right: 5),
        alignment: Alignment.centerRight,
        child:
            const Icon(Icons.more_vert_outlined, size: 20, color: Colors.white),
      ),
    );
  }
}
