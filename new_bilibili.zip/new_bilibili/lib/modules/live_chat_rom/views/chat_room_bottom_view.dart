import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/chat_room_bottom_controller.dart';

import '../../../utils/app_const/app_const.dart';

class ChatRoomBottomView<Controller extends ChatRoomBottomController>
    extends GetView<Controller> {
  const ChatRoomBottomView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.topLeft,
      margin: const EdgeInsets.only(left: 5,right: 5,top: 10),
      height: 60 + AppConst.bottomBarHeight(context),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _createCycleImage(BottomEventType.bottomEventTypeDress,'assets/images/微信卡包.png'),
          Expanded(child:_createTextField(context)),
          _createCycleImage(BottomEventType.bottomEventTypeBattle,'assets/images/看一看icon.png'),
          _createCycleImage(BottomEventType.bottomEventTypeJuan,'assets/images/么么.png'),
          _createCycleImage(BottomEventType.bottomEventTypeGift,'assets/images/告白花束.png'),
        ],
      ),
    );
  }

  Widget _createTextField(BuildContext context) {
    return Container(
      height: 30,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: const Color.fromRGBO(94, 94, 94, 0.8)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 5),
          Expanded(
              child: GestureDetector(
            onTap: () => controller.openChatKeyboard(context),
            child: const Text('来个走心弹幕',
                style: TextStyle(fontSize: 14, color: Colors.grey)),
          )),
          GestureDetector(
            onTap: () => controller.openEmojiKeyboard(context),
            child:const Icon(Icons.emoji_emotions, size: 25, color: Colors.grey),
          ),
          const SizedBox(width: 5),
        ],
      ),
    );
  }

  Widget _createCycleImage(BottomEventType type, String imageName) {
    return GestureDetector(
      onTap: () => controller.bottomTap(type),
      child: Container(
        margin: const EdgeInsets.only(left: 5, right: 5),
        width: 30,
        height: 30,
        decoration: const BoxDecoration(shape: BoxShape.circle),
        child: Image.asset(imageName),
      ),
    );
  }
}
