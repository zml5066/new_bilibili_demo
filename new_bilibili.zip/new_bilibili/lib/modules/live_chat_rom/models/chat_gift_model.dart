import 'package:get/get_rx/src/rx_types/rx_types.dart';

enum ChatGiftType {
  chatGiftTypeNormal;
}

class ChatGiftModel {
  RxString giftImage;
  RxString giftName;
  ChatGiftType giftType;
  RxBool selected;
  RxInt number;

  ChatGiftModel(
      {required this.giftImage,
      required this.giftName,
      required this.giftType,
      required this.selected,
      required this.number});
}
