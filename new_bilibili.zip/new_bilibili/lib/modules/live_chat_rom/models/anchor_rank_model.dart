
import 'package:get/get.dart';

class AnchorRankModel {
  RxList<String>rankAvatarUrls;
  RxInt onlineNum;
  AnchorRankModel({required this.rankAvatarUrls, required this.onlineNum});
}