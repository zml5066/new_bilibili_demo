
class ChatRoomCellModel {
  String chatContent;
  bool isAnchor;
  int level;
  String nickName;
  ChatRoomCellModel({required this.level,required this.nickName, required this.chatContent, required this.isAnchor});
}