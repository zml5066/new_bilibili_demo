
import 'package:get/get.dart';

class AnchorInfoModel {
  String avatarUrl;
  String anchorName;
  RxBool isAttention;
  RxInt  watchNum;
  AnchorInfoModel({required this.avatarUrl, required this.anchorName, required this.isAttention, required this.watchNum});
}