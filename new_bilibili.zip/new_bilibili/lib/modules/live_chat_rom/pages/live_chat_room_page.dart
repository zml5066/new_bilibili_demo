
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live_chat_rom/controllers/live_chat_room_controller.dart';
import 'package:new_bilibili/modules/live_chat_rom/views/chat_room_header_view.dart';

import '../views/chat_gift_list_view.dart';
import '../views/chat_keyboard_view.dart';
import '../views/chat_room_bottom_view.dart';
import '../views/chat_room_list_view.dart';
import '../views/chat_room_live_view.dart';

class LiveChatRoomPage<Controller extends LiveChatRoomController>
    extends GetView<Controller> {
  const LiveChatRoomPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: MediaQuery.removePadding(
            context: context,
            removeBottom: true,
            removeTop: true,
            child: Stack(
              children: [
                Positioned.fill(
                    child: Image.asset("assets/images/chat_back.jpg",
                        fit: BoxFit.cover)),
                const Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    ChatRoomHeaderView(),
                    ChatRoomLiveView(),
                    Expanded(
                      child: ChatRoomListView(),
                    ),
                    ChatRoomBottomView(),
                  ],
                ),
                 const ChatKeyboardView(),
                 const ChatGiftListView(),
              ],
            )
        )
    );
  }
}
