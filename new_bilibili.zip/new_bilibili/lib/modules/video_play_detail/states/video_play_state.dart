/// 播放状态枚举
enum VideoPlayerState {
  stopped, // 初始状态，已停止或发生错误
  playing, // 正在播放
  paused, // 暂停
  completed // 播放结束
}

/// 视频显示状态
enum VideoDisplayState {
  videoDisplayNormal, //默认状态（竖屏未全屏状态）
  videoDisplayVertical, // （竖屏全屏状态）
  videoDisplayLandscape, // 横屏状态
}

/// 播放状态枚举
enum VideoSettingType {
  videoSettingTypeVolume, //音量设置
  videoSettingTypeBrightness, // 亮度设置
  videoSettingTypeSpeed //速度
}

class VideoPlayState {
  late String curPosStr;
  late String totalPosStr;
  late double curPos;
  late double totalPos;
  late VideoPlayerState playerState;
  late VideoDisplayState displayState;
  late double volumeValue;
  late double brightnessValue;
  late bool isExpandedSet;
  late double speedValue;

  VideoPlayState(
      {this.curPosStr = '0.0',
      this.totalPosStr = '0.0',
      this.curPos = 0.0,
      this.totalPos = 0.0,
      this.playerState = VideoPlayerState.stopped,
      this.displayState = VideoDisplayState.videoDisplayNormal,
      this.volumeValue=0.0, this.isExpandedSet=false, this.brightnessValue = 0.0, this.speedValue = 0.0});

  resetState() {
    curPosStr = '0.0';
    totalPosStr = '0.0';
    curPos = 0.0;
    totalPos = 0.0;
    playerState = VideoPlayerState.stopped;
  }
}
