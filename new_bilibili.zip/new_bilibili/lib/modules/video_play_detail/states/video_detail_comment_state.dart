
import 'package:get/get.dart';
/// 排序方式
enum VideoDetailCommentSortType {
  videoDetailCommentSortTypeHot, //按热度
  videoDetailCommentSortTypeTime, // 按时间排序
}
enum VideoDetailCommentEventType {
  videoDetailCommentEventTypeLike, //点赞，
  videoDetailCommentEventTypeNoLike, // 踩
  videoDetailCommentEventTypeShare, // 分享
  videoDetailCommentEventTypeReplay // 恢复
}

class VideoDetailCommentState{

  Rx<VideoDetailCommentSortType> sortType;

  VideoDetailCommentState({required this.sortType});
}