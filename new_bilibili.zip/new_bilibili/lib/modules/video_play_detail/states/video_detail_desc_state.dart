import 'package:get/get.dart';

/// 详情页简介事件类型
enum VideoDetailDescEventType {
  videoDetailDescEventTypeLike, //喜欢
  videoDetailDescEventTypeNoLike, // 不喜欢
  videoDetailDescEventTypeCoin, //投币
  videoDetailDescEventTypeCollect,// 收藏
  videoDetailDescEventTypeShare, // 分享
}

class VideoDetailDescState{

  RxBool isExpandedDesc; // true 展开简介

  VideoDetailDescState({required this.isExpandedDesc});

}