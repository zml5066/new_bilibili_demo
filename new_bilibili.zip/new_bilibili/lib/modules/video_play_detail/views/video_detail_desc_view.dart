import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/video_play_detail/controllers/video_play_detail_controller.dart';
import 'package:new_bilibili/modules/video_play_detail/views/video_detail_event_row.dart';

import 'video_detail_desc_list_view.dart';
import 'video_detail_topic_view.dart';
import 'video_detail_up_info_view.dart';

class VideoDetailDescView<Controller extends VideoPlayDetailController> extends GetView<Controller> {
  const VideoDetailDescView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      child:const Column(
        children: [
          VideoDetailUpInfoView(),
          VideoDetailTopicView(),
          VideoDetailEventRow(),
          VideoDetailDescListView()
        ],
      ),
    );
  }
}
