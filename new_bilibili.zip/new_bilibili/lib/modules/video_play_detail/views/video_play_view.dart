// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/video_play_detail/views/video_bottom_view.dart';
import 'package:new_bilibili/modules/video_play_detail/views/video_setting_view.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';
import 'package:new_bilibili/utils/player/app_video_player.dart';
import 'package:video_player/video_player.dart';
import '../controllers/video_play_controller.dart';
import 'video_top_view.dart';


class VideoPlayView extends StatefulWidget {
  final String videoURL;
  const VideoPlayView({super.key, required this.videoURL});
  @override
  State<VideoPlayView> createState() => _VideoPlayViewState();
}

class _VideoPlayViewState extends State<VideoPlayView> {

  final VideoPlayController controller = Get.put(VideoPlayController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    AppVideoPlayer.configVideoURL(widget.videoURL);
    AppVideoPlayer.play();
    AppVideoPlayer.addListenerState((playState) {
      AppConst.rrPrint(playState);
      setState(() {
      });
    });
  }

  @override
  void deactivate() {
    // TODO: implement deactivate
    super.deactivate();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    AppVideoPlayer.destoryData();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      margin:const EdgeInsets.only(left: 0,right: 0, top: kToolbarHeight),
      child:Stack(
        children: [
          Container(
            margin: const EdgeInsets.only(left: 0,right: 0),
            child: FutureBuilder(
              future: AppVideoPlayer.getVideoPlayerFuture(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  return VideoPlayer(AppVideoPlayer.getPlayerController()!);
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            ),
          ),
           VideoBottomView(),
           VideoTopView(),
           VideoSettingView(),
        ],
      ),
    );
  }
}

