import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';

import '../../../utils/app_const/app_colors.dart';
import '../controllers/video_detail_desc_controller.dart';
import '../states/video_detail_desc_state.dart';

class VideoDetailEventRow <Controller extends VideoDetailDescController> extends GetView<Controller> {
  const VideoDetailEventRow({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.whiteColor,
      margin: const EdgeInsets.only(left: 5, right: 5),
      child: _createEventRow()
    );
  }
  Widget _createEventRow() {
    return Obx(() {
      return Container(
        height: 60,
        margin: const EdgeInsets.only(top: 0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _createEventIcon(
                VideoDetailDescEventType.videoDetailDescEventTypeLike,
                controller.detailDescModel.likeNum.value,
                Icons.heat_pump_rounded),
            _createEventIcon(
                VideoDetailDescEventType.videoDetailDescEventTypeNoLike,
                controller.detailDescModel.noLikeNum.value,
                Icons.no_adult_content),
            _createEventIcon(
                VideoDetailDescEventType.videoDetailDescEventTypeCoin,
                controller.detailDescModel.coinNum.value,
                Icons.monetization_on_rounded),
            _createEventIcon(
                VideoDetailDescEventType.videoDetailDescEventTypeCollect,
                controller.detailDescModel.collectNum.value,
                Icons.collections_bookmark),
            _createEventIcon(
                VideoDetailDescEventType.videoDetailDescEventTypeShare,
                controller.detailDescModel.collectNum.value,
                Icons.share),
          ],
        ),
      );
    });
  }

  Widget _createEventIcon(VideoDetailDescEventType eventType, int num, IconData iconData) {
    return Container(
        width: 30,
        margin: const EdgeInsets.all(0),
        child: GestureDetector(
          onTap: () => controller.descEventTap(eventType),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(iconData, size: 30, color: Colors.black),
              Text('$num',
                  style: const TextStyle(fontSize: 12, color: Colors.black))
            ],
          ),
        ));
  }
}
