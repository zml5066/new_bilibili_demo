import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/video_play_detail/controllers/video_play_detail_controller.dart';
import 'package:new_bilibili/modules/video_play_detail/views/video_detail_comment_list_view.dart';
import 'package:new_bilibili/modules/video_play_detail/views/video_detail_comment_sort_view.dart';

class VideoDetailCommentView<Controller extends VideoPlayDetailController> extends GetView<Controller> {
  const VideoDetailCommentView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Column(
        children: [
          VideoDetailCommentSortView(),
          VideoDetailCommentListView(),
        ],
      ),
    );
  }
}
