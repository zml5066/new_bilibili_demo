import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/video_play_detail/controllers/video_play_detail_controller.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';

import 'video_play_view.dart';

class VideoHeaderView<Controller extends VideoPlayDetailController> extends GetView<Controller> {
  final double height;
  const VideoHeaderView({super.key, required this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      height: height,
      width: AppConst.screenWidth(context),
      child:  VideoPlayView(videoURL: controller.dataModel.videoURL.value),
    );
  }
}

