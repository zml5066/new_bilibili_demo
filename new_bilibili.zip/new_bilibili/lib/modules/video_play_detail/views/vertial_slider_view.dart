import 'package:flutter/material.dart';
import 'package:new_bilibili/utils/player/app_video_player.dart';
import '../../../utils/player/app_video_state.dart';

class VertialSliderView extends StatefulWidget {
  final AppVideoSettingType settingType;
  const VertialSliderView(
      {super.key, required this.settingType});

  @override
  State<VertialSliderView> createState() => _VertialSliderViewState();
}

class _VertialSliderViewState extends State<VertialSliderView> {
  late String title;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (widget.settingType == AppVideoSettingType.appVideoSettingTypeVolume) {
      title = '音量';
    }
    else if (widget.settingType == AppVideoSettingType.appVideoSettingTypeBrightness) {
      title = '亮度';
    }
    else if (widget.settingType == AppVideoSettingType.appVideoSettingTypeSpeed) {
      title = '速度';
    }
    AppVideoPlayer.getDefaultVolume(() {
      setState(() {

      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 10,
      child: Flex(
        direction: Axis.vertical,
        mainAxisSize: MainAxisSize.max,
        verticalDirection: VerticalDirection.up,
        children: <Widget>[
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 2,
                activeTrackColor: Colors.pinkAccent,
                inactiveTrackColor: Colors.grey,
                thumbColor: Colors.pinkAccent,
                overlayColor: Colors.grey,
                thumbShape: const RoundSliderThumbShape(
                    disabledThumbRadius: 15, enabledThumbRadius: 4),
                overlayShape: const RoundSliderOverlayShape(
                  overlayRadius: 14,
                ),
              ),
              child: RotatedBox(
                quarterTurns: 3, // 顺时针旋转 3/4 圈
                child: SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 2,
                    activeTrackColor: Colors.pinkAccent,
                    inactiveTrackColor: Colors.grey,
                    thumbColor: Colors.pinkAccent,
                    overlayColor: Colors.grey,
                    thumbShape: const RoundSliderThumbShape(
                        disabledThumbRadius: 15, enabledThumbRadius: 4),
                    overlayShape: const RoundSliderOverlayShape(
                      overlayRadius: 14,
                    ),
                  ),
                  child: Slider(
                    value: AppVideoPlayer.getSettingValue(widget.settingType)!,
                    min: 0,
                    max: 1,
                    label: AppVideoPlayer.getSettingValue(widget.settingType)!.toString(),
                    onChanged: (value) {
                      if(widget.settingType == AppVideoSettingType.appVideoSettingTypeVolume){
                        AppVideoPlayer.setVolume(value, () {setState(() {});});
                      }
                      else if(widget.settingType==AppVideoSettingType.appVideoSettingTypeBrightness){
                        AppVideoPlayer.setBrightness(value, () {setState(() {});});
                      }
                      else if(widget.settingType==AppVideoSettingType.appVideoSettingTypeSpeed){
                        AppVideoPlayer.setSpeed(value, () {setState(() {});});
                      }
                    },
                  ),
                ),
              ),
            ),
          ),
          Text(
            title,
            style: const TextStyle(fontSize: 10, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
