import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';

import '../controllers/video_detail_comment_controller.dart';
import '../models/video_detail_comment_cell_model.dart';
import '../states/video_detail_comment_state.dart';

class VideoDetailCommentListView<
        Controller extends VideoDetailCommentController>
    extends GetView<Controller> {
  const VideoDetailCommentListView({super.key});

  @override
  Widget build(BuildContext context) {
    return MediaQuery.removePadding(
      context: context,
      removeTop: true,
      child:  Expanded(
          child: Container(
            margin: const EdgeInsets.only(top: 10, left: 5, right: 5),
            child: ListView.builder(
                itemBuilder: (BuildContext context, int index) {
                  return _createCellView(controller.commentList.obs.value[index]);
                },
                shrinkWrap: true,
                itemCount: controller.commentList.obs.value.length),
          )),
    );
  }

  Widget _createCellView(VideoDetailCommentCellModel cellModel) {
    return Column(
      children: [
        _createUserAvatar(cellModel),
        _createCommentView(cellModel),
        _createEvent(cellModel),
        cellModel.replay.length <= 3
            ? _createLessReplayView(cellModel)
            : _createMoreReplayView(cellModel),
        Container(
            height: 0.5,
            margin: const EdgeInsets.only(left: 0),
            color: Colors.grey)
      ],
    );
  }

  Widget _createUserAvatar(VideoDetailCommentCellModel cellModel) {
    return SizedBox(
      height: 50,
      child: Row(
        children: [
          Container(
            alignment: Alignment.centerLeft,
            width: 30,
            height: 30,
            child: ClipOval(
                child: CachedNetworkImage(
                    fit: BoxFit.cover, imageUrl: cellModel.avatarURL)),
          ),
          const SizedBox(width: 10),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(cellModel.upName,
                      style: TextStyle(
                          fontSize: 14,
                          color: cellModel.level > 5
                              ? Colors.redAccent
                              : Colors.black)),
                  const SizedBox(width: 5),
                  Text('Level${cellModel.level}',
                      style: const TextStyle(
                          fontSize: 12,
                          color: Colors.redAccent,
                          fontWeight: FontWeight.bold)),
                ],
              ),
              Text('${cellModel.publishTime} IP属地：${cellModel.ip}',
                  style: const TextStyle(fontSize: 10, color: Colors.black))
            ],
          )
        ],
      ),
    );
  }

  Widget _createCommentView(VideoDetailCommentCellModel cellModel) {
    return Container(
      alignment: Alignment.centerLeft,
      margin: const EdgeInsets.only(left: 40),
      child: Text(cellModel.commentDesc,
          style: const TextStyle(fontSize: 14, color: Colors.black)),
    );
  }

  Widget _createEvent(VideoDetailCommentCellModel cellModel) {
    return Container(
      height: 30,
      margin: const EdgeInsets.only(left: 40),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => controller.eventTap(
                VideoDetailCommentEventType.videoDetailCommentEventTypeLike,
                cellModel),
            child: Row(
              children: [
                const Icon(Icons.thumb_up_alt_outlined,
                    color: Colors.grey, size: 20),
                Text(cellModel.likeNum,
                    style: const TextStyle(fontSize: 10, color: Colors.black))
              ],
            ),
          ),
          const SizedBox(width: 15),
          GestureDetector(
            onTap: () => controller.eventTap(
                VideoDetailCommentEventType.videoDetailCommentEventTypeNoLike,
                cellModel),
            child: const Icon(Icons.thumb_down_alt_outlined,
                color: Colors.grey, size: 20),
          ),
          const SizedBox(width: 15),
          GestureDetector(
            onTap: () => controller.eventTap(
                VideoDetailCommentEventType.videoDetailCommentEventTypeShare,
                cellModel),
            child: const Icon(Icons.share, color: Colors.grey, size: 20),
          ),
          const SizedBox(width: 15),
          GestureDetector(
            onTap: () => controller.eventTap(
                VideoDetailCommentEventType.videoDetailCommentEventTypeReplay,
                cellModel),
            child: const Icon(Icons.replay_circle_filled,
                color: Colors.grey, size: 22),
          ),
        ],
      ),
    );
  }

  Widget _createLessReplayView(VideoDetailCommentCellModel cellModel) {
    return Container(
      margin: const EdgeInsets.only(left: 40, top: 5),
      decoration: BoxDecoration(
          color: const Color.fromRGBO(128, 128, 128, 0.3),
          borderRadius: BorderRadius.circular(5)),
      child: _createReplayList(cellModel),
    );
  }

  Widget _createMoreReplayView(VideoDetailCommentCellModel cellModel) {
    return Container(
      margin: const EdgeInsets.only(left: 40, top: 5),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _createReplayList(cellModel),
          Text.rich(
            TextSpan(
              children: [
                TextSpan(
                    text: '共${cellModel.replay.length}条回复 >',
                    style: const TextStyle(fontSize: 13, color: Colors.blue),
                    recognizer: TapGestureRecognizer()
                      ..onTap = () => controller.openMoreReplay(cellModel)),
              ],
            ),
            style: const TextStyle(fontSize: 20, color: Colors.purple),
            textAlign: TextAlign.left,
          )
        ],
      ),
    );
  }

  Widget _createReplayList(VideoDetailCommentCellModel cellModel) {
    int itemCount = cellModel.replay.length;
    if (cellModel.replay.length > 3) {
      itemCount = cellModel.replay.length - 3;
    }
    return ListView.builder(
      itemBuilder: (BuildContext context, int index) {
        VideoDetailCommentReplayModel replayModel = cellModel.replay[index];
        if (replayModel.repliedName != null) {
          return _createHaveRepliedView(replayModel);
        }
        return _createNoRepliedView(replayModel);
      },
      itemCount: itemCount,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
    );
  }

  Widget _createNoRepliedView(VideoDetailCommentReplayModel replayModel) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(
              text: replayModel.replayName,
              style: const TextStyle(fontSize: 14, color: Colors.blue)),
          TextSpan(
            text: ':${replayModel.replayComment}',
            style: const TextStyle(
                fontSize: 14,
                color: Colors.black,
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
      style: const TextStyle(fontSize: 20, color: Colors.purple),
      textAlign: TextAlign.left,
    );
  }

  Widget _createHaveRepliedView(VideoDetailCommentReplayModel replayModel) {
    return Text.rich(
      TextSpan(
        children: [
          const TextSpan(
              text: '回复', style: TextStyle(fontSize: 14, color: Colors.black)),
          TextSpan(
              text: '@${replayModel.repliedName}',
              style: const TextStyle(fontSize: 14, color: Colors.blue)),
          TextSpan(
            text: ':${replayModel.replayComment}',
            style: const TextStyle(
                fontSize: 14,
                color: Colors.black,
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
      style: const TextStyle(fontSize: 20, color: Colors.purple),
      textAlign: TextAlign.left,
    );
  }
}
