import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';
import 'package:path/path.dart';

import '../controllers/video_play_controller.dart';
import '../controllers/video_play_detail_controller.dart';

class VideoTopView extends StatefulWidget {
  const VideoTopView({super.key});

  @override
  State<VideoTopView> createState() => _VideoTopViewState();
}

class _VideoTopViewState extends State<VideoTopView> {
  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 18.0,
      child:SizedBox(
      height: 30,
      width: AppConst.screenWidth(context),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
              width: 20,height: 20,
              child: GestureDetector(
                onTap: ()=>Get.find<VideoPlayDetailController>().goBack(),
                child: const Icon(Icons.arrow_back, color: Colors.white, size: 20),
              )
          ),
          SizedBox(
              width: 130,height: 20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                      width: 20,height: 20,
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: (){

                            },
                            child:const Icon(Icons.volume_up_sharp, color: Colors.white, size: 20),
                          )
                        ],
                      )
                  ),
                  SizedBox(
                      width: 20,height: 20,
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () {},
                            child:const Icon(Icons.volume_down_alt, color: Colors.white, size: 20),
                          )
                        ],
                      )
                  ),
                  SizedBox(
                      width: 20,height: 20,
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () {},
                            child:const Icon(Icons.tv_sharp, color: Colors.white, size: 20),
                          )
                        ],
                      )
                  ),
                  SizedBox(
                      width: 20,height: 20,
                      child: Row(
                        children: [
                          GestureDetector(
                              onTap: () {
                                Get.find<VideoPlayController>().showSetting(() {
                                  setState(() {});
                                });
                              },
                              child:const Icon(Icons.more_horiz_outlined, color: Colors.white, size: 20),
                          )
                        ],
                      )
                  ),
                  const SizedBox(width: 5)
                ],
              )
          ),
        ],
      ),
    ),
    );
  }
}
