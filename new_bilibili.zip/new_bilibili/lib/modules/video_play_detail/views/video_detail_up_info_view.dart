import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/video_detail_desc_controller.dart';

class VideoDetailUpInfoView<Controller extends VideoDetailDescController> extends GetView<Controller> {
  const VideoDetailUpInfoView({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Obx(() {
          return _createAvatarView(
              controller.detailDescModel.isAttention.value);
        }),
      ],
    );
  }

  Widget _createAvatarView(bool isAttention) {
    return Container(
      height: 45,
      margin: const EdgeInsets.only(left: 5, right: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            alignment: Alignment.centerLeft,
            width: 40,
            height: 40,
            child: ClipOval(
              child: CachedNetworkImage(
                  fit: BoxFit.cover,
                  imageUrl: controller.detailDescModel.upAvatarURL,
                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                      LinearProgressIndicator(
                          value: downloadProgress.progress)),
            ),
          ),
          Expanded(
              child: Container(
                alignment: Alignment.centerLeft,
                margin: const EdgeInsets.only(left: 5),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(controller.detailDescModel.upName,
                        style: const TextStyle(color: Colors.black, fontSize: 14)),
                    Text(
                        '${controller.detailDescModel.fanNum}粉丝  ${controller.detailDescModel.upVideoNum}视频',
                        style: const TextStyle(color: Colors.grey, fontSize: 12)),
                  ],
                ),
              )),
          Container(
            width: 100,
            height: 30,
            decoration: BoxDecoration(
              color: isAttention ? Colors.grey : Colors.pinkAccent,
              borderRadius: const BorderRadius.all(Radius.circular(25)),
            ),
            child: GestureDetector(
              onTap: () => controller.attentionUp(),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  !isAttention
                      ? const Icon(Icons.add, color: Colors.white, size: 20)
                      : const Icon(Icons.read_more_outlined,
                      color: Colors.black, size: 20),
                  const SizedBox(width: 2),
                  Text(isAttention ? '已关注' : '关注',
                      style: TextStyle(
                          color: isAttention ? Colors.black : Colors.white,
                          fontSize: 14))
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

