import 'package:flutter/material.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';
import 'package:new_bilibili/utils/player/app_video_player.dart';
import '../../../utils/player/app_video_state.dart';

class VideoBottomView extends StatefulWidget {
  const VideoBottomView({super.key});

  @override
  State<VideoBottomView> createState() => _VideoBottomViewState();
}

class _VideoBottomViewState extends State<VideoBottomView> {
  @override
  Widget build(BuildContext context) {
    bool isPause = AppVideoPlayer.getPlayerState()?.playerState == AppVideoPlayerState.paused ||  AppVideoPlayer.getPlayerState()?.playerState == AppVideoPlayerState.stopped;
    bool isShorNormal =  AppVideoPlayer.getPlayerState()?.displayState == AppVideoDisplayState.appVideoDisplayNormal;
    bool isLandscape =  AppVideoPlayer.getPlayerState()?.displayState == AppVideoDisplayState.appVideoDisplayLandscape;
    return Positioned(
      bottom: 5.0,
      left: 5,
      right: 5,
      child: SizedBox(
        height: 30,
        width: AppConst.screenWidth(context),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              alignment: Alignment.center,
              width: 20,height: 20,
              child: GestureDetector(
                onTap: ()=>isPause? AppVideoPlayer.play():AppVideoPlayer.pause(),
                child: isPause?const Icon(Icons.play_arrow, color: Colors.white,size: 20):const Icon(Icons.pause, color: Colors.white,size: 20),
              ),
            ),
             Expanded(child: SliderTheme(
             data: SliderTheme.of(context).copyWith(
               trackHeight: 2,
               activeTrackColor: Colors.pinkAccent,
               inactiveTrackColor:  Colors.grey,
               thumbColor: Colors.pinkAccent,
               overlayColor: Colors.grey,
               thumbShape: const RoundSliderThumbShape(disabledThumbRadius: 15, enabledThumbRadius: 4),
               overlayShape: const RoundSliderOverlayShape(overlayRadius: 14,
               ),
             ),
             child:  Slider( value: AppVideoPlayer.getPlayerState()!.curPos,
               min: 0,
               max: AppVideoPlayer.getPlayerState()!.totalDuration,
               label: AppVideoPlayer.getPlayerState()!.curPosStr,
               onChanged: (value){AppVideoPlayer.seekTo(value);},
             ),
           )
           ),
            Container(
              margin: const EdgeInsets.only(left: 0),
              width: 20,height: 20,
              child: GestureDetector(
                onTap: (){},
                child: isShorNormal?const Icon(Icons.crop_square, color: Colors.white,size: 20):const Icon(Icons.trip_origin_outlined, color: Colors.white,size: 20),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(left: 5),
              width: 20,height: 20,
              child: GestureDetector(
                onTap: () =>AppVideoPlayer.setLandscape(),
                child: isLandscape?const Icon(Icons.aspect_ratio_outlined, color: Colors.white,size: 20):const Icon(Icons.aspect_ratio_outlined, color: Colors.white,size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
