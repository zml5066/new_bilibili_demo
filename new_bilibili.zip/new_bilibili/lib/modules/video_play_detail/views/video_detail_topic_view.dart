import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';

import '../../../utils/app_const/app_colors.dart';
import '../controllers/video_detail_desc_controller.dart';
import '../states/video_detail_desc_state.dart';

class VideoDetailTopicView extends StatefulWidget {
  const VideoDetailTopicView({super.key});

  @override
  State<VideoDetailTopicView> createState() => _VideoDetailTopicViewState();
}

class _VideoDetailTopicViewState extends State<VideoDetailTopicView>
    with SingleTickerProviderStateMixin {
  final VideoDetailDescController controller =
      Get.find<VideoDetailDescController>();
  late AnimationController animationController;
  late final Animation<double> height;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    animationController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 300));
    //宽度动画
    height = Tween(begin: 50.0, end: 240.0).animate(animationController);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.whiteColor,
      margin: const EdgeInsets.only(left: 5, right: 5),
      child: Column(
        children: [
          AnimatedBuilder(
            builder: _buildAnimation,
            animation: animationController,
          ),
        ],
      ),
    );
  }

  Widget _buildAnimation(BuildContext context, child) {
    return Stack(
      children: [
        Container(
          color: AppColors.whiteColor,
          margin: const EdgeInsets.only(right: 5, left: 5),
          width: AppConst.screenWidth(context),
          child: Obx(() {
            return SizedBox(
              width: AppConst.screenWidth(context),
              height: height.value,
              child: _createDescText(),
            );
          }),
        ),
        Positioned(
            right: 5,
            top: 6,
            child: GestureDetector(
              onTap: () {
                if (controller.descState.isExpandedDesc.value) {
                  animationController.reverse().orCancel;
                } else {
                  animationController.forward().orCancel;
                }
                controller.openDescDetail();
              },
              child: const Icon(Icons.keyboard_arrow_down_rounded,
                  size: 20, color: Colors.black),
            )),
      ],
    );
  }

  Widget _createDescText() {
    return Wrap(
        // crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(right: 10),
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
            child: Text(
                overflow: TextOverflow.ellipsis,
                maxLines: controller.descState.isExpandedDesc.value ? 5 : 1,
                controller.detailDescModel.videoTopic.value,
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black)),
          ),
          _createTimeView(),
          _createTipView(),
          _createVideoDescText()
        ]);
  }

  Widget _createVideoDescText(){
    if (controller.descState.isExpandedDesc.value && controller.detailDescModel.videoDesc!.value.isNotEmpty){
      return Text(overflow: TextOverflow.ellipsis,maxLines: 5,controller.detailDescModel.videoDesc!.value,style: const TextStyle(fontSize: 12, color: Colors.grey));
    }
    return Container();
  }

  Widget _createTimeView() {
    if (controller.descState.isExpandedDesc.value){
      return SizedBox(
        height: 30,
        child: Row(
          children: [
            _createTimeIcon(Icons.play_circle_outline,'${controller.detailDescModel.totalWatchNum.value/ 10000}万'),
            const SizedBox(width: 5),
            _createTimeIcon(Icons.bookmark_add_rounded,controller.detailDescModel.dateTimeStr.value),
            const SizedBox(width: 5),
            _createTimeIcon(Icons.people_outline,'${controller.detailDescModel.watchingNum.value}人正在看'),
          ],
        ),
      );
    }
    return Container();
  }

  Widget _createTimeIcon(IconData iconData, String text) {
    return Row(
      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Icon(iconData, size: 20, color: Colors.black),
        Container(
          margin: const EdgeInsets.only(left: 2),
          alignment: Alignment.centerLeft,
          child: Text(text,
              style: const TextStyle(fontSize: 12, color: Colors.grey)),
        )
      ],
    );
  }

  Widget _createTipView(){
    if (controller.descState.isExpandedDesc.value){
      return const SizedBox(
        height: 30,
        child:Row(
          children: [
            Text('BW1C4U5Zt67',style: TextStyle(fontSize: 12, color: Colors.grey)),
            Icon(Icons.warning_amber_sharp, color: Colors.red,size: 15),
            Text('未经作者授权禁止转载',style: TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
      );
    }
    return Container();
  }


}
