import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/video_play_detail/controllers/video_detail_desc_controller.dart';

import '../models/video_detail_desc_cell_model.dart';

class VideoDetailDescListView<Controller extends VideoDetailDescController>
    extends GetView<Controller> {
  const VideoDetailDescListView({super.key});

  @override
  Widget build(BuildContext context) {
    return MediaQuery.removePadding(
        removeTop: true,
        context: context,
        child: Expanded(
            child: ListView.builder(
          itemBuilder: (BuildContext context, int index) {
            return _createCellView(controller.descList.obs.value[index]);
          },
          itemCount: controller.descList.obs.value.length,
          shrinkWrap: true,
          // physics: const NeverScrollableScrollPhysics(),
        )));
  }

  Widget _createCellView(VideoDetailDescCellModel cellModel) {
    return SizedBox(
      height: 120,
      child: Column(
        children: [
          Expanded(
              child: Container(
            margin: const EdgeInsets.only(left: 5, right: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 120,
                  alignment: Alignment.centerLeft,
                  margin: const EdgeInsets.only(left: 5, top: 5, bottom: 5),
                  clipBehavior: Clip.hardEdge,
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(6)),
                  child: CachedNetworkImage(
                      fit: BoxFit.cover, imageUrl: cellModel.imageURL),
                ),
                Expanded(
                    child: Column(
                  children: [
                    const SizedBox(height: 5),
                    Text(cellModel.title,
                        style:
                            const TextStyle(fontSize: 14, color: Colors.black)),
                    const SizedBox(height: 15),
                    Row(
                      children: [
                        Container(
                          // width: 100,
                          decoration: BoxDecoration(
                              color: const Color.fromRGBO(255, 0, 0, 0.2),
                              borderRadius: BorderRadius.circular(5)),
                          child: Text('${cellModel.likeNum}点赞',
                              style: const TextStyle(
                                  fontSize: 10, color: Colors.redAccent)),
                        ),
                        Text(cellModel.upName,
                            style: const TextStyle(
                                fontSize: 10, color: Colors.black)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        _createRowIcon(
                            Icons.play_circle_outline, cellModel.totalWatchNum),
                        const SizedBox(width: 5),
                        _createRowIcon(
                            Icons.bookmark_add_rounded, cellModel.commentNum),
                      ],
                    ),
                    const SizedBox(height: 5),
                  ],
                ))
              ],
            ),
          )),
          Container(
            height: 0.5,
            margin: const EdgeInsets.only(left: 5),
            color: Colors.grey,
          )
        ],
      ),
    );
  }

  Widget _createRowIcon(IconData iconData, String text) {
    return Row(
      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Icon(iconData, size: 20, color: Colors.black),
        Container(
          margin: const EdgeInsets.only(left: 2),
          alignment: Alignment.centerLeft,
          child: Text(text,
              style: const TextStyle(fontSize: 12, color: Colors.grey)),
        )
      ],
    );
  }
}
