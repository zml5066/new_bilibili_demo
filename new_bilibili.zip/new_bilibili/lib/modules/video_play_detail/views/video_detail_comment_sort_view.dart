import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/video_detail_comment_controller.dart';
import '../states/video_detail_comment_state.dart';

class VideoDetailCommentSortView <Controller extends VideoDetailCommentController> extends GetView<Controller> {
  const VideoDetailCommentSortView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Container(
        margin:const EdgeInsets.only(left: 10,right: 10, top: 10),
        child:  Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('热门评论',style: TextStyle(fontSize: 14, color: Colors.grey),),
            Container(
              alignment: Alignment.centerRight,
              child:GestureDetector(
                onTap: ()=>controller.commentSort(),
                child: Row(
                  children: [
                    const Icon(Icons.read_more_sharp,color: Colors.grey, size: 20,),
                    Text(controller.commentState.sortType.value == VideoDetailCommentSortType.videoDetailCommentSortTypeHot?'按热度':'按时间',
                      style: const TextStyle(fontSize: 14, color: Colors.grey),
                    )
                  ],
                ) ,
              ),
            )
          ],
        ),
      );
    });
  }
}
