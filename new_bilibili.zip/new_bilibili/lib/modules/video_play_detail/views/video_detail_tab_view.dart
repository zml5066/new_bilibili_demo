import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';

import '../../../utils/app_const/app_colors.dart';
import '../controllers/video_play_detail_controller.dart';

class VideoDetailTabView extends StatefulWidget {
  final double height;
  const VideoDetailTabView({super.key, required this.height});

  @override
  State<VideoDetailTabView> createState() => _VideoDetailTabViewState();
}

class _VideoDetailTabViewState extends State<VideoDetailTabView> with SingleTickerProviderStateMixin {
  final controller = Get.find<VideoPlayDetailController>();
  late AnimationController animationController;
  late Animation<EdgeInsets> padding;
  late final Animation<double> width;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    animationController =
    AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    //宽度动画
    width = Tween(begin: 120.0, end: 50.0).animate(animationController);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    animationController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      width: AppConst.screenWidth(context),
      color: AppColors.whiteColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _createTabView(),
          _createAnimation(),
        ],
      ),
    );
  }

  Widget _createAnimation (){
    return AnimatedBuilder(
      builder: _buildAnimation,
      animation: animationController,
    );
  }

  Widget _buildAnimation(BuildContext context, child) {
    return Container(
      alignment: Alignment.centerRight,
      margin: const EdgeInsets.only(right: 15),
      width: width.value,
      child: Container(
        width: 120.0,
        height: 20,
        // color: Colors.deepOrange,
        child: _createBarrageView(),
      ),
    );
  }

  Widget _createTabView(){
    return Container(
      margin: const EdgeInsets.only(left: 5),
      width: 160,
      child: TabBar(
        controller: controller.tabController,
        tabs: controller.tabs,
        unselectedLabelColor: Colors.black,
        labelColor: Colors.pinkAccent,
        indicatorColor: Colors.pinkAccent,
        isScrollable: true,
        indicatorSize: TabBarIndicatorSize.label,
        // indicator: const BoxDecoration(color: Colors.amber, borderRadius: BorderRadius.all(Radius.circular(15))),
        labelStyle: const TextStyle(fontSize: 14, color: Colors.black),
        padding: const EdgeInsets.only(bottom: 10),
        onTap: (int value) {
          controller.changeTabIndex(value);
        },
      ),
    );
  }

  Widget _createBarrageView(){
    return Obx(() {
      return Container(
        alignment: Alignment.centerRight,
        width: controller.isExpandedBarrage.value?120:50,
        height: 20,
        margin: const EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
            color: controller.isExpandedBarrage.value?Colors.white:Colors.blueGrey,
            borderRadius: controller.isExpandedBarrage.value?const BorderRadius.all(Radius.circular(20)):const BorderRadius.all(Radius.circular(25)),
            border: Border.all(color: Colors.grey, width: 1.0)),
        child:controller.isExpandedBarrage.value?_createExpandedBarrage():_createHiddenBarrageIcon(),
      );
    });
  }

  Widget _createExpandedBarrage(){
    return Row(
      children: [
        _createOpenBarrageIcon(),
        _createHiddenBarrageIcon(),
      ],
    );
  }

  Widget _createOpenBarrageIcon(){
    return Expanded(
      child:GestureDetector(
        onTap: ()=>controller.openBarrage(),
        child:Container(
          decoration: const BoxDecoration(
              color: Colors.black12,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(25),bottomLeft: Radius.circular(25))),
          margin: const EdgeInsets.all(0),
          height: 35,
          alignment: Alignment.center,
          child: const Text('点我发弹幕',style: TextStyle(fontSize: 12, color: Colors.grey)),
        ),
      ),
    );
  }

  Widget _createHiddenBarrageIcon(){
    return Container(
      margin: EdgeInsets.only(right: controller.isExpandedBarrage.value?8:6.5),
      height: 25,width: 25,
      alignment: Alignment.center,
      child: GestureDetector(
        onTap: (){
          if (controller.isExpandedBarrage.value) {
            animationController.forward();
          } else {
            animationController.reverse().orCancel;
          }
          controller.hideBarrage();
        },
        child: const Icon(
          Icons.wifi_tethering_rounded,
          size: 15,
          color: AppColors.appBarColor,
        ),
      ),
    );
  }
}
