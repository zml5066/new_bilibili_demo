import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/player/app_video_player.dart';

import '../../../utils/app_const/app_const.dart';
import '../../../utils/app_const/app_values.dart';
import '../../../utils/player/app_video_state.dart';
import '../controllers/video_play_controller.dart';
import 'vertial_slider_view.dart';

class VideoSettingView extends StatefulWidget {
  const VideoSettingView({super.key});

  @override
  State<VideoSettingView> createState() => _VideoSettingViewState();
}

class _VideoSettingViewState extends State<VideoSettingView> {
  @override
  Widget build(BuildContext context) {
    return  AnimatedPositioned(
        duration: const Duration(milliseconds: 100),
        left: Get.find<VideoPlayController>().isExpandedSet.value?0:AppConst.screenWidth(context),
        width: AppConst.screenWidth(context),
        height: 240,
        child: GestureDetector(
          onTap: (){
            Get.find<VideoPlayController>().showSetting((){
              setState(() {});
            });
          },
          child:  Container(
              color: const Color.fromRGBO(255, 255, 255, 0.0),
              margin: const EdgeInsets.all(0),
              width: AppConst.screenWidth(context),
              height: AppConst.screenHeight(context),
              child: GestureDetector(
                onTap: (){},
                child: Container(
                  color: Colors.black,
                  margin: EdgeInsets.only(left:   AppConst.screenWidth(context) - 100),
                  width:100,
                  height: AppValues.videoHeight,
                  child:  const Row(
                    children: [
                      SizedBox(width: 20,),
                      VertialSliderView(settingType:AppVideoSettingType.appVideoSettingTypeVolume),
                      SizedBox(width: 20,),
                      VertialSliderView(settingType:AppVideoSettingType.appVideoSettingTypeBrightness),
                      SizedBox(width: 20,),
                      VertialSliderView(settingType:AppVideoSettingType.appVideoSettingTypeSpeed),
                    ],
                  ),
                ),
              )
          ),
        ),
    );
  }
}
