import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_toast.dart';

import '../models/video_detail_comment_cell_model.dart';
import '../states/video_detail_comment_state.dart';

class VideoDetailCommentController extends GetxController {
  late VideoDetailCommentState commentState;
  late RxList<VideoDetailCommentCellModel> commentList;

  void initData() {
    commentState = VideoDetailCommentState(
        sortType: VideoDetailCommentSortType.videoDetailCommentSortTypeHot.obs);
    commentList = _defaultCommentList();
  }

  void commentSort() {
    if (commentState.sortType.value ==
        VideoDetailCommentSortType.videoDetailCommentSortTypeHot) {
      commentState.sortType.value =
          VideoDetailCommentSortType.videoDetailCommentSortTypeTime;
    } else if (commentState.sortType.value ==
        VideoDetailCommentSortType.videoDetailCommentSortTypeTime) {
      commentState.sortType.value =
          VideoDetailCommentSortType.videoDetailCommentSortTypeHot;
    }
  }

  void eventTap(VideoDetailCommentEventType eventType,
      VideoDetailCommentCellModel model) {
    AppToast.toast(model.upName);
  }

  void openMoreReplay(VideoDetailCommentCellModel model){
    AppToast.toast('打开更多回复');
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    initData();
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
  }

  RxList<VideoDetailCommentCellModel> _defaultCommentList() {
    return RxList<VideoDetailCommentCellModel>([
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/66.jpg',
          upName: '真需挺先生',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc: '此一时，彼一时，实力变化轮，已经不允许轮',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/67.jpg',
          upName: '真需挺先生1',
          level: 5,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '巴以冲突是指以色列和巴勒斯坦之间的长期冲突。这场冲突始于20世纪初，当时巴勒斯坦地区处于奥斯曼帝国的统治下。随着第一次世界大战的结束，巴勒斯坦成为英国的托管地，同时犹太人移民也逐渐增加。'
              '冲突的根源可以追溯到对土地和国家主权的争夺。犹太人希望在巴勒斯坦建立一个犹太国家，而巴勒斯坦人则主张建立一个独立的巴勒斯坦国家。这两个群体之间的冲突导致了暴力事件和战争。'
              '冲突的具体事件包括1947年的巴勒斯坦分区计划、1948年的以色列独立战争、1967年的六日战争、1987年的第一次巴勒斯坦起义、2000年的第二次巴勒斯坦起义等。这些事件导致了大量的死亡和伤亡，同时也造成了巨大的人道主义危机。'
              '国际社会一直在努力促进以色列和巴勒斯坦之间的和平进程。多次的和平谈判和协议都未能解决冲突的根本问题。目前，巴以冲突仍然存在，对于实现长期和平仍然面临巨大的挑战。',
          likeNum: '3000'),
      VideoDetailCommentCellModel(
          avatarURL: 'https://randomuser.me/api/portraits/men/69.jpg',
          upName: '小怪',
          level: 7,
          publishTime: '10小时前',
          isNoLike: false,
          ip: '海南',
          replay: RxList<VideoDetailCommentReplayModel>([
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了',
                repliedName: '影月飞羽'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
            VideoDetailCommentReplayModel(
                replayName: '行道者',
                replayComment: '乐妍，咱别带货乐，你去干时政评论巴，你比很多评论员强多了'),
          ]),
          commentDesc:
              '福岛事件是指2011年3月11日发生在日本福岛县的一系列灾难事件。该事件由一场9.0级地震引发，随后发生的海啸导致福岛第一核电站的核反应堆失去冷却系统，引发了核泄漏事故。'
              '地震和海啸造成了大量的人员伤亡和财产损失，但福岛第一核电站的核泄漏事故引起了全球范围内的关注。核电站的核反应堆失去冷却系统后，核燃料开始过热并产生氢气，最终导致了三个反应堆的熔毁和核泄漏。'
              '核泄漏导致大量的放射性物质释放到空气和海洋中，对周边地区的居民和环境造成了严重的影响。大量的人员被疏散，福岛县的一些地区至今仍然无法居住。'
              '福岛事件引发了全球对核能安全性的担忧，许多国家重新评估了自己的核能政策，并加强了核能安全措施。此外，福岛事件也对日本的经济和能源政策产生了深远影响，导致了对核能的质疑和反对声音的增加。',
          likeNum: '3000'),
    ]);
  }
}
