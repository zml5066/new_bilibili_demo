import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_toast.dart';
import '../models/video_detail_desc_cell_model.dart';
import '../models/video_detail_desc_model.dart';
import '../states/video_detail_desc_state.dart';

class VideoDetailDescController extends GetxController {
  late VideoDetailDescModel detailDescModel;
  late VideoDetailDescState descState;
  late RxList<VideoDetailDescCellModel> descList;

  void initData() {
    detailDescModel = _defaultDetailDescModel();
    descState = VideoDetailDescState(isExpandedDesc: false.obs);
    descList = _defaultDescList();
  }

  void attentionUp() {
    AppToast.toast('关注');
    detailDescModel.isAttention.value = !detailDescModel.isAttention.value;
  }

  void openDescDetail() {
    descState.isExpandedDesc.value = !descState.isExpandedDesc.value;
  }

  void descEventTap(VideoDetailDescEventType eventType) {
    AppToast.toast('事件点击');
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    initData();
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
  }

  VideoDetailDescModel _defaultDetailDescModel() {
    return VideoDetailDescModel(
        upName: '奥特老六',
        upAvatarURL: 'https://randomuser.me/api/portraits/men/65.jpg',
        upVideoNum: 4.obs,
        fanNum: 201.obs,
        videoTopic: '一部讽刺末位巨星的经典电影，你们知道是谁吗？"李连杰，张学友《鼠胆龙威》放到现在也是经典中的经典"'.obs,
        videoDesc:
            '一部讽刺末位巨星的经典电影，你们知道是谁吗？"李连杰，张学友《鼠胆龙威》放到现在也是经典中的经典",一部讽刺末位巨星的经典电影，你们知道是谁吗？"李连杰，张学友《鼠胆龙威》放到现在也是经典中的经典"一部讽刺末位巨星的经典电影，你们知道是谁吗？"李连杰，张学友《鼠胆龙威》放到现在也是经典中的经典",一部讽刺末位巨星的经典电影，你们知道是谁吗？"李连杰，张学友《鼠胆龙威》放到现在也是经典中的经典"'
                .obs,
        isAttention: false.obs,
        totalWatchNum: 19000.obs,
        dateTimeStr: '35 2023年10月3日 11:32'.obs,
        watchingNum: 247.obs,
        videoTabs: RxList(['李连杰', '张学友', '经典电影', '鼠胆龙威']),
        likeNum: 102.obs,
        noLikeNum: 1.obs,
        coinNum: 10.obs,
        collectNum: 12.obs);
  }

  //required this.totalWatchNum,
  RxList<VideoDetailDescCellModel> _defaultDescList() {
    return RxList<VideoDetailDescCellModel>([
      VideoDetailDescCellModel(
          imageURL:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '五常对新一轮巴以冲突的表态（微博）',
          videoDuration: '00:17',
          upName: '地理溪',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '老站声明哈马斯搞恐怖主义，打好你的篮球就可以轮',
          videoDuration: '00:17',
          upName: '科晓渔',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '欧文疑似谴责以色列，他是NBA最有勇气的人',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
      VideoDetailDescCellModel(
          imageURL:
          'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '韩国这样解读巴以冲突，专家：放眼全球都很另类',
          videoDuration: '00:17',
          upName: '二哥日记本',
          likeNum: '1.2万',
          commentNum: '14',
          totalWatchNum: '8.8万'),
    ]);
  }
}
