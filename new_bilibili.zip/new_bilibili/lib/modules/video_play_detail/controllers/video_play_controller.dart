import 'dart:io';
import 'package:auto_orientation/auto_orientation.dart';
import 'package:brightness_volume/brightness_volume.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';
import 'package:new_bilibili/utils/player/app_video_player.dart';
import 'package:video_player/video_player.dart';

import '../states/video_play_state.dart';

class VideoPlayController extends GetxController{

  late RxBool isExpandedSet;

  void showSetting(Function() callback){
    isExpandedSet.value = !isExpandedSet.value;
    callback();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    isExpandedSet = false.obs;
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
  }

}