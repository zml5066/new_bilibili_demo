
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_toast.dart';
import 'package:new_bilibili/utils/player/app_video_player.dart';
import '../../../utils/app_const/app_const.dart';
import '../../../utils/player/app_video_state.dart';
import '../models/video_detail_tab_model.dart';
import '../models/video_play_detail_model.dart';

class VideoPlayDetailController extends GetxController with GetSingleTickerProviderStateMixin {
  late VideoPlayDetailModel dataModel;
  late RxInt currentTabIndex;
  late List<VideoDetailTabModel> tabData;
  late List<Tab> tabs;
  late TabController tabController;
  late RxBool isExpandedBarrage;

  late ScrollController scrollController;

  void initData(){
    isExpandedBarrage = true.obs;
    currentTabIndex = 0.obs;
    tabData = [
      VideoDetailTabModel(title: '简介', index: 0, tabType: VideoDetailTabType.videoDetailTabTypeDesc),
      VideoDetailTabModel(title: '评论 1046', index: 1, tabType: VideoDetailTabType.videoDetailTabTypeComment),
    ];
    tabs = _createTabs();
    tabController = TabController(vsync: this, length: tabData.length);
    scrollController = ScrollController();
    scrollController.addListener((){
      if (AppVideoPlayer.getPlayerState()?.playerState == AppVideoPlayerState.playing){
        scrollController.jumpTo(0.0);
      }
    });
  }

  void changeTabIndex(int index) {
    currentTabIndex = index.obs;
    tabController.index = currentTabIndex.value;
  }

  void goBack(){
    Get.back();
  }

  /// 打开弹幕
  void openBarrage(){
    AppToast.toast('打开弹幕');
  }

  /// 隐藏弹幕
  void hideBarrage(){
    isExpandedBarrage.value = !isExpandedBarrage.value;
  }

  List<Tab> _createTabs(){
    List<Tab> tabs = [];
    for(VideoDetailTabModel tabModel in tabData) {
      tabs.add(Tab(text: tabModel.title));
    }
    return tabs;
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    dataModel = Get.arguments;
    AppConst.rrPrint(dataModel.upName);
    initData();
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
  }

}