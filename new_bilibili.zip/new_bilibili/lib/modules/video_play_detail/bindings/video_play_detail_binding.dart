import 'package:get/get.dart';
import '../controllers/video_detail_comment_controller.dart';
import '../controllers/video_detail_desc_controller.dart';
import '../controllers/video_play_detail_controller.dart';

class VideoPlayDetailBinding extends Bindings {

  @override
  void dependencies() {
    Get.lazyPut<VideoPlayDetailController>(() =>VideoPlayDetailController());
    Get.lazyPut<VideoDetailDescController>(() =>VideoDetailDescController());
    Get.lazyPut<VideoDetailCommentController>(() =>VideoDetailCommentController());
  }
}