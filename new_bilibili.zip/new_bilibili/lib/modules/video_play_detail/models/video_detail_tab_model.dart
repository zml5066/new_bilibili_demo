
enum VideoDetailTabType {
  videoDetailTabTypeDesc,// 简介
  videoDetailTabTypeComment,// 评论
}


class VideoDetailTabModel {
  final String title;
  final int index;
  final VideoDetailTabType? tabType;
  VideoDetailTabModel({required this.title, required this.index, this.tabType});
}