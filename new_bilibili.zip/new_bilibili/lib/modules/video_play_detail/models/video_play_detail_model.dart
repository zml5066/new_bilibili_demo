
import 'package:get/get.dart';

class VideoPlayDetailModel {
  RxString upName;
  RxString videoTitle;
  RxString videoURL;

  VideoPlayDetailModel({required this.upName, required this.videoTitle,required this.videoURL});
}