class VideoDetailCommentCellModel {
  String avatarURL;
  String upName;
  int level;
  String publishTime;
  String ip;
  String commentDesc;
  String likeNum;
  bool isNoLike;
  List<VideoDetailCommentReplayModel> replay;

  VideoDetailCommentCellModel(
      {required this.avatarURL,
      required this.upName,
      required this.level,
      required this.publishTime,
      required this.isNoLike,
      required this.ip,
      required this.replay,
      required this.commentDesc,
      required this.likeNum});
}

class VideoDetailCommentReplayModel {
  String replayName; // 回复者
  String replayComment; // 回复内容
  String? repliedName; // 被回复者

  VideoDetailCommentReplayModel(
      {required this.replayName,
      required this.replayComment,
      this.repliedName});
}
