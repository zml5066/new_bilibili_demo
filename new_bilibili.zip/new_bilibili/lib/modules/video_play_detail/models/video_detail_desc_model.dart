import 'package:get/get.dart';

class VideoDetailDescModel {
  String upAvatarURL;
  String upName;
  RxInt upVideoNum;
  RxInt fanNum;
  RxBool isAttention; // true 关注
  RxString videoTopic; // 主题
  RxString? videoDesc; // 视频简介
  RxInt totalWatchNum; // 视频观看总人数
  RxString dateTimeStr;
  RxInt watchingNum; // 正在观看看人数
  RxList<String> videoTabs;
  RxInt likeNum; // 点赞数量
  RxInt noLikeNum; // 不喜欢数量
  RxInt coinNum; // 投币数量
  RxInt collectNum; // 收藏数量

  VideoDetailDescModel(
      {required this.upName,
        required this.upAvatarURL,
        required this.upVideoNum,
        required this.fanNum,
        required this.isAttention,
        this.videoDesc,
        required this.totalWatchNum,
        required this.dateTimeStr,
        required this.watchingNum,
        required this.videoTabs,
        required this.likeNum,
        required this.noLikeNum,
        required this.coinNum,
        required this.collectNum,
        required this.videoTopic});
}
