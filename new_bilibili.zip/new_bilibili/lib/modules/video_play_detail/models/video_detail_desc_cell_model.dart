

class VideoDetailDescCellModel {
  String imageURL;
  String title;
  String videoDuration;
  String likeNum;
  String totalWatchNum; // 视频观看总人数
  String commentNum;
  String upName;
  VideoDetailDescCellModel({
    required this.imageURL,
    required this.title,
    required this.videoDuration,
    required this.likeNum,
    required this.totalWatchNum,
    required this.commentNum,
    required this.upName
});

}