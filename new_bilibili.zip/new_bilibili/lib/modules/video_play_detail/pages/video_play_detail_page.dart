import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/video_play_detail/controllers/video_play_detail_controller.dart';
import 'package:new_bilibili/utils/app_const/app_values.dart';
import 'package:new_bilibili/utils/player/app_video_player.dart';
import '../../../utils/player/app_video_state.dart';
import '../controllers/video_play_controller.dart';
import '../models/video_detail_tab_model.dart';
import '../views/video_detail_comment_view.dart';
import '../views/video_detail_desc_view.dart';
import '../views/video_detail_tab_view.dart';
import '../views/video_header_view.dart';

class VideoPlayDetailPage<Controller extends VideoPlayDetailController>
    extends GetView<Controller> {
  const VideoPlayDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _createNestedScrollView(),
    );
  }

  NestedScrollView _createNestedScrollView() {
    return NestedScrollView(
       controller: controller.scrollController,
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            const SliverAppBar(
              pinned: true,
              floating: true,
              expandedHeight: AppValues.videoHeight,
              flexibleSpace: VideoHeaderView(height: AppValues.videoHeight),
              bottom: PreferredSize(
                preferredSize: Size(double.infinity, 45),
                child: VideoDetailTabView(height: 45),
              ),
            ),
          ];
        },
        body: TabBarView(
          controller: controller.tabController,
          children: controller.tabData.map((VideoDetailTabModel tabModel) {
            if (tabModel.tabType == VideoDetailTabType.videoDetailTabTypeDesc) {
              return const VideoDetailDescView();
            }
            return const VideoDetailCommentView();
          }).toList(),
        ));
  }
}
