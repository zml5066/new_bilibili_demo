
import 'package:get/get.dart';
import 'package:new_bilibili/modules/home/controllers/home_header_controller.dart';

import '../../live_chat_rom/controllers/live_chat_room_controller.dart';
import '../controllers/chasing_controller.dart';
import '../controllers/home_controller.dart';
import '../controllers/hot_controller.dart';
import '../controllers/recommend_list_controller.dart';

class HomeBinding extends Bindings {

  @override
  void dependencies() {
    Get.lazyPut<HomeController>(() =>HomeController());
    Get.lazyPut<HomeHeaderController>(() =>HomeHeaderController());
    Get.lazyPut<HomeRecommendListController>(() =>HomeRecommendListController());
    Get.lazyPut<HotController>(() =>HotController());
    Get.lazyPut<ChasingController>(() =>ChasingController());
  }
}