class HotListCellModel {
  final String imageUrl;
  final String title;
  final int likeNum;
  final String nickName;
  final int viewersNum;
  final String timeStr;
  late  String? likeStr;
  late  String? viewersStr;
  late  String? timeContent;
  HotListCellModel({required this.imageUrl, required this.title,required this.likeNum, required this.nickName, required this.viewersNum, required this.timeStr, this.likeStr});
}

