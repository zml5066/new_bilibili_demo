import 'package:json_annotation/json_annotation.dart';

part 'chasing_cell_model.g.dart';
@JsonSerializable()
class ChasingCellModel {
  final String imageUrl;
  final String title;
  final String desc;
  final String score;
  ChasingCellModel({required this.imageUrl, required this.title, required this.desc, required this.score});

  factory ChasingCellModel.fromJson(Map<String, dynamic> json) => _$ChasingCellModelFromJson(json);

  Map<String, dynamic> toJson() => _$ChasingCellModelToJson(this);
}