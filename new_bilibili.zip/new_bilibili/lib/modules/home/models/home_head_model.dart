enum HomeTabType {
  homeTabTypeLive,// 直播
  homeTabTypeRecommend,//推荐
  homeTabTypeHot, // 热门
  homeTabTypeZui, // 追番
  homeTabTypeMovie, // 影视
  homeTabTypeNew, // 新征程
}


class HomeTabModel {
  final String title;
  final int index;
  final HomeTabType? tabType;
  HomeTabModel({required this.title, required this.index, this.tabType});
}
