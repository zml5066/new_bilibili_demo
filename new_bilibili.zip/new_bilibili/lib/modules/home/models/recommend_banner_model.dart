import 'package:banner_carousel/banner_carousel.dart';

class RecommendBannerModel {
  final String imageUrl;
  final String id;
  final String name;
  RecommendBannerModel({required this.imageUrl, required this.id, required this.name});
}

const String banner1 =
    'https://upload-images.jianshu.io/upload_images/2990730-7d8be6ebc4c7c95b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240';
const String banner2 =
    'https://upload-images.jianshu.io/upload_images/2990730-e3bfd824f30afaac?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240';
const String banner3 = 'https://upload-images.jianshu.io/upload_images/2990730-a1d64cf5da2d9d99?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240';
const String banner4 =
    'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240';
