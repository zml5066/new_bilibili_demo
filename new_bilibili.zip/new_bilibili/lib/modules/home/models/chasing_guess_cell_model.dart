class ChasingGuessCellModel {
  final String imageUrl;
  final String title;
  final String desc;
  ChasingGuessCellModel({required this.imageUrl, required this.title, required this.desc});
}
