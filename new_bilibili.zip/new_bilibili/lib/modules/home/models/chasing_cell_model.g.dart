// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chasing_cell_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChasingCellModel _$ChasingCellModelFromJson(Map<String, dynamic> json) =>
    ChasingCellModel(
      imageUrl: json['imageUrl'] as String,
      title: json['title'] as String,
      desc: json['desc'] as String,
      score: json['score'] as String,
    );

Map<String, dynamic> _$ChasingCellModelToJson(ChasingCellModel instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'title': instance.title,
      'desc': instance.desc,
      'score': instance.score,
    };
