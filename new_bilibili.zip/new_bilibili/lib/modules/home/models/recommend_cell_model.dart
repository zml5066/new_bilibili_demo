class RecommendCellModel {
  final String url;
  final String title;
  final num index;
  final String upName;
  final bool isVideo;
  RecommendCellModel({required this.url, required this.title, required this.index, required this.upName, required this.isVideo});
}

