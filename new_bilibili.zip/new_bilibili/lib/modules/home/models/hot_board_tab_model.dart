
class HotBoardTabModel {
  final String iconName;
  final String title;
  HotBoardTabModel({required this.iconName, required this.title});
}
