import 'package:get/get.dart';
import '../../../routers/app_pages.dart';
import '../../video_play_detail/models/video_play_detail_model.dart';
import '../models/home_head_model.dart';
import '../models/recommend_banner_model.dart';
import '../models/recommend_cell_model.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class HomeRecommendListController extends GetxController {
  late RxList<RecommendBannerModel> bannersList;
  late RxList<RecommendCellModel> listData;
  late RefreshController refreshController;

  void initData() {
    listData = defaultListData();
    bannersList = RxList([
      RecommendBannerModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          id: "1",
          name: '1'),
      RecommendBannerModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          id: "2",
          name: '1'),
      RecommendBannerModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          id: "3",
          name: '1'),
      RecommendBannerModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          id: "4",
          name: '1'),
    ]);
    refreshController = RefreshController(initialRefresh: false);
  }

  void onRefresh() async {
    await Future.delayed(const Duration(milliseconds: 1000));
    listData.removeRange(0, listData.length);
    listData = defaultListData();
    refreshController.refreshCompleted();
  }

  void onLoading() async {
    await Future.delayed(const Duration(milliseconds: 1000));
    listData.add(RecommendCellModel(
        url: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
        title: '建筑1',
        index: 2,
        upName: '直击面试专方组',
        isVideo: false));
    refreshController.loadComplete();
  }

  /// 推荐列表事件
  void recommendCellTap(RecommendCellModel dataModel,HomeTabType tabType) {
    if (tabType != HomeTabType.homeTabTypeLive){
      VideoPlayDetailModel dataModel = VideoPlayDetailModel(
          upName: '大飞说房'.obs,
          videoTitle: '摊牌了！一人租房全家落户，郑州"抢人大战"'.obs,
          videoURL: 'https://media.w3.org/2010/05/sintel/trailer.mp4'.obs);
      Get.toNamed(AppPages.videoPlayDetail, arguments:dataModel);
    }
  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  RxList<RecommendCellModel> defaultListData() {
    return RxList([
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '第二十九集：翻盘！神小样的语言艺术',
          index: 0,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '建筑1小鸟飞行小鸟飞行',
          index: 2,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 3,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 4,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '建筑2小鸟飞行小鸟飞行小鸟飞行',
          index: 5,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '建筑2',
          index: 6,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '建筑2',
          index: 8,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑1',
          index: 9,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 9,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 10,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '建筑2',
          index: 11,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '建筑2',
          index: 12,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '建筑2',
          index: 13,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '建筑1',
          index: 14,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 15,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 16,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '建筑2',
          index: 17,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '建筑2',
          index: 18,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '建筑2',
          index: 19,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '建筑1',
          index: 20,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 21,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2529476510,3041785782&fm=193&f=GIF',
          title: '建筑2',
          index: 22,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '建筑2',
          index: 23,
          upName: '直击面试专方组',
          isVideo: false),
      RecommendCellModel(
          url: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '建筑2',
          index: 24,
          upName: '直击面试专方组',
          isVideo: false),
    ]);
  }
}
