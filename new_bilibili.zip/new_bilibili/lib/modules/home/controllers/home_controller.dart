import 'package:get/get.dart';
import '../../../routers/app_pages.dart';
import '../../../utils/app_const/app_const.dart';
import '../models/chasing_cell_model.dart';
import '../models/home_head_model.dart';

class HomeController extends GetxController{

  void initData(){

  }

  void openLiveChatRoom(ChasingCellModel dataModel,HomeTabType tabType){
    if (tabType == HomeTabType.homeTabTypeLive){
      Get.toNamed(AppPages.liveChatRoom, arguments:dataModel);
    }
  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {

  }
}