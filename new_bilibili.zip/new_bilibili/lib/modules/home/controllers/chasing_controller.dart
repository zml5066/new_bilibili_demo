import 'package:get/get.dart';

import '../../../routers/app_pages.dart';
import '../../video_play_detail/models/video_play_detail_model.dart';
import '../models/chasing_cell_model.dart';
import '../models/chasing_guess_cell_model.dart';
import '../models/home_head_model.dart';
import '../models/hot_board_tab_model.dart';
import '../models/recommend_banner_model.dart';

class ChasingController extends GetxController{

  late RxList<RecommendBannerModel> bannersList;
  late RxList<HotBoardTabModel> boardTabList;
  late RxList<ChasingCellModel> chasingList;
  late RxList<ChasingGuessCellModel> guessList;

  void initData() {
    bannersList = RxList([
      RecommendBannerModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF', id: "1", name: '1'),
      RecommendBannerModel(imageUrl:'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF', id: "2", name: '1'),
      RecommendBannerModel(imageUrl: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF', id: "3", name: '1'),
      RecommendBannerModel( imageUrl: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF', id: "4", name: '1'),
    ]);
    boardTabList = defaultChasingBoardData();
    chasingList = defaultChasingListData();
    guessList = defaultGuessListData();
  }

  void chasingCellTap(){

  }

  void closeAdvertise(){

  }

  void openActivity(){

  }

  void openVideoDetailPage(HomeTabType tabType){
    if (tabType != HomeTabType.homeTabTypeLive){
      VideoPlayDetailModel dataModel = VideoPlayDetailModel(
          upName: '大飞说房'.obs,
          videoTitle: '摊牌了！一人租房全家落户，郑州"抢人大战"'.obs,
          videoURL: 'https://media.w3.org/2010/05/sintel/trailer.mp4'.obs);
      Get.toNamed(AppPages.videoPlayDetail, arguments:dataModel);
    }
  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
  }

  RxList<HotBoardTabModel> defaultChasingBoardData(){
    return RxList([
      HotBoardTabModel(iconName: 'assets/images/微信表情.png',title: '全部内容'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '番剧'),
      HotBoardTabModel(iconName: 'assets/images/小程序.png',title: '国创'),
      HotBoardTabModel(iconName: 'assets/images/微信表情.png',title: '时间表'),
      HotBoardTabModel(iconName: 'assets/images/小程序.png',title: '7月新番'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '时光游戏'),
      HotBoardTabModel(iconName: 'assets/images/微信表情.png',title: '暑期补番'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '寻光计划'),
      HotBoardTabModel(iconName: 'assets/images/小程序.png',title: '历史记录'),
    ]);
  }

  RxList<ChasingCellModel>defaultChasingListData(){
    return RxList([
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '布莱泽奥特曼', desc:'新奥特英雄成长之路', score: '9.8'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '海绵宝宝 中文配音', desc:'站内高分番剧',score: '9.9'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '鬼灭之刃 刀匠村篇', desc:'信念锻刃，进展恶鬼', score: '5.8'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '茶啊二中 第三季', desc:'站内高分国创', score: '9.7'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '布莱泽奥特曼', desc:'新奥特英雄成长之路', score: '9.8'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '海绵宝宝 中文配音', desc:'站内高分番剧',score: '9.9'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '鬼灭之刃 刀匠村篇', desc:'信念锻刃，进展恶鬼', score: '5.8'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '茶啊二中 第三季', desc:'站内高分国创', score: '9.7'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '布莱泽奥特曼', desc:'新奥特英雄成长之路', score: '9.8'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '海绵宝宝 中文配音', desc:'站内高分番剧',score: '9.9'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '鬼灭之刃 刀匠村篇', desc:'信念锻刃，进展恶鬼', score: '5.8'),
      ChasingCellModel(imageUrl: 'https://t7.baidu.com/it/u=2511982910,2454873241&fm=193&f=GIF',
          title: '茶啊二中 第三季', desc:'站内高分国创', score: '9.7'),
    ]);
  }

  RxList<ChasingGuessCellModel>defaultGuessListData (){
    return RxList<ChasingGuessCellModel>([
      ChasingGuessCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '布莱泽奥特曼', desc:'新奥特英雄成长之路'),
      ChasingGuessCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '第一序列', desc:'人类文明依然屹立'),
      ChasingGuessCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '镇魂街 第三季', desc:'镇魂将至，古人归来'),
      ChasingGuessCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '镇魂街 第三季', desc:'镇魂将至，古人归来')
    ]);
  }
}