import 'package:get/get.dart';
import '../models/hot_board_tab_model.dart';
import '../models/hot_list_cell_model.dart';

class HotController extends GetxController {
  late RxList<HotBoardTabModel> boardTabData;
  late RxList<HotListCellModel> hotListData;

  void initData() {
    boardTabData = defaultBoardData();
    hotListData = RxList<HotListCellModel>([]);
    for(HotListCellModel cellModel in defaultHostListData()){
      if(cellModel.likeNum >= 10000) {
        cellModel.likeStr = "${(cellModel.likeNum.toDouble() / 10000).toStringAsFixed(2)}万点赞";
      }
      else {
        cellModel.likeStr = "${cellModel.likeNum}点赞";
      }
      if(cellModel.viewersNum >= 10000) {
        cellModel.viewersStr = "${(cellModel.viewersNum.toDouble() / 10000).toStringAsFixed(2)}万观看";
      }
      else {
        cellModel.viewersStr = "${cellModel.viewersNum}观看";
      }
      DateTime dateTime= DateTime.now();
      DateTime viewerTime = DateTime.parse(cellModel.timeStr);
      int days = 0;
      int hours = 0;
      int mints = 0;
      days = dateTime.difference(viewerTime).inDays;
      if(days <= 0){
        hours = dateTime.difference(viewerTime).inHours;
      }
      if(hours <=0 && days <= 0) {
        mints =  dateTime.difference(viewerTime).inMinutes;
      }
      if (days > 0) {
        cellModel.timeContent = "$days天前";
      }
      if (hours > 0) {
        cellModel.timeContent = "$hours小时前";
      }
      if (mints > 0) {
        cellModel.timeContent = "$mints分钟前";
      }
      hotListData.add(cellModel);
    }
  }

  void hotCellTap(HotListCellModel dataModel){

  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  RxList<HotBoardTabModel> defaultBoardData(){
    return RxList<HotBoardTabModel>( [
      HotBoardTabModel(iconName: 'assets/images/微信表情.png',title: '排行榜'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '热点日报'),
      HotBoardTabModel(iconName: 'assets/images/小程序.png',title: '每周必看'),
      HotBoardTabModel(iconName: 'assets/images/新的朋友.png',title: '黑马榜'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '入站必刷'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '宝藏音乐'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '看演出'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '音乐榜'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '一周秒评'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '美食'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '游戏榜'),
      HotBoardTabModel(iconName: 'assets/images/微信收藏.png',title: '短剧榜'),
    ]);
  }

  RxList<HotListCellModel> defaultHostListData(){
    return  RxList<HotListCellModel>([
      HotListCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '拖家带口', likeNum: 190000, nickName: '文武俩兄弟', viewersNum: 20011, timeStr: '2023-08-08 23:11:10'),
      HotListCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '总有不舍但还是分开了', likeNum: 170000, nickName: '我就是静静008', viewersNum: 201, timeStr: '2023-08-08 23:11:10'),
      HotListCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '藏族女孩误闯日本导演镜头，她的人生轨迹，竟因此彻底发生改边', likeNum: 10000, nickName: '人间放影厅', viewersNum: 30011, timeStr: '2023-08-08 23:11:10'),
      HotListCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '下水很成功，8月20号左右试航，具体时间定了，通知大家，视频', likeNum: 10200, nickName: '文武俩兄弟', viewersNum: 20011, timeStr: '2023-08-08 23:11:10'),
      HotListCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '胖东来争执事件，戳穿多少人虚伪的一面', likeNum: 770700, nickName: '文武俩兄弟', viewersNum: 2222, timeStr: '2023-08-08 23:11:10'),
      HotListCellModel(imageUrl: 'https://t7.baidu.com/it/u=727460147,2222092211&fm=193&f=GIF',
          title: '八段锦完整版[呼吸法+镜像跟脸]', likeNum: 190000, nickName: '文武俩兄弟', viewersNum: 20011, timeStr: '2023-08-08 23:11:10'),
    ]);
  }
}