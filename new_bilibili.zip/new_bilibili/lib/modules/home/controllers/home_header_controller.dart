import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/utils/app_const/app_toast.dart';

import '../models/home_head_model.dart';

class HomeHeaderController extends GetxController with GetSingleTickerProviderStateMixin{
  late RxInt currentTabIndex;
  late List<HomeTabModel> tabData;
  late List<Tab> tabs;
  late TabController tabController;

  void initData(){
    currentTabIndex = 0.obs;
    tabData = [
      HomeTabModel(title: '直播', index: 0, tabType: HomeTabType.homeTabTypeLive),
      HomeTabModel(title: '推荐', index: 1, tabType: HomeTabType.homeTabTypeRecommend),
      HomeTabModel(title: '热门', index: 2, tabType: HomeTabType.homeTabTypeHot),
      HomeTabModel(title: '追番', index: 3, tabType: HomeTabType.homeTabTypeZui),
      HomeTabModel(title: '影视', index: 4, tabType: HomeTabType.homeTabTypeMovie),
      HomeTabModel(title: '新征程', index: 5, tabType: HomeTabType.homeTabTypeNew),
    ];
    tabs = _createTabs();
    tabController = TabController(vsync: this, length: tabData.length);
  }

  void changeTabIndex(int index) {
    currentTabIndex = index.obs;
    tabController.index = currentTabIndex.value;
  }

  void openLive(){
      AppToast.toast('打开直播');
  }

  void openGame(){
    AppToast.toast('打开游戏');
  }

  void openMsg(){
    AppToast.toast('打开信封');
  }

  List<Tab> _createTabs(){
    List<Tab> tabs = [];
    for(HomeTabModel tabModel in tabData) {
      tabs.add(Tab(text: tabModel.title));
    }
    return tabs;
  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }

  @override
  void onReady() {
    super.onReady();
  }
  @override
  void onClose() {
    tabController.dispose();
  }

}