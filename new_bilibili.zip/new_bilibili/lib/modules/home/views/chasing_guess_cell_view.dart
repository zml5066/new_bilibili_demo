
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/chasing_controller.dart';
import '../models/chasing_guess_cell_model.dart';
import '../models/home_head_model.dart';

class ChasingGuessCellView <Controller extends ChasingController> extends GetView<Controller> {
  final ChasingGuessCellModel dataModel;
  final HomeTabType tabType;
  const ChasingGuessCellView({Key? key, required this.dataModel, required this.tabType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ()=>controller.openVideoDetailPage(tabType),
      child:  Column(
        children: [
          Container(
            width: 120,
            height: 100,
            alignment: Alignment.center,
            margin: const EdgeInsets.only(left: 5),
            clipBehavior: Clip.hardEdge,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(6)),
            child: CachedNetworkImage(
              imageUrl: dataModel.imageUrl,
              progressIndicatorBuilder: (context, url, downloadProgress) =>
                  LinearProgressIndicator(value: downloadProgress.progress),
            ),
          ),
          SizedBox(
            height: 20,
            child: Text(dataModel.title, style: const TextStyle(fontSize: 14, color: Colors.black)),
          ),
          SizedBox(
            height: 15,
            child: Text(dataModel.desc, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ),
        ],
      ),
    );
  }
}
