import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper_view/flutter_swiper_view.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../controllers/home_controller.dart';
import '../controllers/recommend_list_controller.dart';

class RecommendBannerView <Controller extends HomeRecommendListController> extends GetView<Controller> {
  const RecommendBannerView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height:160,
      margin: EdgeInsets.zero,
      child: Swiper(
        itemBuilder: (context, index){
          return CachedNetworkImage(imageUrl:controller.bannersList[index].imageUrl,fit:BoxFit.fill);
        },
        itemCount: controller.bannersList.length,
        autoplay:true,
        pagination: const SwiperPagination(),
      ),
    );

  }
}
