import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/home/controllers/chasing_controller.dart';
import '../models/hot_board_tab_model.dart';

class ChasingBoardView <Controller extends ChasingController> extends GetView<Controller> {
  const ChasingBoardView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90,
      child: ListView.builder(itemBuilder: (BuildContext context, int index){
        return _createChasingBoardCell(controller.boardTabList.obs.value[index]);
      }, scrollDirection: Axis.horizontal,itemCount: controller.boardTabList.obs.value.length),
    );
  }

  Widget _createChasingBoardCell(HotBoardTabModel dataModel){
    return Container(
      width: 60,
      height: 80,
      margin: const EdgeInsets.only(left: 5,right: 5),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 5),
            width: 30, height: 30,
            clipBehavior: Clip.hardEdge,
            decoration: BoxDecoration( borderRadius: BorderRadius.circular(50)),
            // child: Image(image:AssetImage(dataModel.iconName),fit: BoxFit.cover),
            child:  Image.asset(dataModel.iconName,fit: BoxFit.cover)
          ),
          const SizedBox(height: 5),
          Text(dataModel.title, style: const TextStyle(fontSize: 10))
        ],
      ),
    );
  }
}
