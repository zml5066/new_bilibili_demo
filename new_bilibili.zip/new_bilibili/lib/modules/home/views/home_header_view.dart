import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:new_bilibili/modules/home/views/home_tab_view.dart';
import 'package:new_bilibili/utils/app_const/app_colors.dart';

import '../../../utils/app_const/app_const.dart';
import '../controllers/home_header_controller.dart';
import 'home_search_view.dart';

class HomeHeaderView<Controller extends HomeHeaderController> extends GetView<Controller> {
   const HomeHeaderView({Key? key}) : super(key: key);

  // @override
  // Widget build(BuildContext context) {
  //   return Container(
  //     height: 110,
  //     width: AppConst.screenWidth(context),
  //     color: AppColors.whiteColor,
  //     child: const Column(
  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //       children: [
  //         HomeSearchView(),
  //         // Expanded(child: HomeTabView())
  //       ],
  //     )
  //   );
  // }
   @override
   Widget build(BuildContext context) {
     return Container(
         height: 40,
         width: AppConst.screenWidth(context),
         color: AppColors.whiteColor,
         child: const HomeSearchView()
     );
   }
}
