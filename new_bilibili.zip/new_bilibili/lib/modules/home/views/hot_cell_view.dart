import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../controllers/hot_controller.dart';
import '../models/hot_list_cell_model.dart';

class HotCellView<Controller extends HotController>
    extends GetView<Controller> {
  final HotListCellModel dataModel;

  const HotCellView({Key? key, required this.dataModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => controller.hotCellTap(dataModel),
      child: SizedBox(
        height: 150,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 180,
              height: 150,
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.only(left: 5),
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(6)),
              child: CachedNetworkImage(
                  imageUrl: dataModel.imageUrl,
                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                      LinearProgressIndicator(value: downloadProgress.progress)),
            ),
            Expanded(
                child: SizedBox(
              height: 150,
              child: Column(
                children: [
                  Container(
                      alignment: Alignment.centerLeft,
                      margin: const EdgeInsets.only(top: 22, left: 5),
                      child: Text(dataModel.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black))),
                  Container(
                    alignment: Alignment.centerLeft,
                    margin: const EdgeInsets.only(top: 13, left: 5),
                    child: dataModel.likeStr!.isNotEmpty
                        ? Text(dataModel.likeStr!,
                            style: const TextStyle(
                                fontSize: 10, color: Colors.redAccent))
                        : Container(),
                  ),
                  Container(
                      alignment: Alignment.centerLeft,
                      margin: const EdgeInsets.only(top: 12, left: 5),
                      child: Text(dataModel.nickName,
                          style: const TextStyle(
                              fontSize: 10, color: Colors.black87))),
                  Container(
                    alignment: Alignment.centerLeft,
                    margin: const EdgeInsets.only(top: 10, left: 5),
                    child: Row(
                      children: [
                        Container(
                          child: dataModel.viewersStr!.isNotEmpty
                              ? Text(dataModel.viewersStr!,
                                  style: const TextStyle(
                                      fontSize: 10, color: Colors.black87))
                              : Container(),
                        ),
                        Container(
                            margin: const EdgeInsets.only(left: 10),
                            child: Text(dataModel.timeContent!,
                                style: const TextStyle(
                                    fontSize: 10, color: Colors.black87))),
                      ],
                    ),
                  ),
                ],
              ),
            ))
          ],
        ),
      ),
    );
  }
}
