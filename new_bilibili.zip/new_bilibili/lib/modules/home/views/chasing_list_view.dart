import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../controllers/chasing_controller.dart';
import '../models/home_head_model.dart';
import 'chasing_advertise_view.dart';
import 'chasing_banner_view.dart';
import 'chasing_board_view.dart';
import 'chasing_cell_view.dart';
import 'chasing_guess_view.dart';

class ChasingListView <Controller extends ChasingController> extends GetView<Controller> {
  final HomeTabType tabType;
  const ChasingListView({Key? key, required this.tabType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      scrollDirection: Axis.vertical,
      children: [
        const ChasingBannerView(),
        const ChasingBoardView(),
        const ChasingAdvertiseView(),
        ChasingGuessView(tabType: tabType),
        Container(
          height: 20,
          margin: const EdgeInsets.only(left: 10,top: 20),
          child: const Text('正在热播',style: TextStyle(fontSize: 14, color: Colors.black),),
        ),
        GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            padding: const EdgeInsets.only(left: 5, right: 5, top: 5),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1),
            itemCount: controller.chasingList.obs.value.length,
            itemBuilder: (BuildContext context, int position) {
              return ChasingCellView(dataModel: controller.chasingList.obs.value[position],tabType: tabType);
            }
        )
      ],
    );
  }
}
