import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../../../utils/app_const/app_const.dart';
import '../controllers/home_header_controller.dart';

class HomeSearchView<Controller extends HomeHeaderController> extends GetView<Controller> {
  const HomeSearchView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      margin: EdgeInsets.only(top: AppConst.statusBarHeight(context) + 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
              margin: const EdgeInsets.only(left: 5), width: 40,
              child: IconButton(onPressed: ()=>controller.openLive(),
                  icon:const Icon(Icons.tv_sharp, color: Colors.grey))
          ),
          Expanded(
              child: GestureDetector(child:Container(
                padding: const EdgeInsets.all(5),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                        decoration:
                        BoxDecoration(color: Colors.white, borderRadius:BorderRadius.circular(6),border: Border.all(color: Colors.black54))),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(width: 10),
                        Icon(Icons.search,size: 15, color: Colors.black),
                        Text(' 搜索',style: TextStyle(fontSize: 12, color: Colors.black),)
                      ],
                    )
                  ],
                ),
              ) ,)
          ),
          Container(
            margin: const EdgeInsets.only(left: 0), width: 40,
            child: IconButton(onPressed: ()=>controller.openGame(),
                icon:const Icon(Icons.games_rounded, color: Colors.grey)),
          ),
          Container(
            margin: const EdgeInsets.only(left: 0, right: 0),width: 40,
            child: IconButton(onPressed: ()=>controller.openMsg(),
                icon:const Icon(Icons.legend_toggle_rounded, color: Colors.grey)),
          ),
        ],
      ),
    );
  }
}
