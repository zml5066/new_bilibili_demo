import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_swiper_view/flutter_swiper_view.dart';
import 'package:get/get.dart';
import '../controllers/chasing_controller.dart';

class ChasingBannerView <Controller extends ChasingController> extends GetView<Controller> {

  const ChasingBannerView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 160,
      margin: const EdgeInsets.only(top: 0),
      child: Swiper(
        itemBuilder: (context, index){
          return CachedNetworkImage(imageUrl:controller.bannersList.obs.value[index].imageUrl,fit:BoxFit.fill);
        },
        itemCount: controller.bannersList.obs.value.length,
        autoplay:true,
        pagination: const SwiperPagination(),
      ),
    );
  }
}
