// ignore_for_file: invalid_use_of_protected_member

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:new_bilibili/utils/app_const/app_colors.dart';
import '../controllers/home_header_controller.dart';

class HomeTabView<Controller extends HomeHeaderController>
    extends GetView<Controller> {
  const HomeTabView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      color: AppColors.whiteColor,
      child: TabBar(
        controller: controller.tabController,
        tabs: controller.tabs,
        unselectedLabelColor: Colors.black,
        labelColor: Colors.pinkAccent,
        indicatorColor: Colors.pinkAccent,
        isScrollable: true,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: const TextStyle(fontSize: 14, color: Colors.black),
        padding: const EdgeInsets.only(bottom: 10),
        onTap: (int value) {
          controller.changeTabIndex(value);
        },
      ),
    );
  }
}
