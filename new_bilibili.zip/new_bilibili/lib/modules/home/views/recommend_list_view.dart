import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/home/views/recommend_cell_view.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../controllers/recommend_list_controller.dart';
import '../models/home_head_model.dart';
import 'recommend_banner_view.dart';

class RecommendListView<Controller extends HomeRecommendListController>
    extends GetView<Controller> {
  final HomeTabType tabType;
  const RecommendListView({Key? key, required this.tabType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return SmartRefresher(
          enablePullDown: true,
          enablePullUp: true,
          header: const MaterialClassicHeader(),
          footer: CustomFooter(
            builder: (BuildContext context, LoadStatus? mode) {
              Widget body;
              if (mode == LoadStatus.idle) {
                body = const Text("上拉加载");
              } else if (mode == LoadStatus.loading) {
                body = const CupertinoActivityIndicator();
              } else if (mode == LoadStatus.failed) {
                body = const Text("加载失败！点击重试！");
              } else if (mode == LoadStatus.canLoading) {
                body = const Text("松手,加载更多!");
              } else {
                body = const Text("没有更多数据了!");
              }
              return SizedBox(height: 55.0, child: Center(child: body));
            },
          ),
          controller: controller.refreshController,
          onRefresh: controller.onRefresh,
          onLoading: controller.onLoading,
          child: ListView(
            children: [
              const RecommendBannerView(),
              GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  padding: const EdgeInsets.only(left: 5, right: 5, top: 5),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 1),
                  itemCount: controller.listData.obs.value.length,
                  itemBuilder: (BuildContext context, int position) {
                    return RecommendCellView(dataModel: controller.listData.obs.value[position], tabType: tabType,);}
              )
            ],
          ));
    });
  }
}
