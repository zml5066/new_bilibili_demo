import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/home/controllers/home_controller.dart';
import '../controllers/chasing_controller.dart';
import '../models/chasing_cell_model.dart';
import '../models/home_head_model.dart';

class ChasingCellView <Controller extends ChasingController > extends GetView<Controller> {
  final ChasingCellModel dataModel;
  final HomeTabType tabType;
  const ChasingCellView({Key? key, required this.dataModel, required this.tabType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ()=> Get.find<HomeController>().openLiveChatRoom(dataModel, tabType),
      child:Container(
        width: 180,height: 180,
        margin: const EdgeInsets.only(left: 0 ,right: 0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
                height: 120,
                alignment: Alignment.center,
                margin: const EdgeInsets.only(left: 5),
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(6)),
                child:Stack(
                  children: [
                    CachedNetworkImage(
                        imageUrl: dataModel.imageUrl,
                        progressIndicatorBuilder: (context, url, downloadProgress) =>
                            LinearProgressIndicator(value: downloadProgress.progress)),
                    Container(
                      alignment: Alignment.topRight,
                      margin: const EdgeInsets.only(right: 10,top: 5),
                      child: const Text('会员', style: TextStyle(fontSize: 12, color: Colors.red)),
                    )
                  ],
                )
            ),
            Container(
              height: 25,
              alignment: Alignment.centerLeft,
              child: Text(dataModel.title, style: const TextStyle(fontSize: 14, color: Colors.black)),
            ),
            SizedBox(
              height: 25,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: Row(
                      children: [
                        Text(dataModel.score, style: const TextStyle(fontSize: 10, color: Colors.white,backgroundColor: Colors.redAccent)),
                        Text(dataModel.desc, style: const TextStyle(fontSize: 10, color: Colors.grey)),
                      ],
                    ),
                  ),
                  Container(
                    child: const Icon(Icons.more_vert_outlined, color: Colors.grey,),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
