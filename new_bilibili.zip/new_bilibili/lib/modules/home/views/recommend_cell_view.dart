import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../controllers/recommend_list_controller.dart';
import '../models/home_head_model.dart';
import '../models/recommend_cell_model.dart';

class RecommendCellView <Controller extends HomeRecommendListController> extends GetView<Controller> {

  final RecommendCellModel dataModel;
  final HomeTabType tabType;
  const RecommendCellView({Key? key, required this.dataModel, required this.tabType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ()=>controller.recommendCellTap(dataModel, tabType),
      child: Container(
        color: Colors.white12,
        child: Column(
          children: [
            Expanded(child: CachedNetworkImage(imageUrl: dataModel.url,
                progressIndicatorBuilder: (context, url, downloadProgress) =>
                    LinearProgressIndicator(value: downloadProgress.progress))
            ),
            Text(dataModel.title, style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const Icon(Icons.add_alarm_outlined, color: Colors.black26),
                const SizedBox(width: 5),
                Text(dataModel.upName,style: const TextStyle(fontSize: 12, color: Colors.black26)),
              ],
            )
          ],
        ),
      ),
    );
  }
}
