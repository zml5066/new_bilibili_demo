import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/chasing_controller.dart';

class ChasingAdvertiseView <Controller extends ChasingController> extends GetView<Controller> {
  const ChasingAdvertiseView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 8, right: 8),
      height: 100,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(5),
          gradient: const LinearGradient(
            colors: [Color(0xFFfbab66), Color(0xFFf7418c)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          )
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            margin: const EdgeInsets.only(left: 20),
            height: 50,
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('限量2233份', style: TextStyle(fontSize: 12, color: Colors.white)),
                SizedBox(height: 8),
                Text('4.7折开大会员*网易云音乐双年卡', style: TextStyle(fontSize: 12, color: Colors.white)),
              ],
            ),
          ),
          SizedBox(
            height: 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                MaterialButton(
                  color: Colors.redAccent,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all( Radius.circular(8))),
                  height: 32,minWidth: 60,
                  onPressed: () =>controller.openActivity,
                  child: const Text("立即开通",style: TextStyle(fontSize: 12, color: Colors.white)),
                ),
                const SizedBox(width: 10),
                Container(
                  margin: const EdgeInsets.only(right: 15),
                  width: 15,
                  height: 32,
                  child: GestureDetector(
                    onTap: ()=>controller.closeAdvertise,
                    child: const Icon(Icons.close,color: Colors.white,),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
