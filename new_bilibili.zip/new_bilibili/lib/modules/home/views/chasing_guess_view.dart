import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/home/views/chasing_guess_cell_view.dart';
import '../controllers/chasing_controller.dart';
import '../models/home_head_model.dart';

class ChasingGuessView  <Controller extends ChasingController> extends GetView<Controller> {
  final HomeTabType tabType;
  const ChasingGuessView({Key? key, required this.tabType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 175,
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(left: 8,right: 8,top: 20),
            height: 20,
            child:const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('猜你想追',style: TextStyle(fontSize: 14, color: Colors.black)),
                Row(
                  children: [
                    Text('我的追番',style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Icon(Icons.arrow_forward_ios,size: 15,color: Colors.grey),
                  ],
                ),
              ],
            ),
          ),
          Expanded(child:
          ListView.builder(itemBuilder: (BuildContext context, int index){
            return ChasingGuessCellView(dataModel: controller.guessList.obs.value[index], tabType: tabType);
          }, scrollDirection: Axis.horizontal,itemCount: controller.guessList.obs.value.length)
          )
        ],
      ),
    );
  }
}
