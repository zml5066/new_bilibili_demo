import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../controllers/hot_controller.dart';
import 'hot_cell_view.dart';
import 'hot_list_board_view.dart';

class HotListView <Controller extends HotController> extends GetView<Controller> {
  const HotListView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
   return Obx(() {
     return ListView(
       children: [
         const HotListBoardView(),
         ListView.builder(itemBuilder: (BuildContext context, int index){
           return HotCellView(dataModel: controller.hotListData[index]);
         },itemCount: controller.hotListData.length,shrinkWrap: true,physics: const NeverScrollableScrollPhysics(),)
       ],
     );
   });
  }
}
