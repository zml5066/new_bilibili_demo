import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/home/controllers/home_header_controller.dart';
import 'package:new_bilibili/modules/home/views/home_header_view.dart';
import '../controllers/home_controller.dart';
import '../models/home_head_model.dart';
import '../views/chasing_list_view.dart';
import '../views/home_tab_view.dart';
import '../views/hot_list_view.dart';
import '../views/recommend_list_view.dart';

class HomePage<Controller extends HomeController> extends GetView<Controller> {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        toolbarHeight: 0,
      ),
      body: _createNestedScrollView(),
    );
  }
  NestedScrollView _createNestedScrollView() {
    return NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            const SliverAppBar(
              pinned: true,
              floating: true,
              expandedHeight: 90,
              flexibleSpace: HomeHeaderView(),
              bottom: PreferredSize(
                preferredSize: Size(double.infinity, 40),
                child: HomeTabView(),
              ),
            ),
          ];
        },
        body: TabBarView(
          controller: Get.find<HomeHeaderController>().tabController,
          children: Get.find<HomeHeaderController>().tabData.map((HomeTabModel tabModel) {
            if (tabModel.tabType == HomeTabType.homeTabTypeRecommend) {
              return const RecommendListView(tabType: HomeTabType.homeTabTypeRecommend,);
            }
            if (tabModel.tabType == HomeTabType.homeTabTypeHot){
              return const HotListView();
            }
            if (tabModel.tabType == HomeTabType.homeTabTypeZui){
              return const ChasingListView(tabType: HomeTabType.homeTabTypeZui,);
            }
            if (tabModel.tabType == HomeTabType.homeTabTypeMovie){
              return const ChasingListView(tabType:HomeTabType.homeTabTypeMovie ,);
            }
            if (tabModel.tabType == HomeTabType.homeTabTypeNew){
              return const ChasingListView(tabType: HomeTabType.homeTabTypeNew,);
            }
            if (tabModel.tabType == HomeTabType.homeTabTypeLive){
              return const ChasingListView(tabType: HomeTabType.homeTabTypeLive,);
            }

            return const ChasingListView(tabType: HomeTabType.homeTabTypeNew);
          }).toList(),
        )
    );
  }
}
