
class HomeHeadState {

}