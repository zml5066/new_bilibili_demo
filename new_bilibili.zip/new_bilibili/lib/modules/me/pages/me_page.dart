import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:new_bilibili/modules/me/views/me_header_view.dart';
import 'package:new_bilibili/utils/app_const/app_colors.dart';
import '../controllers/me_controller.dart';
import '../views/me_cache_view.dart';
import '../views/me_cell_view.dart';
import '../views/me_create_center.dart';
import '../views/me_game_center_view.dart';
import '../views/me_join_membership_view.dart';
import '../views/me_more_view.dart';
import '../views/recommend_service_view.dart';

class MePage <Controller extends MeController> extends GetView<Controller>{
  const MePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:AppColors.statusBarColor,
        elevation: 0.0,
        toolbarHeight: 0,
      ),
      body: Column(
        children: [
          const MeHeaderView(),
          const MeJoinMemberShipView(),
          Expanded(child: ListView(
            scrollDirection: Axis.vertical,
            children: const [
              MeCacheView(),
              MeCreateCenterView(),
              MeGameCenterView(),
              RecommendServiceView(),
              MeMoreView(),
            ],
          ),),
        ],
      )
    );
  }
}
