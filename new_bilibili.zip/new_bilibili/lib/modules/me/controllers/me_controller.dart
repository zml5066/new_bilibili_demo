import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../utils/app_const/app_toast.dart';
import '../models/me_cell_model.dart';
import '../models/user_info_model.dart';

class MeController extends GetxController {
  late Rx<UserInfoModel> infoModel;
  late RxList<MeCellModel>cacheList;
  late RxList<MeCellModel>createCenterList;
  late RxList<MeCellModel>gameCenterList;
  late RxList<MeCellModel>recommendServiceList;
  late RxList<MeCellModel>moreServiceList;

  void initData() {
    infoModel = _defaultUserInfoData();
    cacheList = _defaultCacheListData();
    createCenterList = _defaultCreateCenter();
    gameCenterList = _defaultGameCenter();
    recommendServiceList = _defaultRecommendService();
    moreServiceList = _defaultMoreService();
  }

  void openBiliTV() {
    AppToast.toast('哔哩哔哩电视');
  }

  void openQRCode() {
    AppToast.toast('扫一扫');
  }

  void openDressUp() {
    AppToast.toast('装扮商城');
  }

  /// 日夜间切换
  void openChangeThem() {
    if (Get.isDarkMode) {
      Get.changeTheme(ThemeData.light());
    }
    else {
      Get.changeTheme(ThemeData.dark());
    }
  }

  void openMeSpace(){
    AppToast.toast('个人空间');
    //   state.iszhCN = false;
    var locale = const Locale('en', 'US');
    Get.updateLocale(locale);
  }

  void openMePage(){
    AppToast.toast('个人主页');
    var locale = const Locale('zh', 'CN');
    Get.updateLocale(locale);
  }

  void modifyNickName() {
    AppToast.toast('修改昵称');
  }

  void cellViewTap(MeCellModel dataModel){
    AppToast.toast('点击了${dataModel.name}');
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    initData();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  Rx<UserInfoModel> _defaultUserInfoData() {
    return Rx(UserInfoModel(
        avatarUrl: 'https://randomuser.me/api/portraits/men/46.jpg',
        nickName: '小样子',
        level: '4',
        bNum: '10',
        coinNum: '12',
        dynamicNum: '122',
        attentionNum: '100',
        fanNum: '1')
    );
  }
  RxList<MeCellModel> _defaultCacheListData(){
    return RxList([
      MeCellModel(iconName: 'assets/images/海洋之心.png', name: '离线缓存',type: 0),
      MeCellModel(iconName: 'assets/images/红叶大道.png', name: '历史记录',type: 1),
      MeCellModel(iconName: 'assets/images/嗨翻全场.png', name: '我的收藏',type: 2),
      MeCellModel(iconName: 'assets/images/极速超跑.png', name: '稍后再看',type: 3),
    ]);
  }
  RxList<MeCellModel> _defaultCreateCenter(){
    return RxList([
      MeCellModel(iconName: 'assets/images/D言D语.png', name: '创作中心',type: 4),
      MeCellModel(iconName: 'assets/images/IVL冲冲冲.png', name: '稿件管理',type: 5),
      MeCellModel(iconName: 'assets/images/一箭倾心.png', name: '任务中心',type: 6),
      MeCellModel(iconName: 'assets/images/海洋之心.png', name: '有奖活动',type: 7),
    ]);
  }

  RxList<MeCellModel> _defaultGameCenter(){
    return RxList([
      MeCellModel(iconName: 'assets/images/马了顶大.png', name: '我的预约',type: 8),
      MeCellModel(iconName: 'assets/images/金币.png', name: '找游戏',type: 9),
      MeCellModel(iconName: 'assets/images/赛事劫宝.png', name: '游戏排行榜',type: 10),
      MeCellModel(iconName: 'assets/images/铃兰花.png', name: '游戏礼包',type: 11),
    ]);
  }
  RxList<MeCellModel> _defaultRecommendService(){
    return RxList([
      MeCellModel(iconName: 'assets/images/荧光马车.png', name: '我的课程',type: 12),
      MeCellModel(iconName: 'assets/images/红叶大道.png', name: '免流量服务',type: 13),
      MeCellModel(iconName: 'assets/images/美满.png', name: '个性装扮',type: 14),
      MeCellModel(iconName: 'assets/images/闪耀R星.png', name: '邀好友赚红包',type: 15),
      MeCellModel(iconName: 'assets/images/马了顶大.png', name: '我的钱包',type: 16),
      MeCellModel(iconName: 'assets/images/金币.png', name: '会员购中心',type: 17),
      MeCellModel(iconName: 'assets/images/赛事劫宝.png', name: '我的直播',type: 18),
      MeCellModel(iconName: 'assets/images/铃兰花.png', name: '社区中心',type: 19),
      MeCellModel(iconName: 'assets/images/聆听.png', name: '哔哩哔哩公益',type: 20),
      MeCellModel(iconName: 'assets/images/踏青日记.png', name: '能量加油站',type: 21),
      MeCellModel(iconName: 'assets/images/震撼声浪.png', name: '大会员4.2折',type: 22),
      MeCellModel(iconName: 'assets/images/积分加成卡.png', name: '时光照相馆',type: 23),
    ]);
  }

  RxList<MeCellModel> _defaultMoreService(){
    return RxList([
      MeCellModel(iconName: 'assets/images/泡泡机.png', name: '联系客服',type: 24),
      MeCellModel(iconName: 'assets/images/森林花路.png', name: '听视频',type: 25),
      MeCellModel(iconName: 'assets/images/玲珑福袋.png', name: '青少年守护',type: 26),
      MeCellModel(iconName: 'assets/images/草莓蛋糕.png', name: '设置',type: 27),
    ]);
  }
}
