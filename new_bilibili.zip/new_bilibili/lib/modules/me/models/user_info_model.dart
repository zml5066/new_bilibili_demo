class UserInfoModel {
  String avatarUrl;
  String nickName;
  String level;
  String bNum;
  String coinNum;
  String dynamicNum;
  String attentionNum;
  String fanNum;

  UserInfoModel(
      {required this.avatarUrl,
      required this.nickName,
      required this.level,
      required this.bNum,
      required this.coinNum,
      required this.dynamicNum,
      required this.attentionNum,
      required this.fanNum});
}
