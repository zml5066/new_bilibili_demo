
class MeCellModel {
  String iconName;
  String name;
  int type;
  MeCellModel({required this.iconName, required this.name, required this.type});
}