import 'package:get/get.dart';
import '../controllers/me_controller.dart';

class MeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MeController>(() =>MeController());
  }
}

// void changeEn() {
//   state.iszhCN = false;
//   var locale = const Locale('en', 'US');
//   Get.updateLocale(locale);
// }
// void changeZh(){
//   state.iszhCN = true;
//   var locale = const Locale('zh', 'CN');
//   Get.updateLocale(locale);
// }
//
