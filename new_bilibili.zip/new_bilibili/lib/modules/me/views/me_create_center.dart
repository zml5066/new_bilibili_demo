import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/me/controllers/me_controller.dart';

import 'me_cell_view.dart';

class MeCreateCenterView<Controller extends MeController> extends GetView<Controller> {
  const MeCreateCenterView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      margin: const EdgeInsets.only(left: 5, right: 5),
      child:  Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('创作中心',style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              Stack(
                children: [
                  ElevatedButton.icon(
                    style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.resolveWith((states) {
                        return Colors.pinkAccent;
                      },
                      ),
                      backgroundColor: MaterialStateProperty.resolveWith((states) {
                        return Colors.pinkAccent;
                      }),
                      overlayColor: MaterialStateProperty.all(Colors.pinkAccent),
                      minimumSize: MaterialStateProperty.all(const Size(90, 36)),
                      ///设置按钮圆角
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20))),
                    ),
                    icon: const Icon(Icons.upload_outlined, color: Colors.white),
                    label: const Text("发送", style: TextStyle(fontSize: 14, color: Colors.white)),
                    onPressed: (){},
                  ),
                  Container(
                    height: 10,
                    width: 10,
                    margin:const EdgeInsets.only(top: 5,left: 80),
                    decoration:
                    const BoxDecoration(shape: BoxShape.circle, color: Colors.blue),
                  ),
                ],
              )
            ],
          ),
          Expanded(child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              padding: const EdgeInsets.only(left: 5, right: 5, top: 5),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1),
              itemCount: controller.createCenterList.length,
              itemBuilder: (BuildContext context, int position) {
                return MeCellView(dataModel: controller.createCenterList.obs.value[position]);
              }
          ))
        ],
      ),
    );
  }
}
