import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/me/controllers/me_controller.dart';

class MeJoinMemberShipView<Controller extends MeController>
    extends GetView<Controller> {
  const MeJoinMemberShipView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          gradient: const LinearGradient(
            colors: [Color.fromRGBO(251, 171, 102, 0.2),Color.fromRGBO(247, 65, 140, 0.2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          )),
      margin: const EdgeInsets.only(left: 5, right: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: const Row(
              children: [
                ClipOval(
                  child: Image(
                    image: AssetImage('assets/images/天空之翼.png'),
                    height: 40,
                    width: 40,
                    fit: BoxFit.cover,
                  ),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('萌节特惠',style: TextStyle(fontSize: 14, color: Colors.deepOrangeAccent),),
                    Text('大会员年卡低至0.26元每天',style: TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                )
              ],
            ),
          ),
         Container(
           height: 32,
           margin: const EdgeInsets.only(right: 10),
           child: TextButton(
               onPressed: () {},
               style: ButtonStyle(
                   backgroundColor: MaterialStateProperty.resolveWith((states) {
                     if (states.contains(MaterialState.hovered)) {
                       return Colors.white;
                     }
                     return Colors.white;
                   })),
               child: const Text('立即开通',
                   style: TextStyle(fontSize: 14, color: Colors.purpleAccent))),
         )
        ],
      ),
    );
  }
}
