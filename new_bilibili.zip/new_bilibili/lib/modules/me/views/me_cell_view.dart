import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/me/controllers/me_controller.dart';

import '../models/me_cell_model.dart';

class MeCellView<Controller extends MeController> extends GetView<Controller> {
  final MeCellModel dataModel;
  const MeCellView({super.key, required this.dataModel});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ()=>controller.cellViewTap(dataModel),
      child: Container(
        height: 50,
        width: 50,
        alignment: Alignment.center,
        child: Column(
          children: [
            Container(
              alignment: Alignment.center,
              width: 25,height: 25,
              child: Image.asset(dataModel.iconName)
            ),
            const SizedBox(height: 3),
            Text(dataModel.name, style: const TextStyle(fontSize: 14, color: Colors.black)),
          ],
        ),
      ),
    );
  }
}
