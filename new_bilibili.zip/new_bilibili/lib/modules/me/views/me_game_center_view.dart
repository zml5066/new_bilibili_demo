import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/me/controllers/me_controller.dart';

import 'me_cell_view.dart';
class MeGameCenterView<Controller extends MeController> extends GetView<Controller> {
  const MeGameCenterView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5, top: 20),
      height: 100,
      child: Column(
        children:  [
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
               Text('游戏中心',style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
               Row(
                children: [
                   Text('查看更多',style: TextStyle(fontSize: 12,color: Colors.grey)),
                   Icon(Icons.arrow_forward_ios_rounded, color: Colors.grey,size: 12),
                ],
              )
            ],
          ),
          Expanded(child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              padding: const EdgeInsets.only(left: 5, right: 5, top: 5),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1),
              itemCount: controller.gameCenterList.length,
              itemBuilder: (BuildContext context, int position) {
                return MeCellView(dataModel: controller.gameCenterList.obs.value[position]);
              }
          ))
        ],
      ),
    );
  }
}
