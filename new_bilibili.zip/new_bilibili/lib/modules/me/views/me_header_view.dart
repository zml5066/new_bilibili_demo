import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/me/controllers/me_controller.dart';

class MeHeaderView<Controller extends MeController>
    extends GetView<Controller> {
  const MeHeaderView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.amberAccent,
      height: 180,
      child: GestureDetector(
        onTap: ()=>controller.openMePage(),
        child: Column(
          children: [
            _createTopButtons(),
            _createAvatar(),
            _createFan(),
          ],
        ),
      ),
    );
  }

  Widget _createTopButtons() {
    return Container(
      margin: const EdgeInsets.only(right: 15),
      height: 30,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          GestureDetector(
              onTap: () => controller.openBiliTV(),
              child: const Icon(Icons.tv_sharp, color: Colors.grey, size: 20)),
          const SizedBox(width: 25),
          GestureDetector(
              onTap: () => controller.openQRCode(),
              child: const Icon(Icons.qr_code_rounded,
                  color: Colors.grey, size: 20)),
          const SizedBox(width: 25),
          GestureDetector(
              onTap: () => controller.openDressUp(),
              child:
                  const Icon(Icons.cabin_sharp, color: Colors.grey, size: 20)),
          const SizedBox(width: 25),
          GestureDetector(
              onTap: () => controller.openChangeThem(),
              child: const Icon(Icons.nightlight_sharp,
                  color: Colors.grey, size: 20)),
        ],
      ),
    );
  }

  Widget _createAvatar() {
    return Container(
      // color: Colors.amberAccent,
      height: 90,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                SizedBox(
                  width: 60,
                  height: 60,
                  child: ClipOval(
                    child: CachedNetworkImage(
                        fit: BoxFit.cover,
                        imageUrl: controller.infoModel.value.avatarUrl,
                        progressIndicatorBuilder:
                            (context, url, downloadProgress) =>
                                LinearProgressIndicator(
                                    value: downloadProgress.progress)),
                  ),
                ),
                SizedBox(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          margin: const EdgeInsets.only(left: 10, top: 10),
                          child:Row(
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    color: Colors.black26,
                                  ),
                                  child:GestureDetector(
                                    onTap: ()=>controller.modifyNickName(),
                                    child: Row(
                                      children: [
                                        Text(controller.infoModel.value.nickName,
                                            style: const TextStyle(
                                                fontSize: 14, color: Colors.black)),
                                        const SizedBox(width: 1),
                                        const Icon(Icons.chevron_right_sharp,
                                            color: Colors.grey)
                                      ],
                                    ),
                                  )),
                              const SizedBox(width: 5),
                              GestureDetector(
                                onTap: ()=>controller.openMePage(),
                                child: const Icon(Icons.edit, size: 20, color: Colors.grey),
                              ),
                              GestureDetector(
                                onTap: ()=>controller.openMePage(),
                                child:Text('Level${controller.infoModel.value.level}', style: const TextStyle(fontSize: 14, color: Colors.orangeAccent),),

                              )
                            ],
                          ),
                          ),
                      Container(
                        margin: const EdgeInsets.only(left: 10, top: 5),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.redAccent, width: 1),
                          borderRadius: BorderRadius.circular((5.0)),
                        ),
                        width: 50,
                        height: 20,
                        child: GestureDetector(
                          onTap: ()=>controller.openMePage(),
                          child: const Text('正式会员',
                              style: TextStyle(
                                  fontSize: 10, color: Colors.redAccent)),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 10, top: 5),
                        width: 200,
                        height: 25,
                        child: GestureDetector(
                          onTap:()=>controller.openMePage(),
                          child: Row(
                            children: [
                              Text('B币:  ${controller.infoModel.value.bNum}',
                                  style: const TextStyle(
                                      fontSize: 10, color: Colors.grey)),
                              Expanded(
                                child: Text(
                                    '硬币:  ${controller.infoModel.value.coinNum}',
                                    style: const TextStyle(
                                        fontSize: 10, color: Colors.grey)),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          SizedBox(
              width: 60,
              child: TextButton(
                child: const Row(
                  children: [
                    Text('空间',
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Icon(Icons.keyboard_arrow_right,
                        size: 20, color: Colors.grey)
                  ],
                ),
                onPressed: () => controller.openMeSpace(),
              ))
        ],
      ),
    );
  }

  Widget _createFan(){
    return GestureDetector(
      onTap: ()=>controller.openMePage(),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _createDynamic(controller.infoModel.value.dynamicNum, '动态'),
          Container(
            width: 1,
            height: 20,
            color: Colors.grey,
          ),
          _createDynamic(controller.infoModel.value.attentionNum, '关注'),
          Container(
            width: 1,
            height: 20,
            color: Colors.grey,
          ),
          _createDynamic(controller.infoModel.value.fanNum, '粉丝'),
        ],
      ),
    );
  }

  Widget _createDynamic(String num, String textStr){
    return Container(
      margin:const EdgeInsets.only(left: 10, right: 10,top: 10),
      height: 50,
      width: 50,
      alignment: Alignment.center,
      child: Column(
        children: [
          Text(num, style: const TextStyle(fontSize: 14, color: Colors.black)),
          Text(textStr, style: const TextStyle(fontSize: 14, color: Colors.black)),
        ],
      ),
    );
  }
}
