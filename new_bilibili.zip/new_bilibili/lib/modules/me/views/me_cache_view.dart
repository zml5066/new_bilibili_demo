import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/me/controllers/me_controller.dart';

import 'me_cell_view.dart';

class MeCacheView<Controller extends MeController> extends GetView<Controller> {
  const MeCacheView({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        padding: const EdgeInsets.only(left: 5, right: 5, top: 5),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1),
        itemCount: controller.cacheList.length,
        itemBuilder: (BuildContext context, int position) {
          return MeCellView(dataModel: controller.cacheList.obs.value[position]);
        }
    )
    ;
  }
}
