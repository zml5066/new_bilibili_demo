import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/me/controllers/me_controller.dart';

import '../models/me_cell_model.dart';

class MeMoreView<Controller extends MeController> extends GetView<Controller> {
  const MeMoreView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5, top: 10),
      height: 250,
      child: Column(
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('更多服务',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              Row(
                children: [
                  Text('', style: TextStyle(fontSize: 12, color: Colors.grey)),
                ],
              )
            ],
          ),
          Expanded(
              child: ListView.builder(
            itemBuilder: (BuildContext context, int index) {
              MeCellModel dataModel = controller.moreServiceList[index];
              return GestureDetector(
                onTap:()=>controller.cellViewTap(dataModel),
                child: Container(
                  height: 30,
                  margin: const EdgeInsets.only(top: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          margin: const EdgeInsets.only(right: 10),
                          width: 25,
                          height: 25,
                          child: Image.asset(dataModel.iconName)),
                      Expanded(
                          child: Text(dataModel.name,
                              style: const TextStyle(
                                  fontSize: 14, color: Colors.black))),
                      Container(
                          margin: const EdgeInsets.only(right: 5),
                          alignment: Alignment.bottomRight,
                          width: 25,
                          height: 25,
                          child: const Icon(Icons.arrow_forward_ios_rounded,
                              color: Colors.grey, size: 20)),
                    ],
                  ),
                ),
              );
            },
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: controller.moreServiceList.obs.value.length,
          ))
        ],
      ),
    );
  }
}
