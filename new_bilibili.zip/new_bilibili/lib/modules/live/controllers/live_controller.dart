import 'package:get/get.dart';

class LiveController extends GetxController{

  void goBack(){
    Get.back();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();

  }

}