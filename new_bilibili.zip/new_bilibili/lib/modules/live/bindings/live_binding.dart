import 'package:get/get.dart';
import '../../../utils/app_web_rtc/local_video_controller.dart';
import '../controllers/live_controller.dart';

class LiveBinding extends Bindings {
  @override
  void dependencies() {
     Get.lazyPut<LiveController>(() =>LiveController());
     Get.lazyPut<LocalVideoController>(() =>LocalVideoController());

  }
}