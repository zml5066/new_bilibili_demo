import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live/controllers/live_controller.dart';
import 'package:new_bilibili/modules/live/views/live_header_view.dart';

import '../../../utils/app_web_rtc/local_video_view.dart';

class LivePage<Controller extends LiveController> extends GetView<Controller> {
  const LivePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MediaQuery.removePadding(
        removeTop: true,
        context: context,
        child: MediaQuery.removePadding(
            context: context,
            removeBottom: true,
            removeTop: true,
            child: Stack(
              children: [
                Positioned.fill(child: Image.asset("assets/images/chat_back.jpg", fit: BoxFit.cover)),
                  const Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    LiveHeaderView(),
                    LocalVideoView(),
                  ],
                ),
              ],
            )
        ),
      )
    );
  }
}
