import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/live/controllers/live_controller.dart';
import 'package:new_bilibili/utils/app_const/app_colors.dart';
import 'package:new_bilibili/utils/app_const/app_const.dart';

class LiveHeaderView<Controller extends LiveController>
    extends GetView<Controller> {
  const LiveHeaderView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.liveChatBgColor,
      width: AppConst.screenWidth(context),
      margin: const EdgeInsets.only(left: 0, right: 0, top: 0),
      height: 120,
      child: Row(
        children: [
          GestureDetector(
            onTap: () => controller.goBack(),
            child: const Icon(Icons.arrow_back_ios, color: Colors.white),
          )
        ],
      ),
    );
  }
}
