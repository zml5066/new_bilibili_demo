import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/state_manager.dart';
import 'package:new_bilibili/modules/dynamic/controllers/dynamic_controller.dart';

import '../models/last_visit_model.dart';

class LastVisitView<Controller extends DynamicController>
    extends GetView<Controller> {
  const LastVisitView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Container(
        height: 105,
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 20,
              margin: const EdgeInsets.only(left: 10, right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('最近访问',
                      style: TextStyle(
                          fontSize: 14,
                          color: Colors.black,
                          fontWeight: FontWeight.bold)),
                  GestureDetector(
                    onTap: () => controller.openMorePage(),
                    child: const Text('查看更多>',
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                  ),
                ],
              ),
            ),
            Expanded(child: ListView.builder(itemBuilder: (BuildContext context, int index){
              return _createVisitCell(controller.visitList.obs.value[index]);
            },
              itemCount: controller.visitList.obs.value.length,
              scrollDirection: Axis.horizontal,
            )
            ),
          ],
        ),
      );
    });
  }

  Widget _createVisitCell(LastVisitModel dataModel) {
    return GestureDetector(
      onTap: ()=>controller.openVisitUp(dataModel),
      child: Container(
        height: 80,
        margin: const EdgeInsets.only(top: 5, left: 5,right: 5),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipOval(
              child: CachedNetworkImage(
                  fit: BoxFit.cover,
                  width: 45,
                  height: 45,
                  imageUrl: dataModel.imageUrl,
                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                      LinearProgressIndicator(value: downloadProgress.progress)),
            ),
            Container(
              margin: const EdgeInsets.only(top: 5),
              height: 30,
              width: 45,
              child: Text(
                dataModel.name,
                style: const TextStyle(fontSize: 11, color: Colors.black),
              ),
            )
          ],
        ),
      ),
    );
  }
}
