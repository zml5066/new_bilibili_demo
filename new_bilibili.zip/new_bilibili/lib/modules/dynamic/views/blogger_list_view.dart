import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/dynamic/controllers/dynamic_controller.dart';
import 'package:new_bilibili/modules/dynamic/views/blogger_cell_view.dart';

class BloggerListView<Controller extends DynamicController> extends GetView<Controller> {
  const BloggerListView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(itemBuilder: (BuildContext context, int index){
      return BloggerCellView(dataModel: controller.bloggerList.obs.value[index]);
    },
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: controller.bloggerList.obs.value.length,
    );
  }
}
