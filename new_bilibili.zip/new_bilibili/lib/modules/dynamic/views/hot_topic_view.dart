import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/dynamic/controllers/dynamic_controller.dart';

class HotTopicView<Controller extends DynamicController> extends GetView<Controller> {
  const HotTopicView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      height: 130,
      margin: const EdgeInsets.only(top: 5),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 20,
            margin: const EdgeInsets.only(left: 10, right: 10,bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Row(
                  children: [
                    Icon(
                      Icons.hdr_plus,
                      color: Colors.blue,
                      size: 20,
                    ),
                    SizedBox(width: 5),
                    Text('热门话题',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.black,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
                GestureDetector(
                  onTap: () => controller.openHotUpMorePage(),
                  child: const Text('查看更多>',
                      style: TextStyle(fontSize: 12, color: Colors.grey)),
                ),
              ],
            ),
          ),
          GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 5,
              crossAxisSpacing: 5,
              childAspectRatio:10,
            ),
            itemBuilder: (BuildContext context, int index){
              return Container(
                  child:Text(controller.topicList[index].topic,style: const TextStyle(fontSize: 12, color: Colors.black))
              );
            },itemCount: controller.topicList.length,
          )
        ],
      ),
    );
  }
}
