import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../utils/app_const/app_const.dart';
import '../controllers/dynamic_controller.dart';
import '../models/blogger_cell_model.dart';

class BloggerCellView<Controller extends DynamicController>
    extends GetView<Controller> {
  final BloggerCellModel dataModel;

  const BloggerCellView({super.key, required this.dataModel});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      margin: const EdgeInsets.only(top: 5),
      color: Colors.white,
      child: Column(
        children: [
          _createAvatarView(dataModel),
          dataModel.isVideo
              ? Expanded(child: _createVideoView(dataModel))
              : Expanded(child: _createArticleView(dataModel)),
          _createButtons(dataModel),
        ],
      ),
    );
  }

  Widget _createAvatarView(BloggerCellModel dataModel) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5, top: 10),
      height: 40,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              ClipOval(
                child: CachedNetworkImage(
                    fit: BoxFit.cover,
                    width: 40,
                    height: 40,
                    imageUrl: dataModel.avatarUrl,
                    progressIndicatorBuilder:
                        (context, url, downloadProgress) =>
                            LinearProgressIndicator(
                                value: downloadProgress.progress)
                ),
              ),
              Container(
                margin: const EdgeInsets.only(left: 5, right: 5),
                alignment: Alignment.centerLeft,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(dataModel.bloggerName,
                        style: const TextStyle(
                            fontSize: 14,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                        textAlign: TextAlign.left),
                    Text(
                        '${dataModel.time} 投稿了${dataModel.isVideo ? '视频' : '文章'}',
                        style:
                            const TextStyle(fontSize: 14, color: Colors.grey),
                        textAlign: TextAlign.left)
                  ],
                ),
              ),
            ],
          ),
          Container(
            alignment: Alignment.centerRight,
            width: 25,
            height: 30,
            margin: const EdgeInsets.only(right: 0),
            child: GestureDetector(
              onTap: () => controller.openBloggerMorePage(dataModel),
              child: const Icon(
                Icons.more_vert,
                color: Colors.grey,
                size: 25,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _createButtons(BloggerCellModel dataModel) {
    return Container(
      height: 25,
      margin: const EdgeInsets.only(left: 10, right: 10, top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: ()=>controller.openShare(dataModel),
            child: _createShareBtn( Icons.mobile_screen_share_outlined, dataModel.shareNum),
          ),
          GestureDetector(
            onTap: ()=>controller.openComment(dataModel),
            child:_createShareBtn(Icons.mode_comment_outlined, dataModel.commentNum),
          ),
          GestureDetector(
            onTap: ()=>controller.likeBlogger(dataModel),
            child:_createShareBtn(Icons.clean_hands, dataModel.likeNum),
          ),
        ],
      ),
    );
  }

  Widget _createShareBtn(IconData icon, String num) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 20, color: Colors.grey),
        const SizedBox(width: 2),
        Text(num, style: const TextStyle(fontSize: 12, color: Colors.grey))
      ],
    );
  }

  Widget _createVideoView(BloggerCellModel dataModel) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5),
      child: Stack(
        alignment: AlignmentDirectional.bottomEnd,
        children: [
          CachedNetworkImage(
              fit: BoxFit.cover,
              imageUrl: dataModel.videoUrl!,
              progressIndicatorBuilder: (context, url, downloadProgress) =>
                  LinearProgressIndicator(value: downloadProgress.progress)),
          GestureDetector(
            onTap: () => controller.playVideo(dataModel),
            child: Container(
              alignment: Alignment.bottomRight,
              margin: const EdgeInsets.only(right: 10, bottom: 10),
              child: const Icon(Icons.play_circle_fill,
                  size: 30, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _createArticleView(BloggerCellModel dataModel) {
    return Container(
        margin: const EdgeInsets.only(top: 10),
        child: Column(
          children: [
            Container(
              height: 60,
              child: Text(dataModel.desc!,
                  style: const TextStyle(fontSize: 14, color: Colors.black), overflow:TextOverflow.ellipsis, maxLines: 4,),
            ),
            Expanded(
                child: ListView.builder(
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: (AppConst.screenWidth(context) -
                          (dataModel.imageUrls.obs.value!.length - 1) * 5) /
                      dataModel.imageUrls.obs.value!.length,
                  height: 80,
                  margin: const EdgeInsets.only(left: 5),
                  child: CachedNetworkImage(
                      fit: BoxFit.cover,
                      imageUrl: dataModel.imageUrls.obs.value![index],
                      progressIndicatorBuilder:
                          (context, url, downloadProgress) =>
                              LinearProgressIndicator(
                                  value: downloadProgress.progress)),
                );
              },
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: dataModel.imageUrls.obs.value?.length,
            ))
          ],
        ));
  }
}
