
class LastVisitModel {
  String imageUrl;
  String name;

  LastVisitModel({required this.imageUrl, required this.name});
}