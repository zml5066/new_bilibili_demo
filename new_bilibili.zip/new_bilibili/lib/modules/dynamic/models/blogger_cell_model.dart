class BloggerCellModel {
  String avatarUrl;
  String? videoUrl;
  String bloggerName;
  String time;
  String title;
  String? desc;
  bool isVideo;
  List<String>? imageUrls;
  String shareNum;
  String likeNum;
  String commentNum;

  BloggerCellModel({
    required this.avatarUrl,
    this.videoUrl,
    required this.bloggerName,
    required this.time,
    this.desc,
    required this.isVideo,
    this.imageUrls,
    required this.title,
    required this.shareNum,
    required this.likeNum,
    required this.commentNum,
  });
}
