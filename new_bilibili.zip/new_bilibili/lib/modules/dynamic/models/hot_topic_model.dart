
import 'package:get/get.dart';

class HotTopicModel {
  String topic;
  String topicId;
  HotTopicModel({required this.topic, required this.topicId});
}