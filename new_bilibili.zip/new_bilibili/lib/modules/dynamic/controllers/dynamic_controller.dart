import 'package:get/get.dart';
import '../../../utils/app_const/app_toast.dart';
import '../models/blogger_cell_model.dart';
import '../models/hot_topic_model.dart';
import '../models/last_visit_model.dart';

class DynamicController extends GetxController {
  late RxList<LastVisitModel> visitList;
  late RxList<HotTopicModel> topicList;
  late RxList<BloggerCellModel> bloggerList;

  void initData() {
    visitList = _defaultVisitData();
    topicList = _defaultHotTopicData();
    bloggerList = _defaultBloggerListData();
  }

  void openSendDynamicPage() {
    AppToast.toast('打开发布动态页面');
  }

  void openMorePage() {
    AppToast.toast('打开查看更多页面');
  }

  void openVisitUp(LastVisitModel dataModel) {
    AppToast.toast('打开最近访问的博主${dataModel.name}');
  }

  /// 打开热门话题更多页面
  void openHotUpMorePage() {
    AppToast.toast('打开热门话题更多页面');
  }

  void openBloggerMorePage(BloggerCellModel dataModel) {
    AppToast.toast('打开最近访问的博主${dataModel.bloggerName}');
  }

  void playVideo(BloggerCellModel dataModel) {
    AppToast.toast('播放${dataModel.bloggerName}的视频');
  }

  void openShare(BloggerCellModel dataModel){
    AppToast.toast('打开${dataModel.bloggerName}的分享');
  }

  void openComment(BloggerCellModel dataModel){
    AppToast.toast('打开${dataModel.bloggerName}的评论');
  }

  void likeBlogger(BloggerCellModel dataModel){
    AppToast.toast('点赞${dataModel.bloggerName}');
  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }

  @override
  void onClose() {}

  RxList<LastVisitModel> _defaultVisitData() {
    return RxList([
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '结节呼吸科专家王朝民'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: 'YouTube英语屋'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '金灿荣教授'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '冒险雷探长'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '雪哈哈的乡村生活'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '刘乐妍工作室'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '台湾张绍群'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '芬兰卡姐'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '温铁军学堂'),
      LastVisitModel(
          imageUrl:
              'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          name: '小小老师教您学唱歌'),
    ]);
  }

  RxList<HotTopicModel> _defaultHotTopicData() {
    return RxList([
      HotTopicModel(topic: '封神榜纣王饰演者达奇去世', topicId: '1'),
      HotTopicModel(topic: '月饼今年卖不动了', topicId: '2'),
      HotTopicModel(topic: '母亲与去世儿子游戏中重逢', topicId: '3'),
      HotTopicModel(topic: '中秋最美的月', topicId: '4'),
      HotTopicModel(topic: '中国人的名字有多惊艳', topicId: '5'),
      HotTopicModel(topic: '中秋国庆双节怎么过', topicId: '6'),
      HotTopicModel(topic: '养宠物教会我的事', topicId: '7'),
      HotTopicModel(topic: '宅家旅游大赛', topicId: '8'),
    ]);
  }

  RxList<BloggerCellModel> _defaultBloggerListData() {
    return RxList([
      BloggerCellModel(
          avatarUrl: 'https://randomuser.me/api/portraits/men/44.jpg',
          bloggerName: '金灿荣教授',
          videoUrl:
              'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
          time: '3个小时前',
          title: '金灿荣:世界进入大争之世界，西方雄霸天下将告一段落',
          isVideo: true,
          likeNum: '2735',
          shareNum: '9',
          commentNum: '121'),
      BloggerCellModel(
          avatarUrl: 'https://randomuser.me/api/portraits/men/45.jpg',
          bloggerName: '司马南',
          videoUrl:
              'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
          time: '2个小时前',
          title: '司马南:重要信号!美国让你引用毛主席语录',
          desc:
              '文/司马南在驻美大使谢锋举行的中华人民共和国国庆74周年招待会上，美中关系全国委员会会长欧伦斯用中英双语致辞，他引用乐毛主席金句，引来热烈掌声'
              '中国驻美大使谢锋主持建国纪念',
          isVideo: false,
          imageUrls: [
            'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
            'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240'
          ],
          likeNum: '2735',
          shareNum: '9',
          commentNum: '121'),
      BloggerCellModel(
          avatarUrl: 'https://randomuser.me/api/portraits/men/44.jpg',
          bloggerName: '金灿荣教授',
          videoUrl:
          'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
          time: '3个小时前',
          title: '金灿荣:世界进入大争之世界，西方雄霸天下将告一段落',
          isVideo: true,
          likeNum: '2735',
          shareNum: '9',
          commentNum: '121'),
      BloggerCellModel(
          avatarUrl: 'https://randomuser.me/api/portraits/men/45.jpg',
          bloggerName: '司马南',
          videoUrl:
          'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
          time: '2个小时前',
          title: '司马南:重要信号!美国让你引用毛主席语录',
          desc:
          '文/司马南在驻美大使谢锋举行的中华人民共和国国庆74周年招待会上，美中关系全国委员会会长欧伦斯用中英双语致辞，他引用乐毛主席金句，引来热烈掌声'
              '中国驻美大使谢锋主持建国纪念',
          isVideo: false,
          imageUrls: [
            'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
            'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240'
          ],
          likeNum: '2735',
          shareNum: '9',
          commentNum: '121'),
      BloggerCellModel(
          avatarUrl: 'https://randomuser.me/api/portraits/men/44.jpg',
          bloggerName: '金灿荣教授',
          videoUrl:
          'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
          time: '3个小时前',
          title: '金灿荣:世界进入大争之世界，西方雄霸天下将告一段落',
          isVideo: true,
          likeNum: '2735',
          shareNum: '9',
          commentNum: '121'),
      BloggerCellModel(
          avatarUrl: 'https://randomuser.me/api/portraits/men/45.jpg',
          bloggerName: '司马南',
          videoUrl:
          'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
          time: '2个小时前',
          title: '司马南:重要信号!美国让你引用毛主席语录',
          desc:
          '文/司马南在驻美大使谢锋举行的中华人民共和国国庆74周年招待会上，美中关系全国委员会会长欧伦斯用中英双语致辞，他引用乐毛主席金句，引来热烈掌声'
              '中国驻美大使谢锋主持建国纪念',
          isVideo: false,
          imageUrls: [
            'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
            'https://upload-images.jianshu.io/upload_images/2990730-5a7b5550a19b8342?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240'
          ],
          likeNum: '2735',
          shareNum: '9',
          commentNum: '121'),
    ]);
  }
}
