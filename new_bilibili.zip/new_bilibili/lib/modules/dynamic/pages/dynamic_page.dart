import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:new_bilibili/utils/app_const/app_colors.dart';
import '../controllers/dynamic_controller.dart';
import '../views/blogger_list_view.dart';
import '../views/hot_topic_view.dart';
import '../views/last_visit_view.dart';

class DynamicPage <Controller extends DynamicController>
    extends GetView<Controller>{
  const DynamicPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('关注',style: TextStyle(fontSize: 14,color: Colors.black)),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.wrap_text_rounded),
            onPressed: () => controller.openSendDynamicPage(),
          ),
        ],
        leading: const Text(''),

      ),
      body: Container(
        color: AppColors.pageBackground,
        child: ListView(
          scrollDirection: Axis.vertical,
          children: const[
            LastVisitView(),
            HotTopicView(),
            BloggerListView(),
          ],
        ),
      )
    );
  }
}
