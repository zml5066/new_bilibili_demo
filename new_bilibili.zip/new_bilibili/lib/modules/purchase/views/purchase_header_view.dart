import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/purchase/controllers/purchase_controller.dart';
import 'package:new_bilibili/modules/purchase/views/purchase_nav_view.dart';

import '../../../utils/app_const/app_const.dart';

class PurchaseHeaderView<Controller extends PurchaseController> extends GetView<Controller> {
  const PurchaseHeaderView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50 + AppConst.statusBarHeight(context),
      child: const PurchaseNavView(),
    );
  }
}
