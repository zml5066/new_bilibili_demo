import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/purchase/controllers/purchase_controller.dart';

import '../model/year_activity_model.dart';

class YearActivityView<Controller extends PurchaseController> extends GetView<Controller> {
  const YearActivityView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      margin: const EdgeInsets.only(left: 5, right: 5,top: 5),
      child: ListView.builder(itemBuilder: (BuildContext context, int index){
        return _createIcon(controller.activityList.obs.value[index]);
      },
        itemCount: controller.activityList.obs.value.length,
        physics: const ClampingScrollPhysics(),
        scrollDirection: Axis.horizontal,
      ),
    );
  }

  Widget _createIcon(YearActivityModel dataModel){
    return Container(
      height: 60,
      width: 70,
      margin: const EdgeInsets.only(left: 1, right: 1),
      child: Column(
        children: [
          SizedBox(width: 35,height: 35,  child:  Image.asset(dataModel.iconName),),
          Text(dataModel.title,style: const TextStyle(fontSize: 12, color: Colors.white),)
        ],
      ),
    );
  }
}
