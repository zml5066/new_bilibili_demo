import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/purchase/controllers/purchase_controller.dart';

import '../state/purchase_nav_state.dart';

class PurchaseSignView<Controller extends PurchaseController> extends GetView<Controller> {
  const PurchaseSignView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 5,right: 5,top: 10),
      height: 45,
      child: Row(
        children: [
          _createSign(),
         Expanded(child:  _createField()),
          _createClass(),
        ],
      ),
    );
  }

  Widget _createSign(){
    return GestureDetector(
      onTap: ()=>controller.purchaseNavTap(PurchaseNavEventType.purchaseNavEventTypeSign),
      child: Container(
        height: 40,width: 60,
        margin: const EdgeInsets.only(left: 5),
        decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(5)),
        child:const Row(
          children: [
            SizedBox(width: 2),
            Icon(Icons.monetization_on_rounded, color: Colors.yellow),
            SizedBox(width: 3),
            Text('签到\n有礼',style: TextStyle(fontSize: 10, color: Colors.black)),
            SizedBox(width: 2),
          ],
        ),
      ),
    );
  }

  Widget _createClass(){
    return GestureDetector(
      onTap: ()=>controller.purchaseNavTap(PurchaseNavEventType.purchaseNavEventTypeClass),
      child: Container(
        width: 30,
        height: 45,
        child: const Column(
          children: [
            Text('ALL', style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold, fontSize: 14)),
            Text('分类', style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 12))
          ],
        ),
      ),
    );
  }

  Widget _createField(){
    return GestureDetector(
      onTap: ()=>controller.purchaseNavTap(PurchaseNavEventType.purchaseNavEventTypeSearch),
      child: Container(
        margin: const EdgeInsets.only(left: 5, right: 5),
        height: 30,
        decoration: BoxDecoration(color: const Color.fromRGBO(255, 255, 255, 0.3),borderRadius: BorderRadius.circular(20)),
        child:  Row(
          children: [
            const SizedBox(width: 5),
            const Icon(Icons.search,color: Colors.white, size: 15),
            const Expanded(child: Text('60元宠粉神劵限量抢！',style: TextStyle(fontSize: 12, color: Colors.black))),
            GestureDetector(
              onTap: ()=>controller.purchaseNavTap(PurchaseNavEventType.purchaseNavEventTypeQRCode),
              child: const Icon(Icons.photo_camera,color: Colors.white, size: 15),
            )
          ],
        ),
      ),
    );
  }
}
