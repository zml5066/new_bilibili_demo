import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/purchase/controllers/purchase_controller.dart';

import '../model/purchase_cell_model.dart';

class PurchaseCellView<Controller extends PurchaseController>
    extends GetView<Controller> {
  final PurchaseCellModel dataModel;

  const PurchaseCellView({super.key, required this.dataModel});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(8.0)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.only(topLeft: Radius.circular(8), topRight: Radius.circular(8)),
            child: CachedNetworkImage(
                fit: BoxFit.cover,
                imageUrl: dataModel.imageUrl,
                progressIndicatorBuilder: (context, url, downloadProgress) =>
                    LinearProgressIndicator(value: downloadProgress.progress)), //设置圆角
          ),
          _createProductInfo(),
        ],
      ),
    );
  }

  Widget _createProductInfo() {
    return Container(
      height: 48,
      alignment: Alignment.centerLeft,
      margin: const EdgeInsets.only(left: 5, right: 5),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(dataModel.title,
              style: const TextStyle(fontSize: 12, color: Colors.black)),
          const Text('免费试玩',
              style: TextStyle(fontSize: 10, color: Colors.deepOrangeAccent)),
          Text(dataModel.price,
              style: const TextStyle(
                  fontSize: 12, color: Colors.deepOrangeAccent)),
        ],
      ),
    );
  }
}
