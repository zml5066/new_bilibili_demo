import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/purchase/controllers/purchase_controller.dart';
import 'package:new_bilibili/modules/purchase/views/purchase_cell_view.dart';

import '../model/purchase_cell_model.dart';

class PurchaseListView<Controller extends PurchaseController> extends GetView<Controller> {
  const PurchaseListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5),
      child: MasonryGridView.count(
        crossAxisCount: 2,
        itemCount:controller.purchaseList.obs.value.length,
        itemBuilder: (BuildContext context, int index) =>
            PurchaseCellView(dataModel: controller.purchaseList.obs.value[index]),
        mainAxisSpacing: 6,
        crossAxisSpacing: 6,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
      ),
    );
  }
  // @override
  // Widget build(BuildContext context) {
  //   return Container(
  //     color: Colors.yellow,
  //     margin: const EdgeInsets.only(left: 5, right: 5),
  //     child: ListView.builder(itemBuilder: (BuildContext context, int index){
  //        return PurchaseCellView(dataModel: controller.purchaseList.obs.value[index]);
  //     },
  //       itemCount: controller.purchaseList.obs.value.length,
  //       shrinkWrap:true,
  //       physics: const NeverScrollableScrollPhysics(),
  //     ),
  //   );
  // }
}
