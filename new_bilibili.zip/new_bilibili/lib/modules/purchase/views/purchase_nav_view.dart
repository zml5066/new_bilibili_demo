import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:new_bilibili/modules/purchase/controllers/purchase_controller.dart';
import '../../../utils/app_const/app_const.dart';
import '../../../utils/marquee/vertical_marquee.dart';
import '../state/purchase_nav_state.dart';

class PurchaseNavView<Controller extends PurchaseController>
    extends GetView<Controller> {
  const PurchaseNavView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      margin: EdgeInsets.only(left: 5, right: 5,top: AppConst.statusBarHeight(context)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Obx(() => controller.navState.showSearchField.value?Expanded(child: _createField()):_createMarquee()),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _createIcon(PurchaseNavEventType.purchaseNavEventTypeBuy,
                  Icons.shopping_basket_outlined),
              _createIcon(PurchaseNavEventType.purchaseNavEventTypeMember,
                  Icons.person_pin_outlined),
            ],
          )
        ],
      ),
    );
  }

  Widget _createField(){
    return GestureDetector(
      child: Container(
        margin: const EdgeInsets.only(left: 5, right: 5),
        height: 30,
        decoration: BoxDecoration(color: const Color.fromRGBO(255, 255, 255, 0.3),borderRadius: BorderRadius.circular(20)),
        child: const Row(
          children: [
            SizedBox(width: 5),
            Icon(Icons.search,color: Colors.white, size: 15),
            Expanded(child: Text('60元宠粉神劵限量抢！',style: TextStyle(fontSize: 12, color: Colors.white)))
          ],
        ),
      ),
    );
  }

  Widget _createMarquee() {
    return GestureDetector(
      onTap: ()=>controller.purchaseNavTap(PurchaseNavEventType.purchaseNavEventTypeSearch),
      child:Container(
        width: 170,
        height: 30,
        margin: const EdgeInsets.only(left: 5, right: 5),
        child:   Row(
          children: [
            const Text('会员购',style: TextStyle( fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold)),
            Expanded(
              child: VerticalMarquee(
                stepOffset: 1,
                itemBuilder: (BuildContext context, int index) {
                  index = index.abs();
                  if(index < controller.purchaseNavMarqueeList.obs.value.length) {
                    return GestureDetector(
                      child: Container(
                        alignment: Alignment.center,
                        height: 30,
                        child:Text(controller.purchaseNavMarqueeList.obs.value[index],style: const TextStyle(fontSize: 12,color: Colors.white)),
                      ),
                    );
                  }
                  else {
                    var newIndex = index % controller.purchaseNavMarqueeList.obs.value.length;
                    return GestureDetector(
                      child: Container(
                        height: 30,
                        alignment: Alignment.center,
                        child:Text(controller.purchaseNavMarqueeList.obs.value[newIndex],style: const TextStyle(fontSize: 12,color: Colors.white)),
                      ),
                    );
                  }
                },
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,  color: Colors.white, size: 20)
          ],
        ),
      ),
    );
  }

  Widget _createIcon(PurchaseNavEventType type, IconData iconData) {
    return GestureDetector(
      onTap: () => controller.purchaseNavTap(type),
      child: Container(
        width: 30,
        height: 30,
        margin: const EdgeInsets.only(left: 5, right: 5),
        alignment: Alignment.center,
        child: Icon(iconData, color: Colors.white, size: 25),
      ),
    );
  }
}
