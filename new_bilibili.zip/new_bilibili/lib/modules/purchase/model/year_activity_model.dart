
class YearActivityModel {
  String iconName;
  String title;
  String activityId;
  YearActivityModel({required this.iconName, required this.title, required this.activityId});
}