import 'package:get/get.dart';

class PurchaseCellModel {
  String imageUrl;
  String title;
  String price;
  String likeNum;
  int? imageWidth;
  int? imageHeight;
  PurchaseCellModel({required this.imageUrl, required this.title, required this.price,required this.likeNum, this.imageHeight,this.imageWidth});
}