import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../controllers/purchase_controller.dart';
import '../views/purchase_header_view.dart';
import '../views/purchase_list_view.dart';
import '../views/purchase_sign_view.dart';
import '../views/year_activity_view.dart';

class PurchasePage<Controller extends PurchaseController>
    extends GetView<Controller> {
  const PurchasePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
              child: Image.asset("assets/images/purchase_back.jpg",
                  fit: BoxFit.cover)),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const PurchaseHeaderView(),
              Expanded(
                  child: MediaQuery.removePadding(
                      removeTop: true,
                      context: context,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 0.5),
                        child: ListView(
                          controller:controller.purchaseListController ,
                          physics: const ClampingScrollPhysics(),
                          scrollDirection: Axis.vertical,
                          children: const [
                            PurchaseSignView(),
                            YearActivityView(),
                            PurchaseListView(),
                          ],
                        ),
                      )
                  )
              ),
            ],
          )
        ],
      ),
    );
  }
}
