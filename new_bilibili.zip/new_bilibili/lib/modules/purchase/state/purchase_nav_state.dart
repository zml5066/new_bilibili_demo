
import 'package:get/get.dart';
enum PurchaseNavEventType {
  purchaseNavEventTypeBuy,// 购物
  purchaseNavEventTypeMember, //会员购物中心
  purchaseNavEventTypeSearch,// 搜索
  purchaseNavEventTypeSign, // 签到
  purchaseNavEventTypeClass,// 分类
  purchaseNavEventTypeQRCode,// 扫码
}

class PurchaseNavState {
  RxBool showSearchField;
  PurchaseNavState({required this.showSearchField});
}