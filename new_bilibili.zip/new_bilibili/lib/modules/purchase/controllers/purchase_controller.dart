import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../../../utils/app_const/app_toast.dart';
import '../model/purchase_cell_model.dart';
import '../model/year_activity_model.dart';
import '../state/purchase_nav_state.dart';

class PurchaseController extends GetxController{

  late PurchaseNavState navState;

  late RxList<String> purchaseNavMarqueeList;

  late RxList<YearActivityModel> activityList;

  late RxList<PurchaseCellModel>purchaseList;

  late ScrollController purchaseListController;

  void purchaseNavTap(PurchaseNavEventType type){
    if (type == PurchaseNavEventType.purchaseNavEventTypeSearch) {
      AppToast.toast('搜索');
    }
  }

  void openYearActivity(YearActivityModel dataModel){
    AppToast.toast(dataModel.iconName);

  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    navState = PurchaseNavState(showSearchField: false.obs);
    purchaseNavMarqueeList = _defaultPurchaseNavMarqueeList();
    activityList = _defaultActivityList();
    purchaseList = _defaultPurchaseList();
    purchaseListController = ScrollController();
    purchaseListController.addListener(() {
      if (purchaseListController.offset > 50) {
        navState.showSearchField.value = true;
      }
      else if (purchaseListController.offset <= 30) {
        navState.showSearchField.value = false;
      }
    });
  }

  RxList<String> _defaultPurchaseNavMarqueeList(){
    return RxList<String>([
      '内购群现实开放',
      '内购群现实开放',
      '内购群现实开放',
      '官方直营.正品保障'
    ]);
  }

  RxList<YearActivityModel> _defaultActivityList(){
    return RxList<YearActivityModel>([
      YearActivityModel(iconName: 'assets/images/D言D语.png',title: '手办雕像', activityId: '0'),
      YearActivityModel(iconName: 'assets/images/疯狂点赞.png',title: '盲盒', activityId: '1'),
      YearActivityModel(iconName: 'assets/images/红叶大道.png',title: '漫展', activityId: '2'),
      YearActivityModel(iconName: 'assets/images/缘定三生.png',title: '新人福利', activityId: '3'),
      YearActivityModel(iconName: 'assets/images/荧光马车.png',title: '谷子', activityId: '4'),
      YearActivityModel(iconName: 'assets/images/踏青日记.png',title: '景品', activityId: '5'),
      YearActivityModel(iconName: 'assets/images/灵魂歌姬.png',title: 'Q版手办', activityId: '6'),
      YearActivityModel(iconName: 'assets/images/灯塔.png',title: '漫画', activityId: '7'),
      YearActivityModel(iconName: 'assets/images/海洋之心.png',title: '画集', activityId: '8'),
      YearActivityModel(iconName: 'assets/images/次元之城.png',title: '毛绒玩具', activityId: '9'),
      YearActivityModel(iconName: 'assets/images/草莓蛋糕.png',title: '品牌馆', activityId: '10'),
      YearActivityModel(iconName: 'assets/images/震撼声浪.png',title: '轻小说', activityId: '11'),
      YearActivityModel(iconName: 'assets/images/马了顶大.png',title: '个性装扮', activityId: '12'),

    ]);
  }

  RxList<PurchaseCellModel>_defaultPurchaseList(){
    return RxList<PurchaseCellModel>([
      PurchaseCellModel(
        imageUrl: 'https://bkimg.cdn.bcebos.com/pic/500fd9f9d72a6059252d1977427a239b033b5bb50c05?x-bce-process=image/watermark,image_d2F0ZXIvYmFpa2UxNTA=,g_7,xp_5,yp_5/format,f_auto',
        title: '精灵粉晶1',price: '¥15元/抽',likeNum: '15'),
      PurchaseCellModel(
          imageUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fnimg.ws.126.net%2F%3Furl%3Dhttp%3A%2F%2Fdingyue.ws.126.net%2F2021%2F0624%2Fca3f3547j00qv6yuq002ic000mn0148c.jpg%26thumbnail%3D650x2147483647%26quality%3D80%26type%3Djpg&refer=http%3A%2F%2Fnimg.ws.126.net&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1636620826&t=1f7e60c5d4a5baadafbae5d25dfdae39',
          title: '精灵粉晶2',price: '¥15元/抽',likeNum: '25'),
      PurchaseCellModel(
          imageUrl: 'https://bkimg.cdn.bcebos.com/pic/0d338744ebf81a4c510f10a4bd647759252dd42a0805?x-bce-process=image/watermark,image_d2F0ZXIvYmFpa2UyMjA=,g_7,xp_5,yp_5/format,f_auto',
          title: '精灵粉晶3',price: '¥15元/抽',likeNum: '35'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=3203007717,1062852813&fm=193&f=GIF',
          title: '精灵粉晶4',price: '¥15元/抽',likeNum: '45'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=3748136518,1353249359&fm=193&f=GIF',
          title: '精灵粉晶5',price: '¥15元/抽',likeNum: '55'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=3212659202,2293359303&fm=193&f=GIF',
          title: '精灵粉晶6',price: '¥15元/抽',likeNum: '65'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=2208874845,2635541186&fm=193&f=GIF',
          title: '精灵粉晶7',price: '¥15元/抽',likeNum: '75'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=2605426091,1199286953&fm=193&f=GIF',
          title: '精灵粉晶13',price: '¥15元/抽',likeNum: '135'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=2478304529,1778129966&fm=193&f=GIF',
          title: '精灵粉晶8',price: '¥15元/抽',likeNum: '85'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=814247456,3302780251&fm=193&f=GIF',
          title: '精灵粉晶9',price: '¥15元/抽',likeNum: '95'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=519156368,1721871523&fm=193&f=GIF',
          title: '精灵粉晶10',price: '¥15元/抽',likeNum: '105'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=2237872352,3036992004&fm=193&f=GIF',
          title: '精灵粉晶11',price: '¥15元/抽',likeNum: '125'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=1831846009,1460005090&fm=193&f=GIF',
          title: '精灵粉晶11',price: '¥15元/抽',likeNum: '125'),
      PurchaseCellModel(
          imageUrl: 'https://bkimg.cdn.bcebos.com/pic/500fd9f9d72a6059252d1977427a239b033b5bb50c05?x-bce-process=image/watermark,image_d2F0ZXIvYmFpa2UxNTA=,g_7,xp_5,yp_5/format,f_auto',
          title: '精灵粉晶1',price: '¥15元/抽',likeNum: '15'),
      PurchaseCellModel(
          imageUrl: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fnimg.ws.126.net%2F%3Furl%3Dhttp%3A%2F%2Fdingyue.ws.126.net%2F2021%2F0624%2Fca3f3547j00qv6yuq002ic000mn0148c.jpg%26thumbnail%3D650x2147483647%26quality%3D80%26type%3Djpg&refer=http%3A%2F%2Fnimg.ws.126.net&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1636620826&t=1f7e60c5d4a5baadafbae5d25dfdae39',
          title: '精灵粉晶2',price: '¥15元/抽',likeNum: '25'),
      PurchaseCellModel(
          imageUrl: 'https://bkimg.cdn.bcebos.com/pic/0d338744ebf81a4c510f10a4bd647759252dd42a0805?x-bce-process=image/watermark,image_d2F0ZXIvYmFpa2UyMjA=,g_7,xp_5,yp_5/format,f_auto',
          title: '精灵粉晶3',price: '¥15元/抽',likeNum: '35'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=2886797742,2479237417&fm=193&f=GIF',
          title: '精灵粉晶4',price: '¥15元/抽',likeNum: '45'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=3029471159,3452873511&fm=193&f=GIF',
          title: '精灵粉晶5',price: '¥15元/抽',likeNum: '55'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=1678502879,748956315&fm=193&f=GIF',
          title: '精灵粉晶6',price: '¥15元/抽',likeNum: '65'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=3632800210,243418919&fm=193&f=GIF',
          title: '精灵粉晶7',price: '¥15元/抽',likeNum: '75'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=3859735106,2767469648&fm=193&f=GIF',
          title: '精灵粉晶13',price: '¥15元/抽',likeNum: '135'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=1469153347,135482855&fm=193&f=GIF',
          title: '精灵粉晶8',price: '¥15元/抽',likeNum: '85'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=1092574912,855301095&fm=193&f=GIF',
          title: '精灵粉晶9',price: '¥15元/抽',likeNum: '95'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=91673060,7145840&fm=193&f=GIF',
          title: '精灵粉晶10',price: '¥15元/抽',likeNum: '105'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=4036010509,3445021118&fm=193&f=GIF',
          title: '精灵粉晶11',price: '¥15元/抽',likeNum: '125'),
      PurchaseCellModel(
          imageUrl: 'https://t7.baidu.com/it/u=1956604245,3662848045&fm=193&f=GIF',
          title: '精灵粉晶11',price: '¥15元/抽',likeNum: '125'),
    ]);
  }
}