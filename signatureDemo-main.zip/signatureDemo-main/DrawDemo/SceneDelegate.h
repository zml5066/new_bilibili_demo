//
//  SceneDelegate.h
//  DrawDemo
//
//  Created by 明孔 on 2020/11/5.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

